import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  try {
    const salt = randomBytes(16).toString("hex");
    const buf = (await scryptAsync(password, salt, 64)) as Buffer;
    return `${buf.toString("hex")}.${salt}`;
  } catch (error) {
    console.error('Error hashing password:', error);
    throw error;
  }
}

async function comparePasswords(supplied: string, stored: string) {
  try {
    const [hashed, salt] = stored.split(".");
    if (!hashed || !salt) {
      console.error('Invalid stored password format');
      return false;
    }
    const hashedBuf = Buffer.from(hashed, "hex");
    const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
    return timingSafeEqual(hashedBuf, suppliedBuf);
  } catch (error) {
    console.error('Error comparing passwords:', error);
    return false;
  }
}

let hasInitialized = false;

export function setupAuth(app: Express) {
  const isDevelopment = app.get("env") === "development";
  const sessionSecret = process.env.SESSION_SECRET || randomBytes(32).toString('hex');

  app.use(session({
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: !isDevelopment,
      sameSite: isDevelopment ? 'lax' : 'strict',
      maxAge: 24 * 60 * 60 * 1000,
      httpOnly: true
    },
    name: 'travel.sid'
  }));

  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        console.log('Login attempt for:', username);
        let user = await storage.getUserByUsername(username);

        if (!user) {
          console.log('No user found with username:', username);
          return done(null, false, { message: "Invalid credentials" });
        }

        const validPassword = await comparePasswords(password, user.password);
        console.log('Password validation result:', validPassword);

        if (!validPassword) {
          console.log('Invalid password for user:', username);
          return done(null, false, { message: "Invalid credentials" });
        }

        console.log('Login successful for user:', username);
        return done(null, user);
      } catch (error) {
        console.error('Login error:', error);
        return done(error);
      }
    })
  );

  if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
    // Always use HTTPS for OAuth with Replit
    const protocol = 'https';
    
    // Get the domain directly from the environment variable
    const domain = process.env.REPLIT_DEV_DOMAIN;
    
    if (!domain) {
      console.warn('REPLIT_DEV_DOMAIN environment variable is not set. Google OAuth may not work correctly.');
    }
    
    const callbackURL = `${protocol}://${domain}/auth/google/callback`;
    
    // Log the complete callback URL for debugging
    console.log('Full callback URL:', callbackURL);

    console.log('Setting up Google auth with callback URL:', callbackURL);

    passport.use(
      new GoogleStrategy(
        {
          clientID: process.env.GOOGLE_CLIENT_ID,
          clientSecret: process.env.GOOGLE_CLIENT_SECRET,
          callbackURL: callbackURL,
          passReqToCallback: true
        },
        async (req, accessToken, refreshToken, profile, done) => {
          try {
            console.log('Google login attempt for:', profile.emails?.[0]?.value);

            let user = await storage.getUserByUsername(profile.emails?.[0]?.value || '');

            if (!user) {
              console.log('Creating new Google user account');
              const randomPassword = randomBytes(32).toString('hex');
              const hashedPassword = await hashPassword(randomPassword);

              user = await storage.createUser({
                username: profile.emails?.[0]?.value || '',
                password: hashedPassword,
                phone_verified: true,
                google_id: profile.id,
                display_name: profile.displayName,
                avatar_url: profile.photos?.[0]?.value
              });

              console.log('Google user account created:', user.id);
            } else {
              console.log('Updating existing user with Google info');
              user = await storage.updateUser(user.id, {
                google_id: profile.id,
                display_name: profile.displayName,
                avatar_url: profile.photos?.[0]?.value
              });
            }

            return done(null, user);
          } catch (error) {
            console.error('Google authentication error:', error);
            return done(error as Error);
          }
        }
      )
    );
  } else {
    console.warn('Google authentication is not configured. Missing client ID or secret.');
  }

  passport.serializeUser((user: SelectUser, done) => {
    console.log('Serializing user:', user.id);
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      console.log('Deserializing user:', id);
      const user = await storage.getUser(id);
      if (!user) {
        console.log('No user found for ID:', id);
        return done(null, false);
      }
      console.log('User deserialized successfully:', user.id);
      done(null, user);
    } catch (error) {
      console.error('Deserialization error:', error);
      done(error, null);
    }
  });

  async function initializeUsers() {
    if (hasInitialized) {
      console.log('Users already initialized, skipping...');
      return;
    }

    try {
      const testEmail = "test@example.com";
      const testPassword = "test123";

      console.log('Checking for existing test user...');
      let existingUser = await storage.getUserByUsername(testEmail);

      if (!existingUser) {
        console.log('Creating test user account...');
        const hashedPassword = await hashPassword(testPassword);
        existingUser = await storage.createUser({
          username: testEmail,
          password: hashedPassword,
          phone_verified: true
        });
        console.log('Test user account created:', existingUser.id);
      } else {
        console.log('Test user already exists:', existingUser.id);
      }

      const guestEmail = "guest@example.com";
      const guestPassword = "guest123";

      console.log('Checking for existing guest user...');
      let guestUser = await storage.getUserByUsername(guestEmail);

      if (!guestUser) {
        console.log('Creating guest user account...');
        const hashedPassword = await hashPassword(guestPassword);
        guestUser = await storage.createUser({
          username: guestEmail,
          password: hashedPassword,
          phone_verified: true
        });
        console.log('Guest user account created:', guestUser.id);
      } else {
        console.log('Guest user already exists:', guestUser.id);
      }

      hasInitialized = true;
    } catch (error) {
      console.error('Error initializing users:', error);
    }
  }

  initializeUsers();

  app.get('/auth/google',
    (req, res, next) => {
      console.log('Initiating Google OAuth flow');
      passport.authenticate('google', { 
        scope: ['profile', 'email'],
        prompt: 'select_account'
      })(req, res, next);
    }
  );

  app.get('/auth/google/callback',
    (req, res, next) => {
      console.log('Handling Google OAuth callback', req.query);
      // Check for Google-provided error
      if (req.query.error) {
        console.error('Google auth error from query params:', req.query.error);
        return res.redirect('/auth?error=' + encodeURIComponent(req.query.error as string));
      }
      
      passport.authenticate('google', { 
        failureRedirect: '/auth',
        failureMessage: true
      })(req, res, (err) => {
        if (err) {
          console.error('Google OAuth callback error:', err);
          return res.redirect('/auth?error=google-auth-failed');
        }
        console.log('Google authentication successful, redirecting to homepage');
        res.redirect('/');
      });
    }
  );

  app.post("/api/guest-login", async (req, res) => {
    try {
      console.log('Guest login attempt');
      const guestUser = await storage.getUserByUsername("guest@example.com");
      if (!guestUser) {
        console.error('Guest account not found');
        return res.status(500).json({ message: "Guest account not available" });
      }

      req.login(guestUser, (err) => {
        if (err) {
          console.error('Guest login error:', err);
          return res.status(500).json({ message: "Login failed" });
        }
        console.log('Guest login successful');
        res.json(guestUser);
      });
    } catch (error) {
      console.error('Guest login error:', error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.post("/api/login", (req, res, next) => {
    console.log('Login request received:', { username: req.body?.username });

    passport.authenticate("local", (err: Error | null, user: SelectUser | false, info: { message: string } | undefined) => {
      console.log('Authentication result:', { err, user: !!user, info });

      if (err) {
        console.error('Authentication error:', err);
        return next(err);
      }

      if (!user) {
        console.log('Authentication failed:', info?.message);
        return res.status(401).json({ message: info?.message || "Invalid credentials" });
      }

      req.login(user, (err) => {
        if (err) {
          console.error('Login error:', err);
          return next(err);
        }
        console.log('Login successful for user:', user.username);
        res.json(user);
      });
    })(req, res, next);
  });

  app.post("/api/register", async (req, res, next) => {
    try {
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const hashedPassword = await hashPassword(req.body.password);
      const user = await storage.createUser({
        username: req.body.username,
        password: hashedPassword,
        phone_verified: true
      });

      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(user);
      });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/logout", (req, res, next) => {
    console.log('Logout request received');
    req.logout((err) => {
      if (err) {
        console.error('Logout error:', err);
        return next(err);
      }
      console.log('Logout successful');
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    console.log('User request:', { 
      isAuthenticated: req.isAuthenticated(),
      user: req.user,
      session: req.session
    });

    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    res.json(req.user);
  });
}