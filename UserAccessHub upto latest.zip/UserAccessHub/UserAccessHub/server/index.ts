import 'dotenv/config'; // Load environment variables early
import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes, setupLoggingEndpoint } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { getDatabaseStatus } from "./db";
import { setupAuth } from "./auth";
import cors from "cors";

const app = express();

// Security middleware
app.set("trust proxy", 1);

// Basic middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors({
  origin: true,
  credentials: true
}));

// Simple request logging
app.use((req, res, next) => {
  const start = Date.now();
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (req.path.startsWith("/api")) {
      log(`${req.method} ${req.path} ${res.statusCode} ${duration}ms`);
    }
  });
  next();
});

// Setup authentication
setupAuth(app);

// Setup client-side error logging endpoint
setupLoggingEndpoint(app);

// Basic health check
app.get("/api/health", (_req, res) => {
  res.json({ 
    status: "ok",
    timestamp: new Date().toISOString(),
    env: app.get("env")
  });
});

// Error handling middleware
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  console.error('Server error:', err);
  res.status(err.status || 500).json({ 
    message: err.message || 'Internal Server Error',
    ...(app.get("env") === "development" ? { error: err.stack } : {})
  });
});

// Initialize server
async function startServer() {
  try {
    // Register API routes
    const server = registerRoutes(app);

    // Setup Vite or static file serving
    if (app.get("env") === "development") {
      await setupVite(app, server);
    } else {
      serveStatic(app);
    }

    // Start listening
    const startServer = (port: number) => {
        server.listen(port, '0.0.0.0', () => {
          log(`Server running on port ${port} in ${app.get("env")} mode at http://0.0.0.0:${port}`);
        }).on('error', (err: any) => {
          if (err.code === 'EADDRINUSE') {
            log(`Port ${port} is already in use, trying ${port + 1}`);
            startServer(port + 1);
          } else {
            console.error('Server error:', err);
            process.exit(1); // Exit process on unrecoverable errors
          }
        });
      };

    const PORT = parseInt(process.env.PORT || '5000', 10);
    startServer(PORT);

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();