import { users, type User, type InsertUser } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User>;
  updateUserOTP(phone: string, otp: string, expiryTime: Date): Promise<void>;
  verifyUserPhone(phone: string): Promise<void>;
  sessionStore: session.Store;
}

class InMemoryStorage implements IStorage {
  private users: User[] = [];
  private nextId = 1;
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000
    });
    console.log('InMemoryStorage initialized');
  }

  async getUser(id: number): Promise<User | undefined> {
    const user = this.users.find(u => u.id === id);
    console.log('Getting user by ID:', id, user ? 'found' : 'not found');
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const user = this.users.find(u => u.username === username);
    console.log('Getting user by username:', username, user ? 'found' : 'not found');
    return user;
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    const user = this.users.find(u => u.phone_number === phone);
    console.log('Getting user by phone:', phone, user ? 'found' : 'not found');
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    console.log('Creating new user:', { username: insertUser.username });

    if (!insertUser.password) {
      throw new Error('Password is required');
    }

    const user: User = {
      id: this.nextId++,
      username: insertUser.username,
      password: insertUser.password,
      phone_number: insertUser.phone_number || null,
      phone_verified: false,
      otp: null,
      otp_expires: null,
      preferences: insertUser.preferences || {
        preferredClass: "",
        budget: 5000,
        cuisinePreferences: [],
        travelStyle: [],
        favoriteDestinations: [],
        accommodationPreferences: [],
        interests: [],
        transportPreferences: [],
        climatePreference: "",
        tripDurationPreference: ""
      },
      google_id: insertUser.google_id || null,
      display_name: insertUser.display_name || null,
      avatar_url: insertUser.avatar_url || null
    };

    this.users.push(user);
    console.log('User created:', { id: user.id, username: user.username });
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with ID ${id} not found`);
    }

    // Update user fields, ensuring type safety
    const updatedUser: User = {
      ...user,
      ...updates,
      // Ensure required fields aren't overwritten with null/undefined
      id: user.id,
      username: updates.username || user.username,
      password: updates.password || user.password,
    };

    // Replace the old user object with the updated one
    const userIndex = this.users.findIndex(u => u.id === id);
    this.users[userIndex] = updatedUser;

    console.log('Updated user:', { id: updatedUser.id, username: updatedUser.username });
    return updatedUser;
  }

  async updateUserOTP(phone: string, otp: string, expiryTime: Date): Promise<void> {
    let user = await this.getUserByPhone(phone);

    if (!user) {
      console.log('Creating new user for OTP verification');
      user = await this.createUser({
        username: phone,
        password: `temp.${Date.now()}`, // Temporary password with correct format
        phone_number: phone
      });
    }

    user.otp = otp;
    user.otp_expires = expiryTime;
    console.log('Updated OTP for user:', user.id);
  }

  async verifyUserPhone(phone: string): Promise<void> {
    const user = await this.getUserByPhone(phone);
    if (user) {
      user.phone_verified = true;
      user.otp = null;
      user.otp_expires = null;
      console.log('Phone verified for user:', user.id);
    }
  }
}

export const storage = new InMemoryStorage();