import Amadeus from "amadeus";
import type { FlightBooking } from "@shared/schema";

declare module 'amadeus' {
  interface SearchParams {
    originLocationCode: string;
    destinationLocationCode: string;
    departureDate: string;
    adults?: number;
    travelClass?: string;
    max?: number;
  }

  interface FlightOffer {
    id: string;
    validatingAirlineCodes: string[];
    itineraries: Array<{
      segments: Array<{
        departure: {
          iataCode: string;
          at: string;
        };
        arrival: {
          iataCode: string;
          at: string;
        };
      }>;
    }>;
    price: {
      total: string;
    };
    travelerPricings: Array<{
      fareDetailsBySegment: Array<{
        cabin: string;
      }>;
    }>;
  }
}

export class FlightService {
  private amadeus: Amadeus;

  constructor() {
    if (!process.env.AMADEUS_API_KEY || !process.env.AMADEUS_API_SECRET) {
      throw new Error('Amadeus API credentials are not configured');
    }

    this.amadeus = new Amadeus({
      clientId: process.env.AMADEUS_API_KEY,
      clientSecret: process.env.AMADEUS_API_SECRET,
    });
  }

  async searchFlights(params: {
    originLocationCode: string;
    destinationLocationCode: string;
    departureDate: string;
    adults?: number;
    travelClass?: string;
  }): Promise<FlightBooking[]> {
    try {
      console.log('Searching flights with params:', params);

      const { data } = await this.amadeus.shopping.flightOffersSearch.get({
        ...params,
        adults: params.adults || 1,
        max: 20, // Increased limit for more results
        currencyCode: 'USD'
      });

      console.log(`Found ${data.length} flight offers`);

      return data.map((offer: Amadeus.FlightOffer) => ({
        id: offer.id,
        airline: this.getAirlineName(offer.validatingAirlineCodes[0]),
        from: offer.itineraries[0].segments[0].departure.iataCode,
        to: offer.itineraries[0].segments[0].arrival.iataCode,
        departure: offer.itineraries[0].segments[0].departure.at,
        arrival: offer.itineraries[0].segments[0].arrival.at,
        price: parseFloat(offer.price.total),
        class: offer.travelerPricings[0].fareDetailsBySegment[0].cabin,
        stops: offer.itineraries[0].segments.length - 1,
        duration: this.calculateDuration(
          offer.itineraries[0].segments[0].departure.at,
          offer.itineraries[0].segments[offer.itineraries[0].segments.length - 1].arrival.at
        ),
        // Add formatted fields for mobile display
        formattedDeparture: this.formatTimeForMobile(offer.itineraries[0].segments[0].departure.at),
        formattedArrival: this.formatTimeForMobile(offer.itineraries[0].segments[offer.itineraries[0].segments.length - 1].arrival.at),
        formattedPrice: `$${parseFloat(offer.price.total).toFixed(2)}`,
      }));
    } catch (error) {
      console.error('Error searching flights:', error);
      throw new Error('Failed to search flights');
    }
  }

  async getAirportsByKeyword(keyword: string) {
    try {
      console.log('Searching airports with keyword:', keyword);

      const { data } = await this.amadeus.referenceData.locations.get({
        keyword,
        subType: Amadeus.location.airport,
      });

      console.log(`Found ${data.length} airports`);

      return data.map((location: any) => ({
        code: location.iataCode,
        name: location.name,
        city: location.address.cityName,
        country: location.address.countryName,
      }));
    } catch (error) {
      console.error('Error fetching airports:', error);
      throw new Error('Failed to fetch airports');
    }
  }

  private getAirlineName(code: string): string {
    // Add more airline mappings as needed
    const airlines: { [key: string]: string } = {
      'AA': 'American Airlines',
      'UA': 'United Airlines',
      'DL': 'Delta Air Lines',
      'WN': 'Southwest Airlines',
      'AC': 'Air Canada',
      // Add more airlines
    };
    return airlines[code] || code;
  }

  private calculateDuration(departure: string, arrival: string): string {
    const start = new Date(departure);
    const end = new Date(arrival);
    const hours = Math.floor((end.getTime() - start.getTime()) / (1000 * 60 * 60));
    const minutes = Math.floor(((end.getTime() - start.getTime()) % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  }
  
  private formatTimeForMobile(dateTimeString: string): string {
    const date = new Date(dateTimeString);
    // Format: "1:30 PM | Mar 15"
    const time = date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit', 
      hour12: true 
    });
    const monthDay = date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric' 
    });
    return `${time} | ${monthDay}`;
  }
}

export const flightService = new FlightService();