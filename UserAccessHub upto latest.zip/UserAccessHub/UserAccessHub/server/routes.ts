import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from 'ws';
import { setupAuth } from "./auth";
import { generateHotels, generateRides, generateDining } from "../shared/mockData";
import { flightService } from "./services/flightService";
import { aiService } from "./services/aiService";
import { messageService } from "./services/messageService";
import { eq } from 'drizzle-orm';
import { db } from './db';
import { users, type User } from '@shared/schema';
import { paymentService } from "./services/paymentService";
import { hotelService } from "./services/hotelService";

interface ChatMessage {
  type: 'message' | 'status' | 'userList';
  sender: string;
  content: string;
  timestamp: number;
  users?: Array<{ id: string; username: string; status: 'online' | 'away' }>;
}

interface ChatClient extends WebSocket {
  userId?: string;
  username?: string;
  status?: 'online' | 'away';
  lastActivity?: number;
}

export function registerRoutes(app: Express): Server {
  const httpServer = createServer(app);

  // Initialize WebSocket for chat
  const wss = new WebSocketServer({
    server: httpServer,
    path: '/ws/chat'
  });

  const clients = new Map<string, ChatClient>();

  // Function to broadcast user list to all clients
  function broadcastUserList() {
    const userList = Array.from(clients.values())
      .filter(client => client.userId && client.username)
      .map(client => ({
        id: client.userId!,
        username: client.username!,
        status: client.status || 'online'
      }));

    console.log('Broadcasting user list:', userList);

    const message: ChatMessage = {
      type: 'userList',
      sender: 'system',
      content: '',
      timestamp: Date.now(),
      users: userList
    };

    broadcastMessage(message);
  }

  // Function to broadcast message to all connected clients
  function broadcastMessage(message: ChatMessage) {
    const messageStr = JSON.stringify(message);
    console.log('Broadcasting message:', message);

    let successCount = 0;
    let failCount = 0;

    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        try {
          client.send(messageStr);
          successCount++;
        } catch (error) {
          console.error('Error sending message to client:', error);
          failCount++;
        }
      }
    });

    console.log(`Message broadcast results - Success: ${successCount}, Failed: ${failCount}`);
  }

  wss.on('connection', (ws: ChatClient) => {
    console.log('New chat client connected');

    ws.on('message', async (data: string) => {
      try {
        const message = JSON.parse(data);
        console.log('Received message:', message);

        switch (message.type) {
          case 'auth':
            if (!message.userId || !message.username) {
              console.error('Invalid auth message:', message);
              ws.send(JSON.stringify({
                type: 'error',
                content: 'Invalid authentication data'
              }));
              return;
            }

            // Associate the WebSocket connection with a user
            ws.userId = message.userId;
            ws.username = message.username;
            ws.status = 'online';
            clients.set(message.userId, ws);

            console.log('User authenticated:', {
              userId: message.userId,
              username: message.username,
              totalClients: clients.size
            });

            // Broadcast user list to all clients
            broadcastUserList();

            // Broadcast user joined status
            broadcastMessage({
              type: 'status',
              sender: 'system',
              content: `${message.username} joined the chat`,
              timestamp: Date.now()
            });
            break;

          case 'message':
            if (!ws.username || !ws.userId) {
              console.error('Unauthenticated message attempt');
              ws.send(JSON.stringify({
                type: 'error',
                content: 'Not authenticated'
              }));
              return;
            }

            // Broadcast the message to all connected clients
            broadcastMessage({
              type: 'message',
              sender: ws.username,
              content: message.content,
              timestamp: Date.now()
            });
            break;
        }
      } catch (error) {
        console.error('Error processing message:', error);
      }
    });

    ws.on('close', () => {
      if (ws.userId && ws.username) {
        console.log('User disconnected:', {
          userId: ws.userId,
          username: ws.username,
          remainingClients: clients.size - 1
        });

        clients.delete(ws.userId);

        broadcastMessage({
          type: 'status',
          sender: 'system',
          content: `${ws.username} left the chat`,
          timestamp: Date.now()
        });

        broadcastUserList();
      }
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
  });

  // Set up authentication routes that don't require database
  try {
    setupAuth(app);
  } catch (error) {
    console.error('Failed to setup authentication:', error);
    // Continue running the server even if auth setup fails
  }

  // Utility function to safely execute database operations
  const safeDbOperation = async <T>(operation: () => Promise<T>, fallback: T): Promise<T> => {
    try {
      return await operation();
    } catch (error) {
      console.error('Database operation failed:', error);
      return fallback;
    }
  };

  // Add a health check endpoint
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok" });
  });

  // Add session check endpoint
  app.get("/api/session", (req, res) => {
    res.json({
      authenticated: req.isAuthenticated(),
      user: req.user || null
    });
  });

  // Real flight service endpoints
  app.get("/api/flights/search", async (req, res) => {
    try {
      const { from, to, date, class: travelClass, passengers } = req.query;

      if (!from || !to || !date) {
        return res.status(400).json({
          message: 'Missing required parameters: from, to, and date are required'
        });
      }

      console.log('Flight search request:', { from, to, date, travelClass, passengers });

      const flights = await flightService.searchFlights({
        originLocationCode: from as string,
        destinationLocationCode: to as string,
        departureDate: date as string,
        travelClass: travelClass as string,
        adults: passengers ? parseInt(passengers as string) : 1,
      });

      res.json(flights);
    } catch (error) {
      console.error('Flight search error:', error);
      res.status(500).json({ message: 'Failed to search flights' });
    }
  });

  app.get("/api/airports/search", async (req, res) => {
    try {
      const { keyword } = req.query;
      if (!keyword) {
        return res.status(400).json({ message: 'Keyword is required' });
      }

      console.log('Airport search request:', { keyword });

      const airports = await flightService.getAirportsByKeyword(keyword as string);
      res.json(airports);
    } catch (error) {
      console.error('Airport search error:', error);
      res.status(500).json({ message: 'Failed to search airports' });
    }
  });

  // Personalized recommendations endpoint
  app.get("/api/recommendations", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const recommendations = await aiService.generateTravelRecommendations(req.user as User);
      res.json(recommendations);
    } catch (error) {
      console.error('Recommendations error:', error);
      res.status(500).json({ message: 'Failed to generate recommendations' });
    }
  });

  app.get("/api/local-experiences", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { location } = req.query;
      if (!location) {
        return res.status(400).json({ message: 'Location is required' });
      }

      const recommendations = await aiService.generateLocalExperiences(
        location as string,
        req.user as User
      );
      res.json(recommendations);
    } catch (error) {
      console.error('Local experiences error:', error);
      res.status(500).json({ message: 'Failed to generate local experience recommendations' });
    }
  });

  // Update user preferences
  app.post("/api/preferences", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const updatedUser = await safeDbOperation(
        async () => await db
          .update(users)
          .set({ preferences: req.body })
          .where(eq(users.id, (req.user as User).id))
          .returning(),
        []
      );

      res.json(updatedUser[0]);
    } catch (error) {
      console.error('Update preferences error:', error);
      res.status(500).json({ message: 'Failed to update preferences' });
    }
  });

  // Replace the /api/hotels endpoint with this implementation
  app.get("/api/hotels", async (req, res) => {
    try {
      const { location, rating, priceRange } = req.query;
      const hotels = await hotelService.searchHotels({
        location: location as string,
        rating: rating ? parseInt(rating as string) : undefined,
        priceRange: priceRange as string,
      });
      res.json(hotels);
    } catch (error) {
      console.error('Hotel search error:', error);
      // Fallback to mock data if real service fails
      const mockHotels = generateHotels(5);
      res.json(mockHotels);
    }
  });

  app.get("/api/rides", (_req, res) => {
    const rides = generateRides(5);
    res.json(rides);
  });

  app.get("/api/dining", (_req, res) => {
    const dining = generateDining(6);
    res.json(dining);
  });

  // Payment routes
  app.post("/api/payment/create-intent", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { amount, bookingType, metadata } = req.body;

      const paymentIntent = await paymentService.createPaymentIntent(
        amount,
        bookingType,
        metadata
      );

      res.json(paymentIntent);
    } catch (error) {
      console.error('Payment intent creation failed:', error);
      res.status(500).json({ message: 'Failed to create payment intent' });
    }
  });

  app.post("/api/payment/confirm/:paymentIntentId", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { paymentIntentId } = req.params;
      const result = await paymentService.confirmPayment(paymentIntentId);

      res.json(result);
    } catch (error) {
      console.error('Payment confirmation failed:', error);
      res.status(500).json({ message: 'Failed to confirm payment' });
    }
  });

  // Update the chatbot endpoint with better error handling and logging
  app.post("/api/chatbot", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        console.log('Unauthorized chat attempt');
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { message, chatHistory, currentLocation } = req.body;

      console.log('Chat request received:', {
        userId: (req.user as User)?.id,
        messageLength: message?.length,
        currentLocation,
        historyLength: chatHistory?.length
      });

      if (!message?.trim()) {
        return res.status(400).json({ message: 'Message is required' });
      }

      const response = await aiService.handleChatbotMessage(
        message,
        req.user as User,
        currentLocation,
        chatHistory
      );

      console.log('Chat response generated:', {
        userId: (req.user as User)?.id,
        responseType: response.type,
        hasResponse: !!response.message
      });

      res.json(response);
    } catch (error) {
      console.error('Chatbot error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to process chatbot request',
        error: process.env.NODE_ENV === 'development' ? error : undefined
      });
    }
  });

  // Add cultural insights endpoint
  app.post("/api/ai/cultural-insights", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { location } = req.body;
      console.log('Cultural insights request:', {
        userId: (req.user as User)?.id,
        location
      });

      if (!location) {
        return res.status(400).json({ message: 'Location is required' });
      }

      const insights = await aiService.getCulturalInsights(location);
      console.log('Cultural insights generated:', {
        userId: (req.user as User)?.id,
        location,
        hasInsights: !!insights
      });

      res.json({ insights });
    } catch (error) {
      console.error('Cultural insights error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to get cultural insights'
      });
    }
  });

  // Add new AI-driven booking routes
  app.post("/api/ai/smart-booking", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { destination, dates, preferences } = req.body;

      if (!destination || !dates) {
        return res.status(400).json({ message: 'Destination and dates are required' });
      }

      console.log('Smart booking request:', {
        userId: (req.user as User)?.id,
        destination,
        dates
      });

      const recommendations = await aiService.getSmartBookingRecommendations(
        destination,
        dates,
        preferences
      );

      res.json({ recommendations });
    } catch (error) {
      console.error('Smart booking error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to get booking recommendations'
      });
    }
  });

  app.post("/api/ai/travel-trends", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { destination } = req.body;

      if (!destination) {
        return res.status(400).json({ message: 'Destination is required' });
      }

      console.log('Travel trends request:', {
        userId: (req.user as User)?.id,
        destination
      });

      const trends = await aiService.analyzeTravelTrends(destination);
      res.json({ trends });
    } catch (error) {
      console.error('Travel trends error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to analyze travel trends'
      });
    }
  });

  // Add these routes before the graceful shutdown handler
  app.post("/api/ai/trip-plan", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { destination, dates, preferences } = req.body;

      if (!destination || !dates) {
        return res.status(400).json({ message: 'Destination and dates are required' });
      }

      console.log('Trip plan request:', {
        userId: (req.user as User)?.id,
        destination,
        dates
      });

      const plan = await aiService.generateDetailedTripPlan(
        destination,
        dates,
        preferences,
        req.user as User
      );

      // Get additional insights
      const insights = await aiService.generateTripInsights(destination, dates);

      res.json({
        plan,
        insights
      });
    } catch (error) {
      console.error('Trip planning error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to generate trip plan'
      });
    }
  });

  app.post("/api/ai/optimize-schedule", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { plan, constraints } = req.body;

      if (!plan) {
        return res.status(400).json({ message: 'Existing plan is required' });
      }

      console.log('Schedule optimization request:', {
        userId: (req.user as User)?.id,
        planId: plan.id
      });

      const optimizedPlan = await aiService.optimizeTripSchedule(plan, constraints);
      res.json({ plan: optimizedPlan });
    } catch (error) {
      console.error('Schedule optimization error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to optimize schedule'
      });
    }
  });

  app.post("/api/ai/activity-alternatives", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { activity, context } = req.body;

      if (!activity || !context) {
        return res.status(400).json({ message: 'Activity and context are required' });
      }

      console.log('Alternative activities request:', {
        userId: (req.user as User)?.id,
        activityId: activity.id
      });

      const alternatives = await aiService.suggestDynamicAlternatives(activity, context);
      res.json({ alternatives });
    } catch (error) {
      console.error('Activity alternatives error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to suggest alternatives'
      });
    }
  });

  app.post("/api/ai/analyze-behavior", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { searchHistory, bookingHistory } = req.body;
      console.log('Analyzing behavior for user:', (req.user as User)?.id);

      const analysis = await aiService.analyzeUserBehavior(
        req.user as User,
        searchHistory,
        bookingHistory
      );

      res.json({ analysis });
    } catch (error) {
      console.error('Behavior analysis error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to analyze behavior'
      });
    }
  });

  app.post("/api/ai/itinerary-optimization", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { itinerary, preferences } = req.body;
      if (!itinerary) {
        return res.status(400).json({ message: 'Itinerary is required' });
      }

      console.log('Itinerary optimization request:', {
        userId: (req.user as User)?.id,
        itineraryLength: itinerary.length
      });

      const optimization = await aiService.getItineraryOptimizations(itinerary, preferences);
      res.json({ optimization });
    } catch (error) {
      console.error('Itinerary optimization error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to optimize itinerary'
      });
    }
  });

  app.post("/api/ai/travel-guide", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { destination, duration } = req.body;
      if (!destination || !duration) {
        return res.status(400).json({ message: 'Destination and duration are required' });
      }

      console.log('Travel guide request:', {
        userId: (req.user as User)?.id,
        destination,
        duration
      });

      const guide = await aiService.getCustomizedTravelGuide(
        destination,
        (req.user as User).preferences,
        duration
      );
      res.json({ guide });
    } catch (error) {
      console.error('Travel guide error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to generate travel guide'
      });
    }
  });

  app.get("/api/ai/proactive-suggestions", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const user = req.user as User;
      console.log('Generating proactive suggestions for user:', user.id);

      // First analyze user behavior
      const analysis = await aiService.analyzeUserBehavior(
        user,
        [], // We'll implement search history tracking later
        []  // We'll implement booking history tracking later
      );

      // Generate suggestions based on the analysis and include local events
      const suggestions = await aiService.generateProactiveSuggestions(
        analysis,
        new Date().toISOString()
      );

      // For each suggestion, fetch relevant local events
      const enhancedSuggestions = await Promise.all(
        suggestions.map(async (suggestion) => {
          const events = await aiService.getLocalEvents(
            suggestion.destination,
            {
              start: new Date().toISOString(),
              end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // Next 30 days
            }
          );

          // Generate a personalized travel guide for each destination
          const guide = await aiService.getCustomizedTravelGuide(
            suggestion.destination,
            user.preferences,
            7 // Default to a week-long trip
          );

          // Analyze travel trends for the destination
          const trends = await aiService.analyzeTravelTrends(suggestion.destination);

          // Get smart booking recommendations
          const bookingOptions = await aiService.getSmartBookingRecommendations(
            suggestion.destination,
            {
              start: new Date().toISOString(),
              end: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
            },
            user.preferences
          );

          return {
            ...suggestion,
            events,
            guide,
            trends,
            bookingOptions
          };
        })
      );

      res.json({
        suggestions: enhancedSuggestions,
        userAnalysis: analysis
      });
    } catch (error) {
      console.error('Enhanced proactive suggestions error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to generate suggestions'
      });
    }
  });

  app.post("/api/ai/local-events", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: 'Unauthorized' });
      }

      const { location, dates } = req.body;

      if (!location || !dates) {
        return res.status(400).json({ message: 'Location and dates are required' });
      }

      const events = await aiService.getLocalEvents(location, dates);
      res.json({ events });
    } catch (error) {
      console.error('Local events error:', error);
      res.status(500).json({
        message: error instanceof Error ? error.message : 'Failed to fetch local events'
      });
    }
  });

  // Add a graceful shutdown handler
  function gracefulShutdown() {
    console.log('Starting graceful shutdown...');
    httpServer.close(() => {
      console.log('HTTP server closed');
      process.exit(0);
    });
  }

  // Handle process termination
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);

  return httpServer;
}

  }

export function setupLoggingEndpoint(app: Express): void {
  app.post("/api/log", (req, res) => {
    try {
      // Log client-side errors to server console
      console.error('Client-side error:', req.body);
      res.status(200).json({ success: true });
    } catch (error) {
      console.error('Error logging client error:', error);
      res.status(500).json({ success: false });
    }
  });
}
