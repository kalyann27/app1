
// Simple client-side error logging utility

interface ErrorLoggerOptions {
  capturePromiseRejections?: boolean;
  captureConsoleErrors?: boolean;
  logToServer?: boolean;
  serverEndpoint?: string;
}

export class ErrorLogger {
  private static instance: ErrorLogger;
  private options: ErrorLoggerOptions;
  private initialized: boolean = false;

  private constructor(options: ErrorLoggerOptions = {}) {
    this.options = {
      capturePromiseRejections: true,
      captureConsoleErrors: true,
      logToServer: false,
      serverEndpoint: '/api/log',
      ...options,
    };
  }

  public static getInstance(options?: ErrorLoggerOptions): ErrorLogger {
    if (!ErrorLogger.instance) {
      ErrorLogger.instance = new ErrorLogger(options);
    }
    return ErrorLogger.instance;
  }

  public init(): void {
    if (this.initialized) return;
    
    // Override console.error
    if (this.options.captureConsoleErrors) {
      const originalConsoleError = console.error;
      console.error = (...args) => {
        this.logError({
          source: 'console.error',
          message: args.map(arg => 
            typeof arg === 'object' ? JSON.stringify(arg) : String(arg)
          ).join(' '),
          timestamp: new Date().toISOString()
        });
        originalConsoleError.apply(console, args);
      };
    }

    // Capture unhandled promise rejections
    if (this.options.capturePromiseRejections) {
      window.addEventListener('unhandledrejection', (event) => {
        this.logError({
          source: 'unhandledRejection',
          message: event.reason?.message || String(event.reason) || 'Unknown promise rejection',
          stack: event.reason?.stack,
          timestamp: new Date().toISOString()
        });
      });
    }

    // Capture global errors
    window.addEventListener('error', (event) => {
      this.logError({
        source: 'window.onerror',
        message: event.message,
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
        stack: event.error?.stack,
        timestamp: new Date().toISOString()
      });
    });

    this.initialized = true;
  }

  private logError(errorData: any): void {
    // Add to local storage for debugging
    const errors = JSON.parse(localStorage.getItem('app_errors') || '[]');
    errors.push(errorData);
    
    // Keep only the last 50 errors
    while (errors.length > 50) errors.shift();
    
    localStorage.setItem('app_errors', JSON.stringify(errors));
    
    // Send to server if enabled
    if (this.options.logToServer) {
      try {
        fetch(this.options.serverEndpoint!, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(errorData),
          credentials: 'include'
        }).catch(e => {
          // Silently fail to avoid infinite loops
        });
      } catch (e) {
        // Ignore fetch errors to prevent loops
      }
    }
  }

  public getStoredErrors(): any[] {
    return JSON.parse(localStorage.getItem('app_errors') || '[]');
  }

  public clearStoredErrors(): void {
    localStorage.removeItem('app_errors');
  }
}

// Initialize the global error logger
const errorLogger = ErrorLogger.getInstance();
errorLogger.init();

export default errorLogger;
