/**
 * Utility function for making API requests
 */
export async function apiRequest(
  method: string,
  endpoint: string,
  body?: any
): Promise<Response> {
  const response = await fetch(endpoint, {
    method,
    headers: {
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
    credentials: "include",
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(error || response.statusText);
  }

  return response;
}
