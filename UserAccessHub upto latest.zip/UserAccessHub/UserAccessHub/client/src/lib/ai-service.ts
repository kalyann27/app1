import { apiRequest } from './api';
import { User, FlightBooking, HotelBooking } from '@shared/schema';

// Add new booking-related interfaces
export interface BookingRecommendation {
  type: 'flight' | 'hotel' | 'package';
  destination: string;
  startDate: string;
  endDate: string;
  price: number;
  confidence: number;
  reason: string;
  flightDetails?: {
    airline: string;
    stops: number;
    duration: string;
    departureTime: string;
    arrivalTime: string;
  };
  hotelDetails?: {
    name: string;
    rating: number;
    amenities: string[];
    location: string;
  };
}

// Rest of the interfaces remain unchanged
export interface TravelRecommendation {
  destination: string;
  reason: string;
  bestTimeToVisit: string;
  estimatedBudget: number;
  activities: string[];
  confidence: number;
  bookingOptions?: BookingRecommendation[];
}

export interface TravelPreferences {
  flight: {
    seatPreference: 'window' | 'aisle' | 'any';
    cabinClass: 'economy' | 'premium_economy' | 'business' | 'first';
    mealPreference: string[];
    airlines: string[];
    maxLayovers: number;
  };
  hotel: {
    roomType: string[];
    amenities: string[];
    location: string[];
    priceRange: { min: number; max: number };
    starRating: number;
  };
  ride: {
    vehicleType: string[];
    maxPrice: number;
    preferredProviders: string[];
    accessibility: string[];
  };
}

export interface PricePrediction {
  trend: "rising" | "falling" | "stable";
  confidence: number;
  bestTimeToBook: string;
  predictedLowestPrice: number;
  priceRange: {
    min: number;
    max: number;
  };
}

export interface BudgetPrediction {
  monthlySpending: Array<{
    month: string;
    predicted: number;
    actual?: number;
  }>;
  recommendations: string[];
  savingsPotential: number;
  riskFactors: string[];
}

interface BudgetPredictionParams {
  destination: string;
  duration: number;
  budget: number;
}

export interface CulturalContext {
  customs: string[];
  etiquette: string[];
  localTips: string[];
  significance: string;
  doAndDonts: {
    do: string[];
    dont: string[];
  };
}

export interface ChatbotResponse {
  message: string;
  type: "general" | "cultural" | "recommendation" | "translation";
  culturalContext?: CulturalContext;
}

export interface LocalEvent {
  name: string;
  type: 'sport' | 'cultural' | 'entertainment';
  date: string;
  venue: string;
  description: string;
  ticketPrice?: number;
  category: string;
}

export interface ProactiveSuggestion {
  destination: string;
  reason: string;
  timing: string;
  confidence: number;
  estimatedBudget: number;
  activities: string[];
  weatherPrediction: string;
  localEvents: LocalEvent[];
  popularAttractions: string[];
  seasonalHighlights: string[];
  eventHighlight?: {
    name: string;
    date: string;
    type: string;
    description: string;
    significance: string;
  };
}

class AIService {
  async getPersonalizedRecommendations(
    user: User,
    pastBookings: (FlightBooking | HotelBooking)[]
  ): Promise<TravelRecommendation[]> {
    const response = await apiRequest('POST', '/api/ai/recommendations', {
      userPreferences: user.preferences,
      pastBookings,
    });

    if (!response.ok) {
      throw new Error('Failed to get travel recommendations');
    }

    const data = await response.json();
    return data.recommendations;
  }

  async predictPrices(
    origin: string,
    destination: string,
    date: string,
    preferences?: TravelPreferences
  ): Promise<PricePrediction> {
    const response = await apiRequest('POST', '/api/ai/predict-prices', {
      origin,
      destination,
      date,
      preferences,
    });

    if (!response.ok) {
      throw new Error('Price prediction failed');
    }

    const data = await response.json();
    return data.prediction;
  }

  async generateTravelTips(
    destination: string,
    travelDates: { start: string; end: string },
    preferences: TravelPreferences
  ): Promise<string[]> {
    const response = await apiRequest('POST', '/api/ai/travel-tips', {
      destination,
      travelDates,
      preferences,
    });

    if (!response.ok) {
      throw new Error('Failed to generate travel tips');
    }

    const data = await response.json();
    return data.tips;
  }

  async optimizeItinerary(
    bookings: (FlightBooking | HotelBooking)[],
    preferences: TravelPreferences
  ): Promise<{
    optimizedBookings: (FlightBooking | HotelBooking)[];
    suggestedChanges: string[];
    potentialSavings: number;
  }> {
    const response = await apiRequest('POST', '/api/ai/optimize-itinerary', {
      bookings,
      preferences,
    });

    if (!response.ok) {
      throw new Error('Itinerary optimization failed');
    }

    const data = await response.json();
    return data.optimization;
  }

  async translateText(text: string, targetLanguage: string): Promise<string> {
    const response = await apiRequest('POST', '/api/translate', {
      text,
      targetLanguage,
    });

    if (!response.ok) {
      throw new Error('Translation failed');
    }

    const data = await response.json();
    return data.translation;
  }

  async analyzeSentiment(feedback: string): Promise<{
    sentiment: "positive" | "negative" | "neutral";
    score: number;
    keyTopics: string[];
  }> {
    const response = await apiRequest('POST', '/api/ai/analyze-sentiment', {
      feedback,
    });

    if (!response.ok) {
      throw new Error('Sentiment analysis failed');
    }

    const data = await response.json();
    return data.analysis;
  }

  async predictBudget(params: BudgetPredictionParams): Promise<BudgetPrediction> {
    const response = await apiRequest('POST', '/api/ai/predict-budget', {
      ...params,
      timestamp: new Date().toISOString(),
      currency: 'USD',
    });

    if (!response.ok) {
      throw new Error('Budget prediction failed');
    }

    const data = await response.json();
    return data.prediction;
  }

  async getChatbotResponse(
    message: string,
    currentLocation?: string,
    chatHistory?: Array<{ role: "user" | "assistant"; content: string }>,
    preferences?: TravelPreferences
  ): Promise<ChatbotResponse> {
    try {
      const response = await apiRequest('POST', '/api/ai/chat', {
        message,
        currentLocation,
        chatHistory,
        preferences,
        timestamp: new Date().toISOString(),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to get chatbot response');
      }

      const data = await response.json();
      return data.response;
    } catch (error) {
      console.error('Chatbot error:', error);
      throw new Error(error instanceof Error ? error.message : 'Failed to get response from AI');
    }
  }

  async getCulturalInsights(location: string): Promise<CulturalContext> {
    try {
      const response = await apiRequest('POST', '/api/ai/cultural-insights', {
        location,
        timestamp: new Date().toISOString(),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to get cultural insights');
      }

      const data = await response.json();
      return data.insights;
    } catch (error) {
      console.error('Cultural insights error:', error);
      throw new Error(error instanceof Error ? error.message : 'Failed to get cultural insights');
    }
  }

  async getProactiveSuggestions(): Promise<ProactiveSuggestion[]> {
    const response = await apiRequest('GET', '/api/ai/proactive-suggestions');

    if (!response.ok) {
      throw new Error('Failed to get proactive suggestions');
    }

    const data = await response.json();
    return data.suggestions;
  }

  async getLocalEvents(location: string, dates: { start: string; end: string }): Promise<LocalEvent[]> {
    const response = await apiRequest('POST', '/api/ai/local-events', {
      location,
      dates,
    });

    if (!response.ok) {
      throw new Error('Failed to get local events');
    }

    const data = await response.json();
    return data.events;
  }

  async getSmartBookingRecommendations(
    destination: string,
    dates: { start: string; end: string },
    preferences: TravelPreferences
  ): Promise<BookingRecommendation[]> {
    const response = await apiRequest('POST', '/api/ai/smart-booking', {
      destination,
      dates,
      preferences,
    });

    if (!response.ok) {
      throw new Error('Failed to get smart booking recommendations');
    }

    const data = await response.json();
    return data.recommendations;
  }

  async analyzeTravelTrends(destination: string): Promise<{
    bestTimeToBook: string;
    priceHistory: Array<{ date: string; price: number }>;
    pricePrediction: {
      nextWeek: number;
      nextMonth: number;
      trend: 'rising' | 'falling' | 'stable';
    };
  }> {
    const response = await apiRequest('POST', '/api/ai/travel-trends', {
      destination,
      timestamp: new Date().toISOString(),
    });

    if (!response.ok) {
      throw new Error('Failed to analyze travel trends');
    }

    const data = await response.json();
    return data.trends;
  }
}

export const aiService = new AIService();