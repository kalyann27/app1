import { Button } from "./button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "./form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./select";
import { Input } from "./input";
import { Separator } from "./separator";
import { Switch } from "./switch";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import type { TravelPreferences } from "@/lib/ai-service";
import { Plane, Hotel, Car, Settings2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const travelPreferencesSchema = z.object({
  flight: z.object({
    seatPreference: z.enum(["window", "aisle", "any"]),
    cabinClass: z.enum(["economy", "premium_economy", "business", "first"]),
    mealPreference: z.array(z.string()),
    airlines: z.array(z.string()),
    maxLayovers: z.number().min(0).max(5),
  }),
  hotel: z.object({
    roomType: z.array(z.string()),
    amenities: z.array(z.string()),
    location: z.array(z.string()),
    priceRange: z.object({
      min: z.number().min(0),
      max: z.number().min(0),
    }),
    starRating: z.number().min(1).max(5),
  }),
  ride: z.object({
    vehicleType: z.array(z.string()),
    maxPrice: z.number().min(0),
    preferredProviders: z.array(z.string()),
    accessibility: z.array(z.string()),
  }),
});

interface TravelPreferencesProps {
  preferences: TravelPreferences;
  onUpdate: (preferences: TravelPreferences) => void;
}

export function TravelPreferencesDialog({ preferences, onUpdate }: TravelPreferencesProps) {
  const { toast } = useToast();
  const form = useForm<TravelPreferences>({
    resolver: zodResolver(travelPreferencesSchema),
    defaultValues: preferences,
  });

  const onSubmit = (data: TravelPreferences) => {
    onUpdate(data);
    toast({
      title: "Preferences Updated",
      description: "Your travel preferences have been saved successfully.",
    });
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="icon">
          <Settings2 className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Travel Preferences</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Flight Preferences */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Plane className="h-5 w-5" />
                <h3 className="text-lg font-medium">Flight Preferences</h3>
              </div>
              <FormField
                control={form.control}
                name="flight.seatPreference"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Seat Preference</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select seat preference" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="window">Window</SelectItem>
                        <SelectItem value="aisle">Aisle</SelectItem>
                        <SelectItem value="any">No Preference</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="flight.cabinClass"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Cabin Class</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select cabin class" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="economy">Economy</SelectItem>
                        <SelectItem value="premium_economy">Premium Economy</SelectItem>
                        <SelectItem value="business">Business</SelectItem>
                        <SelectItem value="first">First Class</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
            </div>

            <Separator />

            {/* Hotel Preferences */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Hotel className="h-5 w-5" />
                <h3 className="text-lg font-medium">Hotel Preferences</h3>
              </div>
              <FormField
                control={form.control}
                name="hotel.starRating"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Minimum Star Rating</FormLabel>
                    <Select onValueChange={(value) => field.onChange(parseInt(value))} defaultValue={field.value.toString()}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select minimum rating" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {[1, 2, 3, 4, 5].map((rating) => (
                          <SelectItem key={rating} value={rating.toString()}>
                            {rating} Star{rating > 1 ? "s" : ""}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="hotel.priceRange.max"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Maximum Price per Night ($)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>

            <Separator />

            {/* Ride Preferences */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Car className="h-5 w-5" />
                <h3 className="text-lg font-medium">Ride Preferences</h3>
              </div>
              <FormField
                control={form.control}
                name="ride.maxPrice"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Maximum Price per Ride ($)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="ride.vehicleType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Preferred Vehicle Types</FormLabel>
                    <Select
                      onValueChange={(value) => field.onChange([...field.value, value])}
                      value={field.value[0]}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select vehicle types" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="standard">Standard</SelectItem>
                        <SelectItem value="suv">SUV</SelectItem>
                        <SelectItem value="luxury">Luxury</SelectItem>
                        <SelectItem value="electric">Electric</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
            </div>

            <Button type="submit" className="w-full">
              Save Preferences
            </Button>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
