import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Smile } from 'lucide-react';
import { apiRequest } from '@/lib/api';
import { useToast } from '@/hooks/use-toast';

interface EmojiReactionProps {
  itemId: string;
  onReact?: (emoji: string) => void;
  initialReactions?: { [key: string]: number };
}

const travelEmojis = [
  { emoji: '✈️', name: 'airplane' },
  { emoji: '🏖️', name: 'beach' },
  { emoji: '🗺️', name: 'map' },
  { emoji: '🌅', name: 'sunset' },
  { emoji: '🎒', name: 'backpack' },
  { emoji: '🏔️', name: 'mountain' },
  { emoji: '🚗', name: 'car' },
  { emoji: '⛴️', name: 'ferry' },
  { emoji: '🍜', name: 'food' },
  { emoji: '📸', name: 'camera' },
];

export function EmojiReaction({ itemId, onReact, initialReactions = {} }: EmojiReactionProps) {
  const [reactions, setReactions] = useState<{ [key: string]: number }>(initialReactions);
  const [recentReaction, setRecentReaction] = useState<string | null>(null);
  const { toast } = useToast();

  const handleReaction = async (emoji: string) => {
    try {
      const response = await apiRequest('POST', `/api/hotels/${itemId}/react`, { emoji });

      if (!response.ok) {
        throw new Error('Failed to update reaction');
      }

      const data = await response.json();
      setReactions(data.reactions);
      setRecentReaction(emoji);
      onReact?.(emoji);

      // Reset recent reaction after animation
      setTimeout(() => setRecentReaction(null), 1000);
    } catch (error) {
      console.error('Reaction error:', error);
      toast({
        title: "Reaction Failed",
        description: "Failed to update reaction. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="relative inline-flex items-center gap-2">
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="outline" size="icon" className="relative">
            <Smile className="h-4 w-4" />
            {Object.keys(reactions).length > 0 && (
              <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground rounded-full w-4 h-4 text-xs flex items-center justify-center">
                {Object.values(reactions).reduce((a, b) => a + b, 0)}
              </span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[200px] p-2">
          <div className="grid grid-cols-5 gap-1">
            {travelEmojis.map(({ emoji, name }) => (
              <Button
                key={emoji}
                variant="ghost"
                className="h-8 w-8 p-0 hover:bg-muted"
                onClick={() => handleReaction(emoji)}
                title={name}
              >
                {emoji}
              </Button>
            ))}
          </div>
        </PopoverContent>
      </Popover>

      <div className="flex gap-1">
        {Object.entries(reactions).map(([emoji, count]) => (
          <div
            key={emoji}
            className="bg-muted rounded-full px-2 py-1 text-sm flex items-center gap-1"
          >
            <span>{emoji}</span>
            <span className="text-muted-foreground">{count}</span>
          </div>
        ))}
      </div>

      <AnimatePresence>
        {recentReaction && (
          <motion.div
            initial={{ scale: 0.5, y: 0, opacity: 0 }}
            animate={{ scale: 1.5, y: -20, opacity: 1 }}
            exit={{ scale: 0.5, y: -40, opacity: 0 }}
            className="absolute -top-4 left-1/2 transform -translate-x-1/2"
          >
            {recentReaction}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}