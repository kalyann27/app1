import { Globe, Plane } from "lucide-react";
import { cn } from "@/lib/utils";

interface LogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
  showText?: boolean;
}

export function Logo({ 
  className, 
  size = "md", 
  showText = true 
}: LogoProps) {
  const sizes = {
    sm: "h-5 w-5 sm:h-6 sm:w-6",
    md: "h-6 w-6 sm:h-8 sm:w-8",
    lg: "h-8 w-8 sm:h-10 sm:w-10"
  };

  const textSizes = {
    sm: "text-base sm:text-lg",
    md: "text-lg sm:text-xl",
    lg: "text-xl sm:text-2xl"
  };

  return (
    <div className={cn("flex items-center gap-1.5 sm:gap-2", className)}>
      <div className="relative flex items-center">
        <Globe 
          className={cn(
            sizes[size],
            "text-blue-500 animate-spin-slow absolute"
          )} 
        />
        <Plane 
          className={cn(
            sizes[size],
            "text-red-500 animate-pulse"
          )}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/30 via-purple-500/20 to-red-500/30 rounded-full blur-lg" />
      </div>
      {showText && (
        <span className={cn(
          textSizes[size],
          "font-bold tracking-tight",
          "bg-gradient-to-r from-blue-500 via-purple-500 to-red-500",
          "bg-clip-text text-transparent",
          "drop-shadow-sm"
        )}>
          AItravelGlobe
        </span>
      )}
    </div>
  );
}