import { Card, CardContent } from "./card";
import { Button } from "./button";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "./skeleton";
import { Link } from "wouter";

interface Destination {
  id: string;
  name: string;
  type: 'domestic' | 'international' | 'region' | 'country';
  image: string;
  description: string;
  rating: number;
  priceRange: string;
  propertyCount: number;
}

const POPULAR_DESTINATIONS: Destination[] = [
  {
    id: "nyc",
    name: "New York City",
    type: "domestic",
    image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9",
    description: "The city that never sleeps",
    rating: 4.5,
    priceRange: "$$$",
    propertyCount: 1234
  },
  {
    id: "paris",
    name: "Paris",
    type: "international",
    image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34",
    description: "The city of love",
    rating: 4.7,
    priceRange: "$$$",
    propertyCount: 2345
  },
  // Add more destinations here
];

export function PopularDestinations() {
  const { data: destinations, isLoading } = useQuery({
    queryKey: ["/api/destinations/popular"],
    initialData: POPULAR_DESTINATIONS,
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <Card key={i} className="overflow-hidden">
            <Skeleton className="h-48" />
            <CardContent className="p-4">
              <Skeleton className="h-6 w-3/4 mb-2" />
              <Skeleton className="h-4 w-1/2" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const groupedDestinations = {
    domestic: destinations.filter(d => d.type === 'domestic'),
    international: destinations.filter(d => d.type === 'international'),
    regions: destinations.filter(d => d.type === 'region'),
    countries: destinations.filter(d => d.type === 'country')
  };

  return (
    <div className="space-y-8">
      {Object.entries(groupedDestinations).map(([category, items]) => (
        <section key={category} className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold capitalize">
              {category.replace('_', ' ')}
            </h2>
            <Button variant="ghost" asChild>
              <Link href={`/destinations/${category}`}>
                View all
              </Link>
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {items.map((destination) => (
              <Link key={destination.id} href={`/destinations/${destination.id}`}>
                <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group">
                  <div 
                    className="h-48 bg-cover bg-center relative"
                    style={{ 
                      backgroundImage: `url(${destination.image}?auto=format&fit=crop&w=800&q=60)`
                    }}
                  >
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors" />
                    <div className="absolute bottom-0 left-0 right-0 p-4 text-white bg-gradient-to-t from-black/60">
                      <h3 className="text-xl font-semibold">{destination.name}</h3>
                      <p className="text-sm text-white/90">{destination.description}</p>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="text-sm text-muted-foreground">
                        {destination.propertyCount.toLocaleString()} properties
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-sm font-medium">{destination.rating}</span>
                        <span className="text-yellow-400">★</span>
                      </div>
                    </div>
                    <div className="mt-2 text-sm font-medium">
                      From {destination.priceRange} per night
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
