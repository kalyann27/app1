import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "./card";
import { Button } from "./button";
import { Badge } from "./badge";
import { aiService, type ProactiveSuggestion, type LocalEvent } from "@/lib/ai-service";
import { Calendar as CalendarIcon, MapPin, Sun, Users, Coins, Trophy, Music, Ticket } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { generateProactiveSuggestions } from "@shared/mockData";
import { useLocation } from "wouter";

function EventTypeIcon({ type }: { type: LocalEvent['type'] }) {
  switch (type) {
    case 'sport':
      return <Trophy className="w-4 h-4 text-green-500" />;
    case 'cultural':
      return <Music className="w-4 h-4 text-purple-500" />;
    case 'entertainment':
      return <Ticket className="w-4 h-4 text-blue-500" />;
    default:
      return <Ticket className="w-4 h-4 text-gray-500" />;
  }
}

export function ProactiveSuggestions() {
  const [, setLocation] = useLocation();
  const { data: suggestions = [], isLoading, isError } = useQuery({
    queryKey: ["/api/ai/proactive-suggestions"],
    queryFn: async () => {
      try {
        return await aiService.getProactiveSuggestions();
      } catch (error) {
        console.log('Using mock data due to API error:', error);
        return generateProactiveSuggestions(3);
      }
    },
    refetchInterval: 1000 * 60 * 30, // Refetch every 30 minutes
  });

  const handleExploreDestination = (suggestion: ProactiveSuggestion) => {
    const params = new URLSearchParams({
      destination: suggestion.destination,
      timing: suggestion.timing,
      budget: suggestion.estimatedBudget.toString(),
      events: suggestion.localEvents.map(e => e.id).join(',')
    });

    setLocation(`/destinations/${encodeURIComponent(suggestion.destination)}?${params.toString()}`);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="space-y-4">
            {[1, 2].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <AnimatePresence>
      {suggestions.map((suggestion, index) => (
        <motion.div
          key={`${suggestion.destination}-${index}`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3, delay: index * 0.1 }}
        >
          <Card className={`mb-4 overflow-hidden border-2 hover:border-[#003580] transition-all duration-300 card-gradient-${(index % 4) + 1}`}>
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-semibold text-[#003580] mb-2">
                    {suggestion.destination}
                  </h3>
                  <p className="text-gray-600">{suggestion.reason}</p>
                </div>
                <Badge 
                  variant={suggestion.confidence > 0.7 ? "default" : "secondary"}
                  className="ml-2"
                >
                  {Math.round(suggestion.confidence * 100)}% Match
                </Badge>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="flex items-center gap-2">
                  <CalendarIcon className="w-4 h-4 text-[#003580]" />
                  <span className="text-sm">{suggestion.timing}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Sun className="w-4 h-4 text-[#003580]" />
                  <span className="text-sm">{suggestion.weatherPrediction}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Coins className="w-4 h-4 text-[#003580]" />
                  <span className="text-sm">${suggestion.estimatedBudget}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-[#003580]" />
                  <span className="text-sm">{suggestion.activities.length} Activities</span>
                </div>
              </div>

              {suggestion.eventHighlight && (
                <div className="bg-blue-50 rounded-lg p-4 mb-6">
                  <h4 className="font-medium text-[#003580] mb-2">Featured Event</h4>
                  <div className="space-y-2">
                    <p className="font-medium">{suggestion.eventHighlight.name}</p>
                    <p className="text-sm text-gray-600">{suggestion.eventHighlight.description}</p>
                    <div className="flex items-center gap-2 text-sm">
                      <CalendarIcon className="w-4 h-4" />
                      <span>{suggestion.eventHighlight.date}</span>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                <h4 className="font-medium mb-2">Local Events</h4>
                <div className="grid gap-3">
                  {suggestion.localEvents.map((event, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                      <EventTypeIcon type={event.type} />
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <p className="font-medium">{event.name}</p>
                          {event.ticketPrice && (
                            <Badge variant="outline" className="ml-2">
                              ${event.ticketPrice}
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{event.description}</p>
                        <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                          <div className="flex items-center gap-1">
                            <CalendarIcon className="w-3 h-3" />
                            <span>{format(new Date(event.date), 'MMM d, yyyy')}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            <span>{event.venue}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 flex justify-end">
                <Button 
                  className="bg-[#003580] hover:bg-[#002255]"
                  onClick={() => handleExploreDestination(suggestion)}
                >
                  Explore This Destination
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </AnimatePresence>
  );
}