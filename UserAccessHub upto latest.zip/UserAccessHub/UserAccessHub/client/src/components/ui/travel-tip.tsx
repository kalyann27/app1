import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lightbulb } from 'lucide-react';
import { Badge } from "@/components/ui/badge";

interface TravelTipProps {
  context: 'flight' | 'hotel' | 'budget' | 'weather' | 'local';
  trigger?: 'hover' | 'click' | 'auto';
  position?: 'top' | 'bottom' | 'left' | 'right';
  children: React.ReactNode;
}

const tips = {
  flight: [
    "Book flights on Tuesday afternoons for best deals",
    "Clear your browser cookies before searching for flights",
    "Consider nearby airports for better prices"
  ],
  hotel: [
    "Email the hotel directly for potential upgrades",
    "Join loyalty programs for extra perks",
    "Check reviews from multiple platforms"
  ],
  budget: [
    "Set aside 10% of your budget for unexpected expenses",
    "Use local transport apps for better rates",
    "Look for free walking tours at your destination"
  ],
  weather: [
    "Pack a lightweight rain jacket just in case",
    "Check historical weather data for your dates",
    "Download offline weather forecasts"
  ],
  local: [
    "Learn basic phrases in the local language",
    "Save offline maps for your destination",
    "Research local customs and etiquette"
  ]
};

export function TravelTip({ context, trigger = 'hover', position = 'top', children }: TravelTipProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [currentTip, setCurrentTip] = useState('');

  useEffect(() => {
    if (trigger === 'auto') {
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [trigger]);

  useEffect(() => {
    if (context && tips[context]) {
      const randomTip = tips[context][Math.floor(Math.random() * tips[context].length)];
      setCurrentTip(randomTip);
    }
  }, [context]);

  const handleInteraction = () => {
    if (trigger === 'click') {
      setIsVisible(!isVisible);
    }
  };

  return (
    <div 
      className="relative inline-block"
      onMouseEnter={() => trigger === 'hover' && setIsVisible(true)}
      onMouseLeave={() => trigger === 'hover' && setIsVisible(false)}
      onClick={handleInteraction}
    >
      {children}
      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ opacity: 0, y: position === 'top' ? 10 : -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: position === 'top' ? 10 : -10 }}
            className={`
              absolute z-50 w-64 p-3 rounded-lg shadow-lg
              bg-card border border-border
              ${position === 'top' ? 'bottom-full mb-2' : 'top-full mt-2'}
              ${position === 'left' ? 'right-full mr-2' : ''}
              ${position === 'right' ? 'left-full ml-2' : ''}
            `}
          >
            <div className="flex items-start space-x-2">
              <Lightbulb className="w-4 h-4 text-primary mt-1 flex-shrink-0" />
              <div className="flex-1">
                <Badge variant="outline" className="mb-1">Travel Tip</Badge>
                <p className="text-sm text-muted-foreground">{currentTip}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
