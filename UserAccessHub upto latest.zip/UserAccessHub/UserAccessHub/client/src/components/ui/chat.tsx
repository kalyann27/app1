import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { Send, X, Users } from 'lucide-react';
import { Button } from './button';
import { Card, CardContent, CardHeader, CardTitle } from './card';
import { Input } from './input';
import { ScrollArea } from './scroll-area';
import { motion, AnimatePresence } from 'framer-motion';
import { Separator } from './separator';

interface Message {
  type: 'message' | 'status' | 'userList';
  sender: string;
  content: string;
  timestamp: number;
  users?: Array<{ id: string; username: string; status: 'online' | 'away' }>;
}

interface ConnectedUser {
  id: string;
  username: string;
  status: 'online' | 'away';
}

interface ChatProps {
  onClose?: () => void;
}

export function Chat({ onClose }: ChatProps) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [connectedUsers, setConnectedUsers] = useState<ConnectedUser[]>([]);
  const [showUserList, setShowUserList] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    if (!user?.id || !user?.username) {
      console.log('No user data available for chat:', user);
      return;
    }

    const connectWebSocket = () => {
      try {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/ws/chat`;
        console.log('Attempting WebSocket connection:', wsUrl);

        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          console.log('WebSocket connected, sending auth message for user:', {
            id: user.id,
            username: user.username
          });
          setIsConnected(true);

          const authMessage = {
            type: 'auth',
            userId: user.id,
            username: user.username
          };
          ws.send(JSON.stringify(authMessage));
        };

        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            console.log('Received WebSocket message:', data);

            if (data.type === 'userList' && Array.isArray(data.users)) {
              console.log('Updating connected users list:', data.users);
              setConnectedUsers(data.users);
            } else if (data.type === 'error') {
              console.error('WebSocket error:', data.content);
            } else {
              setMessages(prev => [...prev, data]);
              if (scrollRef.current) {
                scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
              }
            }
          } catch (error) {
            console.error('Error processing WebSocket message:', error);
          }
        };

        ws.onclose = () => {
          console.log('WebSocket disconnected');
          setIsConnected(false);
          reconnectTimeoutRef.current = setTimeout(connectWebSocket, 3000);
        };

        ws.onerror = (error) => {
          console.error('WebSocket error:', error);
          setIsConnected(false);
        };
      } catch (error) {
        console.error('Error setting up WebSocket:', error);
      }
    };

    console.log('Initiating WebSocket connection for user:', {
      id: user.id,
      username: user.username
    });
    connectWebSocket();

    return () => {
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.close();
      }
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [user]);

  const sendMessage = () => {
    if (!input.trim() || !wsRef.current || !isConnected || !user?.username) return;

    const messageToSend = {
      type: 'message',
      sender: user.username,
      content: input.trim(),
      timestamp: Date.now()
    };

    console.log('Sending chat message:', messageToSend);
    wsRef.current.send(JSON.stringify(messageToSend));
    setInput('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed bottom-24 left-6 w-96 shadow-2xl"
    >
      <Card className="overflow-hidden">
        <CardHeader className="p-4 flex flex-row items-center justify-between space-y-0 border-b bg-[#003580] text-white">
          <div className="flex items-center gap-2">
            <CardTitle className="text-lg font-semibold">Travel Chat</CardTitle>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-white hover:text-white/80 relative"
              onClick={() => setShowUserList(!showUserList)}
            >
              <Users className="h-4 w-4" />
              {connectedUsers.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-green-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                  {connectedUsers.length}
                </span>
              )}
            </Button>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-white hover:text-white/80"
            onClick={onClose}
          >
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>

        <CardContent className="p-0 relative">
          {/* User List Panel */}
          <AnimatePresence>
            {showUserList && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="absolute top-0 left-0 w-full bg-white border-b z-10 shadow-md"
              >
                <div className="p-4">
                  <h3 className="font-medium mb-2 flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Online Users ({connectedUsers.length})
                  </h3>
                  <div className="space-y-2">
                    {connectedUsers.map((connectedUser) => (
                      <div key={connectedUser.id} className="flex items-center gap-2 p-2 hover:bg-gray-50 rounded-lg">
                        <div className={`w-2 h-2 rounded-full ${connectedUser.status === 'online' ? 'bg-green-500' : 'bg-yellow-500'}`} />
                        <span className="text-sm font-medium">{connectedUser.username}</span>
                        <span className="text-xs text-gray-500 ml-auto">
                          {connectedUser.status === 'away' ? 'Away' : 'Online'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Chat Messages */}
          <ScrollArea className="h-[400px] p-4" ref={scrollRef}>
            <AnimatePresence>
              {messages.map((message, index) => (
                <motion.div
                  key={`${message.timestamp}-${index}`}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className={`mb-4 ${message.type === 'status' ? 'text-center' : ''}`}
                >
                  {message.type === 'status' ? (
                    <p className="text-sm text-gray-500">{message.content}</p>
                  ) : (
                    <div className={`flex flex-col ${message.sender === user?.username ? 'items-end' : 'items-start'}`}>
                      <div className={`max-w-[80%] rounded-lg p-3 ${
                        message.sender === user?.username
                          ? 'bg-[#003580] text-white'
                          : 'bg-gray-100'
                      }`}>
                        <p className="text-xs font-medium mb-1">{message.sender}</p>
                        <p className="text-sm break-words">{message.content}</p>
                      </div>
                      <span className="text-xs text-gray-500 mt-1">
                        {new Date(message.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          </ScrollArea>

          {/* Message Input */}
          <div className="p-4 border-t">
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type a message..."
                className="flex-1"
                disabled={!isConnected}
              />
              <Button
                onClick={sendMessage}
                disabled={!isConnected || !input.trim()}
                size="icon"
                className="bg-[#003580] hover:bg-[#002255]"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            {!isConnected && (
              <p className="text-xs text-red-500 mt-2">
                Disconnected. Trying to reconnect...
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}