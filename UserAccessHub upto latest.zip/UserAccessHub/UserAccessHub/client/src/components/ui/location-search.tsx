import { useState, useEffect } from "react";
import { Input } from "./input";
import { MapPin, Globe, Clock, TrendingUp } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "./card";

export type Location = {
  city: string;
  country: string;
  region?: string;
  popularity?: number;
  imageUrl?: string;
  airports?: string[];
};

interface LocationSearchProps {
  onLocationSelect: (location: Location) => void;
  placeholder?: string;
  className?: string;
}

// Trending destinations with images
const trendingDestinations: Location[] = [
  {
    city: "Paris",
    country: "France",
    region: "Europe",
    popularity: 98,
    imageUrl: "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?auto=format&fit=crop&q=80&w=2070",
  },
  {
    city: "Tokyo",
    country: "Japan",
    region: "Asia",
    popularity: 95,
    imageUrl: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&q=80&w=2070",
  },
  {
    city: "Dubai",
    country: "UAE",
    region: "Middle East",
    popularity: 92,
    imageUrl: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&q=80&w=2070",
  },
  {
    city: "New York",
    country: "USA",
    region: "North America",
    popularity: 90,
    imageUrl: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?auto=format&fit=crop&q=80&w=2070",
  },
];

// Comprehensive list of global locations
const allLocations: Location[] = [
  // Europe (Additional cities)
  { city: "Milan", country: "Italy", region: "Europe" },
  { city: "Munich", country: "Germany", region: "Europe" },
  { city: "Frankfurt", country: "Germany", region: "Europe" },
  { city: "Hamburg", country: "Germany", region: "Europe" },
  { city: "Nice", country: "France", region: "Europe" },
  { city: "Lyon", country: "France", region: "Europe" },
  { city: "Marseille", country: "France", region: "Europe" },
  { city: "Porto", country: "Portugal", region: "Europe" },
  { city: "Seville", country: "Spain", region: "Europe" },
  { city: "Valencia", country: "Spain", region: "Europe" },
  { city: "Naples", country: "Italy", region: "Europe" },
  { city: "Florence", country: "Italy", region: "Europe" },
  { city: "Krakow", country: "Poland", region: "Europe" },
  { city: "Warsaw", country: "Poland", region: "Europe" },
  { city: "Bucharest", country: "Romania", region: "Europe" },
  { city: "Sofia", country: "Bulgaria", region: "Europe" },
  { city: "Belgrade", country: "Serbia", region: "Europe" },
  { city: "Zagreb", country: "Croatia", region: "Europe" },
  { city: "Dubrovnik", country: "Croatia", region: "Europe" },
  { city: "Reykjavik", country: "Iceland", region: "Europe" },

  // Europe
  { city: "London", country: "UK", region: "Europe" },
  { city: "Paris", country: "France", region: "Europe" },
  { city: "Rome", country: "Italy", region: "Europe" },
  { city: "Barcelona", country: "Spain", region: "Europe" },
  { city: "Amsterdam", country: "Netherlands", region: "Europe" },
  { city: "Berlin", country: "Germany", region: "Europe" },
  { city: "Vienna", country: "Austria", region: "Europe" },
  { city: "Prague", country: "Czech Republic", region: "Europe" },
  { city: "Venice", country: "Italy", region: "Europe" },
  { city: "Madrid", country: "Spain", region: "Europe" },
  { city: "Stockholm", country: "Sweden", region: "Europe" },
  { city: "Copenhagen", country: "Denmark", region: "Europe" },
  { city: "Oslo", country: "Norway", region: "Europe" },
  { city: "Helsinki", country: "Finland", region: "Europe" },
  { city: "Athens", country: "Greece", region: "Europe" },
  { city: "Budapest", country: "Hungary", region: "Europe" },
  { city: "Lisbon", country: "Portugal", region: "Europe" },
  { city: "Dublin", country: "Ireland", region: "Europe" },
  { city: "Brussels", country: "Belgium", region: "Europe" },
  { city: "Zurich", country: "Switzerland", region: "Europe" },

  // Asia (Additional cities)
  { city: "Busan", country: "South Korea", region: "Asia" },
  { city: "Sapporo", country: "Japan", region: "Asia" },
  { city: "Fukuoka", country: "Japan", region: "Asia" },
  { city: "Nagoya", country: "Japan", region: "Asia" },
  { city: "Guangzhou", country: "China", region: "Asia" },
  { city: "Shenzhen", country: "China", region: "Asia" },
  { city: "Chengdu", country: "China", region: "Asia" },
  { city: "Xi'an", country: "China", region: "Asia" },
  { city: "Bangalore", country: "India", region: "Asia" },
  { city: "Chennai", country: "India", region: "Asia" },
  { city: "Kolkata", country: "India", region: "Asia" },
  { city: "Hyderabad", country: "India", region: "Asia" },
  { city: "Jaipur", country: "India", region: "Asia" },
  { city: "Yangon", country: "Myanmar", region: "Asia" },
  { city: "Phnom Penh", country: "Cambodia", region: "Asia" },
  { city: "Vientiane", country: "Laos", region: "Asia" },
  { city: "Colombo", country: "Sri Lanka", region: "Asia" },
  { city: "Kathmandu", country: "Nepal", region: "Asia" },
  { city: "Ulaanbaatar", country: "Mongolia", region: "Asia" },
  { city: "Almaty", country: "Kazakhstan", region: "Asia" },

  // Asia
  { city: "Tokyo", country: "Japan", region: "Asia" },
  { city: "Singapore", country: "Singapore", region: "Asia" },
  { city: "Hong Kong", country: "China", region: "Asia" },
  { city: "Bangkok", country: "Thailand", region: "Asia" },
  { city: "Seoul", country: "South Korea", region: "Asia" },
  { city: "Shanghai", country: "China", region: "Asia" },
  { city: "Beijing", country: "China", region: "Asia" },
  { city: "Mumbai", country: "India", region: "Asia" },
  { city: "Delhi", country: "India", region: "Asia" },
  { city: "Kyoto", country: "Japan", region: "Asia" },
  { city: "Osaka", country: "Japan", region: "Asia" },
  { city: "Taipei", country: "Taiwan", region: "Asia" },
  { city: "Ho Chi Minh City", country: "Vietnam", region: "Asia" },
  { city: "Kuala Lumpur", country: "Malaysia", region: "Asia" },
  { city: "Jakarta", country: "Indonesia", region: "Asia" },
  { city: "Manila", country: "Philippines", region: "Asia" },
  { city: "Hanoi", country: "Vietnam", region: "Asia" },
  { city: "Bali", country: "Indonesia", region: "Asia" },
  { city: "Phuket", country: "Thailand", region: "Asia" },
  { city: "Chiang Mai", country: "Thailand", region: "Asia" },

  // North America (Additional cities)
  { city: "Austin", country: "USA", region: "North America" },
  { city: "Nashville", country: "USA", region: "North America" },
  { city: "Portland", country: "USA", region: "North America" },
  { city: "San Diego", country: "USA", region: "North America" },
  { city: "Phoenix", country: "USA", region: "North America" },
  { city: "Dallas", country: "USA", region: "North America" },
  { city: "Atlanta", country: "USA", region: "North America" },
  { city: "New Orleans", country: "USA", region: "North America" },
  { city: "Edmonton", country: "Canada", region: "North America" },
  { city: "Winnipeg", country: "Canada", region: "North America" },
  { city: "Halifax", country: "Canada", region: "North America" },
  { city: "Guadalajara", country: "Mexico", region: "North America" },
  { city: "Monterrey", country: "Mexico", region: "North America" },
  { city: "Tijuana", country: "Mexico", region: "North America" },
  { city: "Havana", country: "Cuba", region: "North America" },
  { city: "San Juan", country: "Puerto Rico", region: "North America" },
  { city: "Nassau", country: "Bahamas", region: "North America" },
  { city: "Kingston", country: "Jamaica", region: "North America" },
  { city: "Santo Domingo", country: "Dominican Republic", region: "North America" },
  { city: "Panama City", country: "Panama", region: "North America" },

  // North America
  { city: "New York", country: "USA", region: "North America" },
  { city: "Los Angeles", country: "USA", region: "North America" },
  { city: "San Francisco", country: "USA", region: "North America" },
  { city: "Chicago", country: "USA", region: "North America" },
  { city: "Miami", country: "USA", region: "North America" },
  { city: "Las Vegas", country: "USA", region: "North America" },
  { city: "Toronto", country: "Canada", region: "North America" },
  { city: "Vancouver", country: "Canada", region: "North America" },
  { city: "Montreal", country: "Canada", region: "North America" },
  { city: "Mexico City", country: "Mexico", region: "North America" },
  { city: "Cancun", country: "Mexico", region: "North America" },
  { city: "Seattle", country: "USA", region: "North America" },
  { city: "Boston", country: "USA", region: "North America" },
  { city: "Washington DC", country: "USA", region: "North America" },
  { city: "Houston", country: "USA", region: "North America" },
  { city: "Orlando", country: "USA", region: "North America" },
  { city: "Denver", country: "USA", region: "North America" },
  { city: "Calgary", country: "Canada", region: "North America" },
  { city: "Ottawa", country: "Canada", region: "North America" },
  { city: "Quebec City", country: "Canada", region: "North America" },

  // South America (Additional cities)
  { city: "Salvador", country: "Brazil", region: "South America" },
  { city: "Brasilia", country: "Brazil", region: "South America" },
  { city: "Fortaleza", country: "Brazil", region: "South America" },
  { city: "Recife", country: "Brazil", region: "South America" },
  { city: "Manaus", country: "Brazil", region: "South America" },
  { city: "Cordoba", country: "Argentina", region: "South America" },
  { city: "Mendoza", country: "Argentina", region: "South America" },
  { city: "Rosario", country: "Argentina", region: "South America" },
  { city: "Valparaiso", country: "Chile", region: "South America" },
  { city: "Punta Arenas", country: "Chile", region: "South America" },
  { city: "Medellin", country: "Colombia", region: "South America" },
  { city: "Cali", country: "Colombia", region: "South America" },
  { city: "Arequipa", country: "Peru", region: "South America" },
  { city: "Trujillo", country: "Peru", region: "South America" },
  { city: "Guayaquil", country: "Ecuador", region: "South America" },
  { city: "Cuenca", country: "Ecuador", region: "South America" },
  { city: "Asuncion", country: "Paraguay", region: "South America" },
  { city: "Punta del Este", country: "Uruguay", region: "South America" },
  { city: "Caracas", country: "Venezuela", region: "South America" },
  { city: "Maracaibo", country: "Venezuela", region: "South America" },

  // South America
  { city: "Rio de Janeiro", country: "Brazil", region: "South America" },
  { city: "São Paulo", country: "Brazil", region: "South America" },
  { city: "Buenos Aires", country: "Argentina", region: "South America" },
  { city: "Lima", country: "Peru", region: "South America" },
  { city: "Santiago", country: "Chile", region: "South America" },
  { city: "Bogotá", country: "Colombia", region: "South America" },
  { city: "Cusco", country: "Peru", region: "South America" },
  { city: "Cartagena", country: "Colombia", region: "South America" },
  { city: "Quito", country: "Ecuador", region: "South America" },
  { city: "Montevideo", country: "Uruguay", region: "South America" },

  // Middle East (Additional cities)
  { city: "Jeddah", country: "Saudi Arabia", region: "Middle East" },
  { city: "Medina", country: "Saudi Arabia", region: "Middle East" },
  { city: "Kuwait City", country: "Kuwait", region: "Middle East" },
  { city: "Manama", country: "Bahrain", region: "Middle East" },
  { city: "Sharjah", country: "UAE", region: "Middle East" },
  { city: "Ankara", country: "Turkey", region: "Middle East" },
  { city: "Antalya", country: "Turkey", region: "Middle East" },
  { city: "Tehran", country: "Iran", region: "Middle East" },
  { city: "Isfahan", country: "Iran", region: "Middle East" },
  { city: "Baghdad", country: "Iraq", region: "Middle East" },

  // Middle East
  { city: "Dubai", country: "UAE", region: "Middle East" },
  { city: "Abu Dhabi", country: "UAE", region: "Middle East" },
  { city: "Istanbul", country: "Turkey", region: "Middle East" },
  { city: "Tel Aviv", country: "Israel", region: "Middle East" },
  { city: "Jerusalem", country: "Israel", region: "Middle East" },
  { city: "Doha", country: "Qatar", region: "Middle East" },
  { city: "Riyadh", country: "Saudi Arabia", region: "Middle East" },
  { city: "Muscat", country: "Oman", region: "Middle East" },
  { city: "Amman", country: "Jordan", region: "Middle East" },
  { city: "Beirut", country: "Lebanon", region: "Middle East" },

  // Africa (Additional cities)
  { city: "Alexandria", country: "Egypt", region: "Africa" },
  { city: "Luxor", country: "Egypt", region: "Africa" },
  { city: "Fez", country: "Morocco", region: "Africa" },
  { city: "Tangier", country: "Morocco", region: "Africa" },
  { city: "Tunis", country: "Tunisia", region: "Africa" },
  { city: "Algiers", country: "Algeria", region: "Africa" },
  { city: "Dakar", country: "Senegal", region: "Africa" },
  { city: "Accra", country: "Ghana", region: "Africa" },
  { city: "Abuja", country: "Nigeria", region: "Africa" },
  { city: "Khartoum", country: "Sudan", region: "Africa" },
  { city: "Kampala", country: "Uganda", region: "Africa" },
  { city: "Kigali", country: "Rwanda", region: "Africa" },
  { city: "Mombasa", country: "Kenya", region: "Africa" },
  { city: "Maputo", country: "Mozambique", region: "Africa" },
  { city: "Windhoek", country: "Namibia", region: "Africa" },
  { city: "Gaborone", country: "Botswana", region: "Africa" },
  { city: "Durban", country: "South Africa", region: "Africa" },
  { city: "Port Louis", country: "Mauritius", region: "Africa" },
  { city: "Victoria", country: "Seychelles", region: "Africa" },
  { city: "Antananarivo", country: "Madagascar", region: "Africa" },

  // Africa
  { city: "Cape Town", country: "South Africa", region: "Africa" },
  { city: "Cairo", country: "Egypt", region: "Africa" },
  { city: "Marrakech", country: "Morocco", region: "Africa" },
  { city: "Johannesburg", country: "South Africa", region: "Africa" },
  { city: "Nairobi", country: "Kenya", region: "Africa" },
  { city: "Casablanca", country: "Morocco", region: "Africa" },
  { city: "Lagos", country: "Nigeria", region: "Africa" },
  { city: "Zanzibar City", country: "Tanzania", region: "Africa" },
  { city: "Addis Ababa", country: "Ethiopia", region: "Africa" },
  { city: "Dar es Salaam", country: "Tanzania", region: "Africa" },

  // Oceania (Additional cities)
  { city: "Darwin", country: "Australia", region: "Oceania" },
  { city: "Cairns", country: "Australia", region: "Oceania" },
  { city: "Hobart", country: "Australia", region: "Oceania" },
  { city: "Newcastle", country: "Australia", region: "Oceania" },
  { city: "Canberra", country: "Australia", region: "Oceania" },
  { city: "Hamilton", country: "New Zealand", region: "Oceania" },
  { city: "Dunedin", country: "New Zealand", region: "Oceania" },
  { city: "Napier", country: "New Zealand", region: "Oceania" },
  { city: "Suva", country: "Fiji", region: "Oceania" },
  { city: "Nadi", country: "Fiji", region: "Oceania" },
  { city: "Noumea", country: "New Caledonia", region: "Oceania" },
  { city: "Port Vila", country: "Vanuatu", region: "Oceania" },
  { city: "Apia", country: "Samoa", region: "Oceania" },
  { city: "Nuku'alofa", country: "Tonga", region: "Oceania" },
  { city: "Papeete", country: "French Polynesia", region: "Oceania" },

  // Oceania
  { city: "Sydney", country: "Australia", region: "Oceania" },
  { city: "Melbourne", country: "Australia", region: "Oceania" },
  { city: "Brisbane", country: "Australia", region: "Oceania" },
  { city: "Perth", country: "Australia", region: "Oceania" },
  { city: "Auckland", country: "New Zealand", region: "Oceania" },
  { city: "Wellington", country: "New Zealand", region: "Oceania" },
  { city: "Gold Coast", country: "Australia", region: "Oceania" },
  { city: "Christchurch", country: "New Zealand", region: "Oceania" },
  { city: "Adelaide", country: "Australia", region: "Oceania" },
  { city: "Queenstown", country: "New Zealand", region: "Oceania" },

  // Major Indian Cities
  { city: "Mumbai", country: "India", region: "South Asia" },
  { city: "Delhi", country: "India", region: "South Asia" },
  { city: "Bangalore", country: "India", region: "South Asia" },
  { city: "Hyderabad", country: "India", region: "South Asia" },
  { city: "Chennai", country: "India", region: "South Asia" },
  { city: "Kolkata", country: "India", region: "South Asia" },
  { city: "Pune", country: "India", region: "South Asia" },
  { city: "Ahmedabad", country: "India", region: "South Asia" },
  { city: "Jaipur", country: "India", region: "South Asia" },
  { city: "Surat", country: "India", region: "South Asia" },
  { city: "Lucknow", country: "India", region: "South Asia" },
  { city: "Kanpur", country: "India", region: "South Asia" },
  { city: "Nagpur", country: "India", region: "South Asia" },
  { city: "Indore", country: "India", region: "South Asia" },
  { city: "Thane", country: "India", region: "South Asia" },
  { city: "Bhopal", country: "India", region: "South Asia" },
  { city: "Visakhapatnam", country: "India", region: "South Asia" },
  { city: "Pimpri-Chinchwad", country: "India", region: "South Asia" },
  { city: "Patna", country: "India", region: "South Asia" },
  { city: "Vadodara", country: "India", region: "South Asia" },
  { city: "Ghaziabad", country: "India", region: "South Asia" },
  { city: "Ludhiana", country: "India", region: "South Asia" },
  { city: "Agra", country: "India", region: "South Asia" },
  { city: "Nashik", country: "India", region: "South Asia" },
  { city: "Faridabad", country: "India", region: "South Asia" },
  { city: "Meerut", country: "India", region: "South Asia" },
  { city: "Rajkot", country: "India", region: "South Asia" },
  { city: "Kalyan-Dombivli", country: "India", region: "South Asia" },
  { city: "Vasai-Virar", country: "India", region: "South Asia" },
  { city: "Varanasi", country: "India", region: "South Asia" },
  { city: "Srinagar", country: "India", region: "South Asia" },
  { city: "Aurangabad", country: "India", region: "South Asia" },
  { city: "Dhanbad", country: "India", region: "South Asia" },
  { city: "Amritsar", country: "India", region: "South Asia" },
  { city: "Navi Mumbai", country: "India", region: "South Asia" },
  { city: "Allahabad", country: "India", region: "South Asia" },
  { city: "Ranchi", country: "India", region: "South Asia" },
  { city: "Howrah", country: "India", region: "South Asia" },
  { city: "Coimbatore", country: "India", region: "South Asia" },
  { city: "Jabalpur", country: "India", region: "South Asia" },
  { city: "Gwalior", country: "India", region: "South Asia" },
  { city: "Vijayawada", country: "India", region: "South Asia" },
  { city: "Jodhpur", country: "India", region: "South Asia" },
  { city: "Madurai", country: "India", region: "South Asia" },
  { city: "Raipur", country: "India", region: "South Asia" },
  { city: "Kota", country: "India", region: "South Asia" },
  { city: "Guwahati", country: "India", region: "South Asia" },
  { city: "Chandigarh", country: "India", region: "South Asia" },
  { city: "Solapur", country: "India", region: "South Asia" },
  { city: "Hubli-Dharwad", country: "India", region: "South Asia" },
  { city: "Bareilly", country: "India", region: "South Asia" },
  { city: "Moradabad", country: "India", region: "South Asia" },
  { city: "Mysore", country: "India", region: "South Asia" },
  { city: "Gurgaon", country: "India", region: "South Asia" },
  { city: "Aligarh", country: "India", region: "South Asia" },
  { city: "Jalandhar", country: "India", region: "South Asia" },
  { city: "Tiruchirappalli", country: "India", region: "South Asia" },
  { city: "Bhubaneswar", country: "India", region: "South Asia" },
  { city: "Salem", country: "India", region: "South Asia" },
  { city: "Mira-Bhayandar", country: "India", region: "South Asia" },
  { city: "Warangal", country: "India", region: "South Asia" },
  { city: "Thiruvananthapuram", country: "India", region: "South Asia" },
  { city: "Guntur", country: "India", region: "South Asia" },
  { city: "Bhiwandi", country: "India", region: "South Asia" },
  { city: "Saharanpur", country: "India", region: "South Asia" },
  { city: "Gorakhpur", country: "India", region: "South Asia" },
  { city: "Bikaner", country: "India", region: "South Asia" },
  { city: "Amravati", country: "India", region: "South Asia" },
  { city: "Noida", country: "India", region: "South Asia" },
  { city: "Jamshedpur", country: "India", region: "South Asia" },
  { city: "Bhilai", country: "India", region: "South Asia" },
  { city: "Cuttack", country: "India", region: "South Asia" },
  { city: "Firozabad", country: "India", region: "South Asia" },
  { city: "Kochi", country: "India", region: "South Asia" },
  { city: "Nellore", country: "India", region: "South Asia" },
  { city: "Bhavnagar", country: "India", region: "South Asia" },
  { city: "Dehradun", country: "India", region: "South Asia" },
  { city: "Durgapur", country: "India", region: "South Asia" },
  { city: "Asansol", country: "India", region: "South Asia" },
  { city: "Rourkela", country: "India", region: "South Asia" },
  { city: "Nanded", country: "India", region: "South Asia" },
  { city: "Kolhapur", country: "India", region: "South Asia" },
  { city: "Ajmer", country: "India", region: "South Asia" },
  { city: "Akola", country: "India", region: "South Asia" },
  { city: "Gulbarga", country: "India", region: "South Asia" },
  { city: "Jamnagar", country: "India", region: "South Asia" },
  { city: "Ujjain", country: "India", region: "South Asia" },
  { city: "Loni", country: "India", region: "South Asia" },
  { city: "Siliguri", country: "India", region: "South Asia" },
  { city: "Jhansi", country: "India", region: "South Asia" },
  { city: "Ulhasnagar", country: "India", region: "South Asia" },
  { city: "Jammu", country: "India", region: "South Asia" },
  { city: "Sangli", country: "India", region: "South Asia" },
  { city: "Erode", country: "India", region: "South Asia" },
  { city: "Panipat", country: "India", region: "South Asia" },
  { city: "Mangalore", country: "India", region: "South Asia" },
  { city: "Udaipur", country: "India", region: "South Asia" },
];

export function LocationSearch({ onLocationSelect, placeholder = "Where are you going?", className }: LocationSearchProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [recentSearches, setRecentSearches] = useState<Location[]>([]);

  // Load recent searches from localStorage on mount
  useEffect(() => {
    const savedSearches = localStorage.getItem("recentLocationSearches");
    if (savedSearches) {
      setRecentSearches(JSON.parse(savedSearches));
    }
  }, []);

  // Save recent searches to localStorage
  const saveRecentSearch = (location: Location) => {
    const updatedSearches = [
      location,
      ...recentSearches.filter(l => l.city !== location.city).slice(0, 4)
    ];
    setRecentSearches(updatedSearches);
    localStorage.setItem("recentLocationSearches", JSON.stringify(updatedSearches));
  };

  // Filter locations based on search query
  const filteredLocations = searchQuery
    ? allLocations.filter(location =>
        location.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
        location.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
        location.region?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  const handleLocationSelect = (location: Location) => {
    onLocationSelect(location);
    saveRecentSearch(location);
    setSearchQuery(`${location.city}, ${location.country}`);
    setIsOpen(false);
  };

  return (
    <div className="relative w-full">
      <div className="relative">
        <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
        <Input
          placeholder={placeholder}
          value={searchQuery}
          onChange={(e) => {
            setSearchQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          className={`pl-10 h-12 bg-white border-2 border-gray-200 focus:border-[#003580] ${className}`}
        />
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute z-50 w-full mt-1 bg-white rounded-lg shadow-xl border"
          >
            <Card className="p-4 max-h-[600px] overflow-y-auto">
              {/* Trending Destinations */}
              {!searchQuery && (
                <div className="mb-6">
                  <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-blue-500" />
                    Trending Destinations
                  </h3>
                  <div className="grid grid-cols-2 gap-2">
                    {trendingDestinations.map((location) => (
                      <div
                        key={location.city}
                        className="relative cursor-pointer group"
                        onClick={() => handleLocationSelect(location)}
                      >
                        <div
                          className="h-24 rounded-lg bg-cover bg-center"
                          style={{ backgroundImage: `url(${location.imageUrl})` }}
                        >
                          <div className="absolute inset-0 bg-black/40 rounded-lg group-hover:bg-black/50 transition-all" />
                          <div className="absolute bottom-2 left-2 text-white">
                            <div className="font-semibold">{location.city}</div>
                            <div className="text-sm opacity-90">{location.country}</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Recent Searches */}
              {!searchQuery && recentSearches.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-gray-500" />
                    Recent Searches
                  </h3>
                  <div className="space-y-2">
                    {recentSearches.map((location) => (
                      <div
                        key={location.city}
                        className="flex items-center gap-3 p-2 hover:bg-gray-50 rounded-md cursor-pointer"
                        onClick={() => handleLocationSelect(location)}
                      >
                        <Clock className="w-4 h-4 text-gray-400" />
                        <div>
                          <div className="font-medium">{location.city}</div>
                          <div className="text-sm text-gray-500">{location.country}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Search Results */}
              {searchQuery && (
                <div>
                  <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                    <Globe className="w-4 h-4 text-gray-500" />
                    Search Results
                  </h3>
                  <div className="space-y-2">
                    {filteredLocations.length > 0 ? (
                      filteredLocations.map((location) => (
                        <div
                          key={location.city}
                          className="flex items-center gap-3 p-2 hover:bg-gray-50 rounded-md cursor-pointer"
                          onClick={() => handleLocationSelect(location)}
                        >
                          <MapPin className="w-4 h-4 text-gray-400" />
                          <div>
                            <div className="font-medium">{location.city}</div>
                            <div className="text-sm text-gray-500">
                              {location.country} • {location.region}
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center text-gray-500 py-4">
                        No locations found
                      </div>
                    )}
                  </div>
                </div>
              )}
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}