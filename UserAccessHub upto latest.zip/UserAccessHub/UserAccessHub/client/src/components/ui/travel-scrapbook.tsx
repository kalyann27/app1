import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Calendar, Tag, Share2, ExternalLink } from 'lucide-react';
import { EmojiReaction } from './emoji-reaction';
import { TravelMemory } from '@shared/schema';
import { format } from 'date-fns';
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

interface TravelScrapbookProps {
  memories: TravelMemory[];
  viewType?: "grid" | "scrapbook";
  className?: string;
}

const fallbackImage = "https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&q=80&w=2070";

export function TravelScrapbook({ memories, viewType = "grid", className = "" }: TravelScrapbookProps) {
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [loadedImages, setLoadedImages] = useState<Set<string>>(new Set());

  const handleImageLoad = (id: string) => {
    setLoadedImages(prev => new Set(prev).add(id));
  };

  if (!memories.length) {
    return (
      <Card className="p-6 text-center">
        <p className="text-muted-foreground">No memories found.</p>
      </Card>
    );
  }

  return (
    <div className={`columns-1 md:columns-2 lg:columns-3 xl:columns-4 gap-6 ${className}`}>
      {memories.map((memory, index) => (
        <motion.div
          key={memory.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
          className="break-inside-avoid mb-6"
        >
          <Card 
            className="overflow-hidden hover:shadow-xl transition-all duration-300 group cursor-pointer"
            onMouseEnter={() => setHoveredId(memory.id)}
            onMouseLeave={() => setHoveredId(null)}
          >
            <CardContent className="p-0">
              <div className="relative">
                <div className="aspect-[4/3] overflow-hidden bg-muted">
                  {!loadedImages.has(memory.id) && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Skeleton className="w-full h-full" />
                    </div>
                  )}
                  <motion.img
                    src={memory.imageUrl || fallbackImage}
                    alt={memory.title}
                    className={`w-full h-full object-cover transition-opacity duration-300 ${
                      loadedImages.has(memory.id) ? 'opacity-100' : 'opacity-0'
                    }`}
                    onLoad={() => handleImageLoad(memory.id)}
                    onError={(e) => {
                      const img = e.target as HTMLImageElement;
                      img.src = fallbackImage;
                      handleImageLoad(memory.id);
                    }}
                    whileHover={{ scale: 1.05 }}
                    transition={{ duration: 0.3 }}
                  />
                </div>

                {/* Overlay */}
                <motion.div 
                  className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  initial={false}
                  animate={{ opacity: hoveredId === memory.id ? 1 : 0 }}
                >
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <motion.div
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: hoveredId === memory.id ? 0 : 20, opacity: hoveredId === memory.id ? 1 : 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <h3 className="text-2xl font-semibold mb-2">{memory.title}</h3>
                      <div className="flex items-center gap-2 text-sm text-white/80 mb-3">
                        <MapPin className="w-4 h-4" />
                        <span>{memory.location}</span>
                      </div>
                      <p className="text-sm text-white/70 line-clamp-2 mb-4">
                        {memory.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          <span className="text-sm">{format(new Date(memory.date), 'MMM d, yyyy')}</span>
                        </div>
                        <Button size="sm" variant="secondary" className="gap-2">
                          <ExternalLink className="w-4 h-4" />
                          View Story
                        </Button>
                      </div>
                    </motion.div>
                  </div>
                </motion.div>

                {/* Tags */}
                <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                  {memory.tags.map((tag) => (
                    <Badge
                      key={tag}
                      variant="secondary"
                      className="bg-white/90 text-primary hover:bg-white"
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>

                {/* Actions */}
                <div className="absolute top-4 right-4 flex items-center gap-2">
                  <EmojiReaction itemId={memory.id} />
                  <Button variant="secondary" size="icon" className="bg-white/90 hover:bg-white">
                    <Share2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}