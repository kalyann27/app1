import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  CreditCard,
  CheckCircle,
  XCircle,
  Loader2,
  Plane,
} from 'lucide-react';
import { Button } from './button';
import { Card, CardContent, CardHeader, CardTitle } from './card';

interface PaymentFormProps {
  amount: number;
  onSuccess: () => void;
  onError?: (message: string) => void;
  metadata?: {
    flightId: string;
    seatNumber: string;
    class: string;
  };
  bookingDetails?: {
    type: string;
    description: string;
    image?: string;
  };
}

export function PaymentForm({ amount, onSuccess, onError, metadata, bookingDetails }: PaymentFormProps) {
  const [status, setStatus] = useState<'idle' | 'processing' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    if (status === 'error' && onError) {
      onError(errorMessage);
    } else if (status === 'success') {
      onSuccess();
    }
  }, [status, errorMessage, onError, onSuccess]);

  const handlePayment = async () => {
    try {
      setStatus('processing');

      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));

      // For demo purposes, always succeed
      setStatus('success');

    } catch (error: any) {
      setStatus('error');
      setErrorMessage(error.message || 'Payment failed');
    }
  };

  return (
    <Card className="w-full bg-card/50 backdrop-blur-sm border-2">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            Complete Payment
          </span>
          <CreditCard className="w-6 h-6 text-primary animate-pulse" />
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Booking Summary with animations */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6 p-4 bg-primary/5 rounded-lg border border-primary/10"
        >
          <div className="flex items-start gap-4">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-20 h-20 rounded-md bg-primary/10 flex items-center justify-center"
            >
              <Plane className="w-10 h-10 text-primary" />
            </motion.div>
            <div className="flex-1">
              <motion.p
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="text-sm text-muted-foreground"
              >
                {metadata && (
                  <>
                    <div className="font-semibold">Flight Details</div>
                    <div>Seat: {metadata.seatNumber}</div>
                    <div>Class: {metadata.class}</div>
                  </>
                )}
              </motion.p>
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="mt-2 text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent"
              >
                ${amount.toFixed(2)}
              </motion.div>
            </div>
          </div>
        </motion.div>

        {/* Payment Status */}
        <AnimatePresence mode="wait">
          {status === 'processing' && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="flex flex-col items-center justify-center py-8"
            >
              <Loader2 className="w-12 h-12 animate-spin text-primary" />
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 text-lg font-medium text-primary"
              >
                Processing your payment...
              </motion.p>
            </motion.div>
          )}

          {status === 'success' && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-8"
            >
              <CheckCircle className="w-16 h-16 text-green-500" />
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="mt-4 text-xl font-semibold text-green-500"
              >
                Payment successful!
              </motion.p>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="text-sm text-muted-foreground mt-2"
              >
                Your flight is booked. Check your email for confirmation.
              </motion.p>
            </motion.div>
          )}

          {status === 'error' && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-8"
            >
              <XCircle className="w-16 h-16 text-destructive" />
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 text-xl font-semibold text-destructive"
              >
                Payment failed
              </motion.p>
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="text-sm text-muted-foreground text-center mt-2"
              >
                {errorMessage}
              </motion.p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Payment Button */}
        {status === 'idle' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6"
          >
            <Button
              className="w-full py-6 text-lg relative overflow-hidden group"
              onClick={handlePayment}
            >
              <motion.span
                className="relative z-10 flex items-center justify-center gap-2"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <CreditCard className="w-5 h-5" />
                Pay ${amount.toFixed(2)}
              </motion.span>
              <motion.div
                className="absolute inset-0 bg-primary/20"
                initial={{ x: '-100%' }}
                whileHover={{ x: '100%' }}
                transition={{ duration: 0.8, ease: 'easeInOut' }}
              />
            </Button>
          </motion.div>
        )}

        {/* Security Notice */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-6 text-center"
        >
          <motion.div
            className="inline-flex items-center gap-2 text-sm text-muted-foreground"
            whileHover={{ scale: 1.05 }}
          >
            🔒 Secure payment processing
          </motion.div>
        </motion.div>
      </CardContent>
    </Card>
  );
}