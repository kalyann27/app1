
import { useEffect } from 'react';
import { useLocation, useNavigate } from '@solidjs/router';
import { useToast } from '../ui/toast';
import { useQueryClient } from '@tanstack/solid-query';

export function GoogleCallbackHandler() {
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    console.log('GoogleCallbackHandler running on path:', location.pathname);
    
    // Check for error in URL
    const urlParams = new URLSearchParams(window.location.search);
    const error = urlParams.get('error');

    if (error) {
      console.error('Google auth error in URL:', error);
      toast({
        title: "Authentication Failed",
        description: "Google login was unsuccessful. Please try again.",
        variant: "destructive",
      });
      navigate('/auth');
      return;
    }

    // If we're on the callback page without an error, fetch current user
    if (location.pathname === '/auth/google/callback') {
      fetch('/api/user')
        .then(response => {
          if (!response.ok) {
            throw new Error('Authentication failed');
          }
          return response.json();
        })
        .then(user => {
          console.log('Google login successful, user data:', user);
          
          // Update user in query cache
          queryClient.setQueryData(['/api/user'], user);
          
          toast({
            title: "Welcome!",
            description: `You've been successfully logged in${user.display_name ? ` as ${user.display_name}` : ''}.`,
          });
          
          // Redirect to home page
          navigate('/');
        })
        .catch(error => {
          console.error('Error fetching user after Google login:', error);
          toast({
            title: "Login Failed",
            description: "There was a problem completing your Google login. Please try again.",
            variant: "destructive",
          });
          navigate('/auth');
        });
    }
  }, [location.pathname]);

  return null;
}
