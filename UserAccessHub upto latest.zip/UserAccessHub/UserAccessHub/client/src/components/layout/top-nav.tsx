import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuList,
} from "@/components/ui/navigation-menu";
import {
  Plane,
  Building2,
  Car,
  UtensilsCrossed,
  User,
  LogOut,
  Book,
  Bot,
  Globe,
  Flag,
  DollarSign,
  MapPin,
  Loader2,
  Route, // Added import for Route icon
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useState, useEffect } from "react";

const countries = [
  { code: "US", name: "United States", flag: "🇺🇸", currency: "USD" },
  { code: "GB", name: "United Kingdom", flag: "🇬🇧", currency: "GBP" },
  { code: "CA", name: "Canada", flag: "🇨🇦", currency: "CAD" },
  { code: "AU", name: "Australia", flag: "🇦🇺", currency: "AUD" },
  { code: "IN", name: "India", flag: "🇮🇳", currency: "INR" },
];

const currencies = [
  { code: "USD", symbol: "$", name: "US Dollar", flag: "🇺🇸" },
  { code: "EUR", symbol: "€", name: "Euro", flag: "🇪🇺" },
  { code: "GBP", symbol: "£", name: "British Pound", flag: "🇬🇧" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen", flag: "🇯🇵" },
  { code: "INR", symbol: "₹", name: "Indian Rupee", flag: "🇮🇳" },
  { code: "AUD", symbol: "$", name: "Australian Dollar", flag: "🇦🇺" },
  { code: "CAD", symbol: "$", name: "Canadian Dollar", flag: "🇨🇦" },
];

const languages = [
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "es", name: "Español", flag: "🇪🇸" },
  { code: "fr", name: "Français", flag: "🇫🇷" },
  { code: "de", name: "Deutsch", flag: "🇩🇪" },
  { code: "hi", name: "हिंदी", flag: "🇮🇳" },
];

const TopNav = () => {
  const [location] = useLocation();
  const { logoutMutation } = useAuth();
  const [currency, setCurrency] = useState(currencies[0]);
  const [language, setLanguage] = useState(languages[0]);
  const [isLoadingLocation, setIsLoadingLocation] = useState(true);
  const [currentLocation, setCurrentLocation] = useState({ city: "Detecting location...", country: "" });
  const [selectedCountry, setSelectedCountry] = useState(countries[0]);
  const [retryCount, setRetryCount] = useState(0);
  const MAX_RETRIES = 3;

  const updateLocationSettings = (countryCode: string) => {
    const country = countries.find(c => c.code === countryCode);
    if (country) {
      setSelectedCountry(country);
      const matchingCurrency = currencies.find(c => c.code === country.currency);
      if (matchingCurrency) {
        setCurrency(matchingCurrency);
      }
    }
  };

  const getLocationViaIP = async () => {
    try {
      const response = await fetch(
        `https://api.opencagedata.com/geocode/v1/json?q=ip&key=${import.meta.env.OPENCAGE_API_KEY}&pretty=1`
      );

      if (!response.ok) throw new Error('Location API error');
      const data = await response.json();

      if (data.results && data.results.length > 0) {
        const result = data.results[0];
        setCurrentLocation({
          city: result.components.city || result.components.town || result.components.state_district || result.components.state,
          country: result.components.country
        });
        updateLocationSettings(result.components.country_code.toUpperCase());
        return;
      }

      throw new Error('Location data not available');
    } catch (error) {
      console.error("Location error:", error);
      throw error;
    }
  };

  const getLocationViaGeolocation = async (): Promise<{ latitude: number; longitude: number }> => {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        (position) => resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        }),
        reject,
        {
          enableHighAccuracy: true,
          timeout: 5000,
          maximumAge: 0
        }
      );
    });
  };

  useEffect(() => {
    const detectLocation = async () => {
      try {
        setIsLoadingLocation(true);

        if ("geolocation" in navigator) {
          try {
            const { latitude, longitude } = await getLocationViaGeolocation();
            const response = await fetch(
              `https://api.opencagedata.com/geocode/v1/json?q=${latitude}+${longitude}&key=${import.meta.env.OPENCAGE_API_KEY}`
            );

            if (!response.ok) throw new Error('Geocoding API error');

            const data = await response.json();
            if (data.results && data.results.length > 0) {
              const result = data.results[0].components;
              const locationName = result.city || result.town || result.village || result.suburb || result.state_district;
              setCurrentLocation({
                city: locationName,
                country: result.country
              });
              const countryCode = result.country_code.toUpperCase();
              updateLocationSettings(countryCode);

              const browserLang = navigator.language.split('-')[0];
              const matchingLang = languages.find(l => l.code === browserLang);
              if (matchingLang) {
                setLanguage(matchingLang);
              }
              return;
            }
          } catch (error) {
            console.error("Geolocation error:", error);
          }
        }

        await getLocationViaIP();

      } catch (error) {
        console.error("Location detection error:", error);
        if (retryCount < MAX_RETRIES) {
          setTimeout(() => {
            setRetryCount(prev => prev + 1);
          }, 2000);
        } else {
          setCurrentLocation({
            city: "New Delhi",
            country: "India"
          });
          updateLocationSettings("IN");
        }
      } finally {
        setIsLoadingLocation(false);
      }
    };

    detectLocation();
  }, [retryCount]);

  const navItems = [
    { href: "/flights", icon: Plane, label: "Flights" },
    { href: "/hotels", icon: Building2, label: "Hotels" },
    { href: "/rides", icon: Car, label: "Rides" },
    { href: "/dining", icon: UtensilsCrossed, label: "Dining" },
    { href: "/trip-planner", icon: Route, label: "AI Trip Planner" },
    { href: "/memories", icon: Book, label: "Memories" },
    { href: "/chatbot", icon: Bot, label: "Travel Assistant" },
    { href: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <div className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="bg-[#003580] text-white">
        <div className="container flex h-10 items-center justify-between text-sm">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <a className="font-bold">TravelAI</a>
            </Link>
            <div className="flex items-center text-white/80">
              {isLoadingLocation ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Detecting location{'.'.repeat((retryCount % 3) + 1)}</span>
                </div>
              ) : (
                <>
                  <MapPin className="h-4 w-4 mr-1" />
                  {currentLocation.city}
                </>
              )}
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 text-white hover:text-white hover:bg-[#00224f] min-w-[2.5rem] flex items-center justify-center"
                >
                  <span className="text-xl leading-none">{selectedCountry.flag}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[200px]">
                {countries.map((country) => (
                  <DropdownMenuItem
                    key={country.code}
                    onClick={() => updateLocationSettings(country.code)}
                    className="flex items-center gap-2"
                  >
                    <span className="text-xl leading-none">{country.flag}</span>
                    <span className="ml-2">{country.name}</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 text-white hover:text-white hover:bg-[#00224f] min-w-[3.5rem] flex items-center justify-center px-2"
                >
                  <span className="font-medium">{currency.symbol}</span>
                  <span className="ml-1 font-medium">{currency.code}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[240px]">
                {currencies.map((curr) => (
                  <DropdownMenuItem
                    key={curr.code}
                    onClick={() => setCurrency(curr)}
                    className="flex items-center justify-between"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-xl leading-none">{curr.flag}</span>
                      <span>{curr.name}</span>
                    </div>
                    <span className="font-medium text-muted-foreground">
                      {curr.symbol} {curr.code}
                    </span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 text-white hover:text-white hover:bg-[#00224f] min-w-[7rem] flex items-center justify-center"
                >
                  <span className="text-xl leading-none">{language.flag}</span>
                  <span className="ml-2">{language.name}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[200px]">
                {languages.map((lang) => (
                  <DropdownMenuItem
                    key={lang.code}
                    onClick={() => setLanguage(lang)}
                    className="flex items-center gap-2"
                  >
                    <span className="text-xl leading-none">{lang.flag}</span>
                    <span className="ml-2">{lang.name}</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      <div className="container flex h-16 items-center">
        <Link href="/">
          <a className="mr-8 flex items-center space-x-2">
            <Plane className="h-6 w-6 text-primary" />
            <span className="hidden font-bold sm:inline-block">
              TravelAI
            </span>
          </a>
        </Link>
        <NavigationMenu>
          <NavigationMenuList>
            {navItems.map(({ href, icon: Icon, label }) => (
              <NavigationMenuItem key={href}>
                <Link href={href}>
                  <a
                    className={cn(
                      "group inline-flex h-10 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground focus:outline-none disabled:pointer-events-none disabled:opacity-50 data-[active]:bg-accent/50 data-[state=open]:bg-accent/50",
                      location === href && "bg-accent text-accent-foreground"
                    )}
                  >
                    <Icon className="mr-2 h-4 w-4" />
                    {label}
                  </a>
                </Link>
              </NavigationMenuItem>
            ))}
          </NavigationMenuList>
        </NavigationMenu>
        <div className="ml-auto">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => logoutMutation.mutate()}
            className="px-4"
          >
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>
    </div>
  );
};

export default TopNav;