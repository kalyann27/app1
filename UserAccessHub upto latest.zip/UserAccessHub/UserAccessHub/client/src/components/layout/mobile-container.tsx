
import React from "react";
import { useIsMobile } from "@/hooks/use-mobile";

interface MobileContainerProps {
  children: React.ReactNode;
  className?: string;
  fullWidth?: boolean;
  noPadding?: boolean;
}

export function MobileContainer({ 
  children, 
  className = "", 
  fullWidth = false,
  noPadding = false 
}: MobileContainerProps) {
  const isMobile = useIsMobile();
  
  return (
    <div 
      className={`
        ${isMobile ? 'max-w-full' : (fullWidth ? 'max-w-full' : 'max-w-7xl')} 
        ${!noPadding ? (isMobile ? 'px-4' : 'px-6 lg:px-8') : ''}
        mx-auto w-full
        ${className}
      `}
    >
      {children}
    </div>
  );
}
