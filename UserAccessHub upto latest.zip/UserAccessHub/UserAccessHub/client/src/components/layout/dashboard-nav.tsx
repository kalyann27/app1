import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import {
  Plane,
  Building2,
  Car,
  UtensilsCrossed,
  User,
  LogOut,
  Book,
  Bot,
  Globe,
  Route,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { FloatingChat } from "@/components/ui/floating-chat";

export default function DashboardNav() {
  const [location] = useLocation();
  const { logoutMutation } = useAuth();

  const navItems = [
    { href: "/flights", icon: Plane, label: "Flights" },
    { href: "/hotels", icon: Building2, label: "Hotels" },
    { href: "/rides", icon: Car, label: "Rides" },
    { href: "/dining", icon: UtensilsCrossed, label: "Dining" },
    { href: "/trip-planner", icon: Route, label: "AI Trip Planner" },
    { href: "/memories", icon: Book, label: "Memories" },
    { href: "/chatbot", icon: Bot, label: "Travel Assistant" },
    { href: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <>
      <nav className="flex flex-col h-full p-4 space-y-2">
        <div className="text-xl font-bold mb-8 text-primary">AITravelGlobe</div>

        <div className="flex flex-col space-y-2">
          {navItems.map(({ href, icon: Icon, label }) => (
            <Link key={href} href={href}>
              <a 
                className={`flex items-center space-x-2 p-2 rounded-lg transition-colors
                  ${location === href 
                    ? "bg-primary text-primary-foreground" 
                    : "hover:bg-primary/10"
                  }`}
              >
                <Icon className="w-5 h-5" />
                <span>{label}</span>
              </a>
            </Link>
          ))}
        </div>

        <div className="mt-auto">
          <Button
            variant="outline"
            className="w-full"
            onClick={() => logoutMutation.mutate()}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </nav>
      <FloatingChat />
    </>
  );
}