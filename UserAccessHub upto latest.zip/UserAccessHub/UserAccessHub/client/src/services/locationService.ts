
import { useState, useEffect } from 'react';

// Options for geolocation API
const geoOptions = {
  enableHighAccuracy: true,
  timeout: 5000,
  maximumAge: 0
};

export class LocationError extends Error {
  code?: number;
  
  constructor(message: string, code?: number) {
    super(message);
    this.name = 'LocationError';
    this.code = code;
  }
}

export async function getCurrentPosition(): Promise<GeolocationPosition> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new LocationError('Geolocation is not supported by this browser'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => resolve(position),
      (error) => {
        let errorMessage: string;
        
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = 'User denied the request for geolocation';
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = 'Location information is unavailable';
            break;
          case error.TIMEOUT:
            errorMessage = 'The request to get user location timed out';
            break;
          default:
            errorMessage = 'An unknown error occurred while retrieving location';
        }
        
        console.warn(`Geolocation error (${error.code}): ${errorMessage}`);
        reject(new LocationError(errorMessage, error.code));
      },
      geoOptions
    );
  });
}

export async function getLocationName(lat: number, lng: number): Promise<string> {
  try {
    const response = await fetch(
      `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lng}&localityLanguage=en`
    );
    
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    
    const data = await response.json();
    return data.city || data.locality || data.principalSubdivision || 'Unknown location';
  } catch (error) {
    console.error('Error getting location name:', error);
    throw new LocationError('Failed to get location name');
  }
}

export function useUserLocation() {
  const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);
  const [locationName, setLocationName] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const detectLocation = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const position = await getCurrentPosition();
      const { latitude, longitude } = position.coords;
      
      setLocation({ lat: latitude, lng: longitude });
      
      try {
        const name = await getLocationName(latitude, longitude);
        setLocationName(name);
      } catch (nameError) {
        console.warn('Could not get location name, but coordinates were obtained');
        // We don't set an error here since we at least have coordinates
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown location error';
      setError(message);
      console.error('Location detection error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    // Optional: Auto-detect on component mount
    // detectLocation();
  }, []);

  return {
    location,
    locationName,
    error,
    isLoading,
    detectLocation
  };
}
