
import { useEffect } from 'react';
import { useIsMobile } from './use-mobile';

export function useMobileOptimization() {
  const isMobile = useIsMobile();
  
  useEffect(() => {
    if (!isMobile) return;
    
    // Handle iOS vh unit bug (100vh includes the address bar)
    const setVh = () => {
      const vh = window.innerHeight * 0.01;
      document.documentElement.style.setProperty('--vh', `${vh}px`);
    };

    // Prevent pull to refresh on mobile browsers
    const preventPullToRefresh = (e: TouchEvent) => {
      const touchY = e.touches[0].clientY;
      const isAtTop = window.scrollY <= 0;
      if (isAtTop && touchY > 10) {
        e.preventDefault();
      }
    };

    // Fast click implementation for eliminating 300ms delay
    const enableFastClick = () => {
      document.addEventListener('touchstart', function() {}, {passive: true});
    };
    
    // Run optimizations
    setVh();
    window.addEventListener('resize', setVh);
    document.addEventListener('touchmove', preventPullToRefresh, { passive: false });
    enableFastClick();
    
    // Clean up
    return () => {
      window.removeEventListener('resize', setVh);
      document.removeEventListener('touchmove', preventPullToRefresh);
    };
  }, [isMobile]);
  
  return isMobile;
}
