import { useState, useEffect } from "react";
import { AnimatePresence } from "framer-motion";
import { LoadingScreen } from "@/components/ui/loading-screen";

export function useLoading(isLoading: boolean, delay = 400) {
  const [showLoading, setShowLoading] = useState(false);

  useEffect(() => {
    let timeout: NodeJS.Timeout;

    if (isLoading) {
      // Add a small delay before showing the loading screen to avoid flicker
      timeout = setTimeout(() => {
        setShowLoading(true);
      }, delay);
    } else {
      setShowLoading(false);
    }

    return () => {
      if (timeout) {
        clearTimeout(timeout);
      }
    };
  }, [isLoading, delay]);

  const LoadingIndicator = () => (
    <AnimatePresence>
      {showLoading && <LoadingScreen />}
    </AnimatePresence>
  );

  return LoadingIndicator;
}
