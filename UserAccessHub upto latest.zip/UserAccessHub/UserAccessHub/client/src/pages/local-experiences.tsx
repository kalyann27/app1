import { LocalExperiences } from "@/components/ui/local-experiences";

export default function LocalExperiencesPage() {
  return (
    <div className="min-h-screen bg-background">
      <LocalExperiences />
    </div>
  );
}
