import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { HotelBooking } from "@shared/schema";
import TopNav from "@/components/layout/top-nav";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { generateHotels } from "@shared/mockData";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Search,
  Calendar,
  Users,
  Wifi,
  Coffee,
  Star,
  Filter,
  MapPin,
} from 'lucide-react';
import { motion } from "framer-motion";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { PaymentForm } from "@/components/ui/payment-form";
import { LocationSearch, type Location } from "@/components/ui/location-search";

const HotelsPage = () => {
  const [filters, setFilters] = useState<{
    rating?: string;
    priceRange?: string;
    amenities?: string[];
  }>({});
  const [showPayment, setShowPayment] = useState(false);
  const [selectedHotel, setSelectedHotel] = useState<HotelBooking | null>(null);
  const [checkIn, setCheckIn] = useState("");
  const [checkOut, setCheckOut] = useState("");
  const [guests, setGuests] = useState("2");
  const [searchKey, setSearchKey] = useState(0);
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);
  const { toast } = useToast();

  const { data: hotels = [], isLoading } = useQuery<HotelBooking[]>({
    queryKey: ["/api/hotels/search", searchKey, selectedLocation?.city, checkIn, checkOut, guests, filters],
    queryFn: async () => {
      try {
        let mockHotels = generateHotels(30);

        if (searchKey === 0) {
          return mockHotels.slice(0, 8);
        }

        if (selectedLocation) {
          const guaranteedMatches = Array(8).fill(null).map((_, index) => ({
            id: `guaranteed-${Math.random()}`,
            name: `${selectedLocation.city} ${['Grand Hotel', 'Plaza', 'Resort & Spa', 'Luxury Suites'][index % 4]}`,
            location: `${selectedLocation.city}, ${selectedLocation.country}`,
            checkIn: checkIn || new Date().toISOString(),
            checkOut: checkOut || new Date(Date.now() + 86400000).toISOString(),
            price: Math.floor(Math.random() * 300) + 200,
            rating: Math.floor(Math.random() * 2) + 4,
            amenities: ["wifi", "pool", "spa", "restaurant", "gym"].slice(0, Math.floor(Math.random() * 3) + 2),
            image: `https://images.unsplash.com/photo-${['1566073771259-6a8506099945', '1582719508461-905c673771fd', '1551882547-ff40c63fe5fa'][index % 3]}?auto=format&fit=crop&w=800`,
            isFavorite: Math.random() > 0.7
          }));
          mockHotels = [...guaranteedMatches, ...mockHotels];
        }

        return mockHotels.filter(hotel => {
          const locationMatch = !selectedLocation?.city ||
            hotel.location.toLowerCase().includes(selectedLocation.city.toLowerCase());

          if (!locationMatch) return false;

          if (filters.rating && hotel.rating < parseInt(filters.rating)) {
            return false;
          }

          if (filters.priceRange) {
            const ranges = {
              budget: { min: 0, max: 150 },
              mid: { min: 151, max: 300 },
              luxury: { min: 301, max: Infinity }
            };
            const range = ranges[filters.priceRange as keyof typeof ranges];
            if (hotel.price < range.min || hotel.price > range.max) {
              return false;
            }
          }

          if (filters.amenities?.length) {
            if (!hotel.amenities) return false;
            if (!filters.amenities.every(amenity => hotel.amenities?.includes(amenity))) {
              return false;
            }
          }

          return true;
        });
      } catch (error) {
        console.error('Error searching hotels:', error);
        return [];
      }
    }
  });

  const handleSearch = () => {
    if (!checkIn || !checkOut) {
      toast({
        title: "Dates Required",
        description: "Please select check-in and check-out dates",
        variant: "destructive",
      });
      return;
    }

    setSearchKey(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      <TopNav />

      {/* Hero Section with Search */}
      <div className="relative bg-[#00224f] text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-[#00224f] to-[#003580] opacity-90" />
        <div className="container mx-auto px-4 py-16 relative">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-4xl mx-auto text-center mb-12"
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-4">
              Find Your Perfect Stay
            </h1>
            <p className="text-xl opacity-90">
              Book hotels, resorts, and unique accommodations worldwide
            </p>
          </motion.div>

          {/* Search Box */}
          <Card className="bg-white shadow-xl border-0">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                {/* Location Search */}
                <div className="md:col-span-4">
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Where are you going?
                  </label>
                  <LocationSearch
                    onLocationSelect={setSelectedLocation}
                    className="w-full"
                  />
                </div>

                {/* Check-in Date */}
                <div className="md:col-span-3">
                  <label className="text-sm font-medium text-gray-700 flex items-center gap-2 mb-2">
                    <Calendar className="w-4 h-4" /> Check-in
                  </label>
                  <Input
                    type="date"
                    value={checkIn}
                    onChange={(e) => setCheckIn(e.target.value)}
                    className="w-full border-2 border-gray-200 focus:border-[#003580]"
                    min={format(new Date(), 'yyyy-MM-dd')}
                  />
                </div>

                {/* Check-out Date */}
                <div className="md:col-span-3">
                  <label className="text-sm font-medium text-gray-700 flex items-center gap-2 mb-2">
                    <Calendar className="w-4 h-4" /> Check-out
                  </label>
                  <Input
                    type="date"
                    value={checkOut}
                    onChange={(e) => setCheckOut(e.target.value)}
                    className="w-full border-2 border-gray-200 focus:border-[#003580]"
                    min={checkIn || format(new Date(), 'yyyy-MM-dd')}
                  />
                </div>

                {/* Guests Field */}
                <div className="md:col-span-2">
                  <label className="text-sm font-medium text-gray-700 flex items-center gap-2 mb-2">
                    <Users className="w-4 h-4" /> Guests
                  </label>
                  <Select value={guests} onValueChange={setGuests}>
                    <SelectTrigger className="w-full border-2 border-gray-200 focus:border-[#003580]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5, 6].map((num) => (
                        <SelectItem key={num} value={num.toString()}>
                          {num} {num === 1 ? "Guest" : "Guests"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="md:col-span-12">
                  <Button
                    onClick={handleSearch}
                    className="w-full mt-6 h-12 text-lg bg-[#003580] hover:bg-[#00224f] text-white"
                    size="lg"
                  >
                    <Search className="w-5 h-5 mr-2" /> Search Hotels
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          {/* Filters Sidebar */}
          <div className="md:col-span-3">
            <Card className="bg-white sticky top-4">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-4 pb-4 border-b">
                  <Filter className="w-4 h-4 text-[#003580]" />
                  <h3 className="font-semibold text-[#003580]">Filter Properties</h3>
                </div>

                <div className="space-y-6">
                  {/* Star Rating */}
                  <div>
                    <h4 className="text-sm font-medium mb-3">Star Rating</h4>
                    <div className="space-y-2">
                      {[5, 4, 3, 2, 1].map((rating) => (
                        <label key={rating} className="flex items-center cursor-pointer">
                          <input
                            type="radio"
                            checked={filters.rating === rating.toString()}
                            onChange={() => setFilters({ ...filters, rating: rating.toString() })}
                            className="w-4 h-4 border-2 border-gray-300 rounded-full text-[#003580]"
                          />
                          <span className="ml-2 flex items-center">
                            {Array.from({ length: rating }).map((_, i) => (
                              <Star key={i} className="w-4 h-4 fill-[#febb02] text-[#febb02]" />
                            ))}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Price Range */}
                  <div className="border-t pt-4">
                    <h4 className="text-sm font-medium mb-3">Your Budget</h4>
                    <div className="space-y-2">
                      {[
                        { label: "$0 - $150", value: "budget" },
                        { label: "$151 - $300", value: "mid" },
                        { label: "$301+", value: "luxury" },
                      ].map(({ label, value }) => (
                        <label key={value} className="flex items-center cursor-pointer">
                          <input
                            type="radio"
                            checked={filters.priceRange === value}
                            onChange={() => setFilters({ ...filters, priceRange: value })}
                            className="w-4 h-4 border-2 border-gray-300 rounded-full text-[#003580]"
                          />
                          <span className="ml-2 text-sm">{label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Amenities */}
                  <div className="border-t pt-4">
                    <h4 className="text-sm font-medium mb-3">Popular Amenities</h4>
                    <div className="space-y-2">
                      {[
                        { icon: Wifi, label: "Free WiFi" },
                        { icon: Coffee, label: "Breakfast Included" },
                      ].map(({ icon: Icon, label }) => (
                        <label key={label} className="flex items-center cursor-pointer">
                          <input
                            type="checkbox"
                            checked={filters.amenities?.includes(label)}
                            onChange={() => {
                              const newAmenities = filters.amenities?.includes(label)
                                ? filters.amenities.filter((a) => a !== label)
                                : [...(filters.amenities || []), label];
                              setFilters({ ...filters, amenities: newAmenities });
                            }}
                            className="w-4 h-4 border-2 border-gray-300 rounded text-[#003580]"
                          />
                          <Icon className="w-4 h-4 mx-2 text-gray-500" />
                          <span className="text-sm">{label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Hotel Listings */}
          <div className="md:col-span-9 space-y-4">
            {isLoading ? (
              Array(3).fill(0).map((_, i) => (
                <Card key={i} className="bg-white p-6">
                  <div className="flex items-center space-x-4">
                    <Skeleton className="h-32 w-48" />
                    <div className="flex-1">
                      <Skeleton className="h-6 w-48 mb-2" />
                      <Skeleton className="h-4 w-72 mb-4" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                    <div className="text-right">
                      <Skeleton className="h-8 w-24 mb-2" />
                      <Skeleton className="h-10 w-32" />
                    </div>
                  </div>
                </Card>
              ))
            ) : (
              hotels?.map((hotel) => (
                <motion.div
                  key={hotel.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <Card className="bg-white hover:shadow-lg transition-all duration-300">
                    <CardContent className="p-6">
                      <div className="flex gap-6">
                        {/* Hotel card image section */}
                        <div
                          className="w-48 h-32 bg-cover bg-center rounded-lg relative"
                          style={{
                            backgroundImage: `url(${
                              hotel.image ||
                              'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=1470'
                            })`
                          }}
                        >
                          {hotel.price < 200 && (
                            <Badge className="absolute top-2 left-2 bg-green-600">
                              Deal
                            </Badge>
                          )}
                        </div>

                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="text-xl font-semibold text-[#003580] mb-2">
                                {hotel.name}
                              </h3>
                              <div className="flex items-center gap-2 mb-3">
                                <div className="flex">
                                  {Array.from({ length: hotel.rating }).map((_, i) => (
                                    <Star
                                      key={i}
                                      className="w-4 h-4 fill-[#febb02] text-[#febb02]"
                                    />
                                  ))}
                                </div>
                                <span className="text-sm text-gray-500">
                                  {hotel.rating} Star Hotel
                                </span>
                              </div>
                              <p className="text-sm text-gray-500 flex items-center mb-4">
                                <MapPin className="w-4 h-4 mr-1" />
                                {hotel.location}
                              </p>
                            </div>

                            <div className="text-right">
                              <div className="text-3xl font-bold text-[#003580] mb-2">
                                ${hotel.price}
                              </div>
                              <div className="text-sm text-gray-500 mb-4">per night</div>
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button
                                    className="bg-[#003580] hover:bg-[#00224f]"
                                    onClick={() => setSelectedHotel(hotel)}
                                  >
                                    See availability
                                  </Button>
                                </DialogTrigger>
                                <DialogContent className="sm:max-w-[800px]">
                                  <PaymentForm
                                    amount={hotel.price}
                                    bookingDetails={{
                                      type: "Hotel Booking",
                                      description: `${hotel.name} - ${hotel.location}\nCheck-in: ${format(
                                        new Date(hotel.checkIn),
                                        "MMM d, yyyy"
                                      )}\nCheck-out: ${format(
                                        new Date(hotel.checkOut),
                                        "MMM d, yyyy"
                                      )}`,
                                    }}
                                    onSuccess={() => {
                                      setShowPayment(false);
                                      setSelectedHotel(null);
                                      toast({
                                        title: "Booking Successful",
                                        description: "Your hotel has been booked successfully!",
                                      });
                                    }}
                                    onError={(message: string) => {
                                      toast({
                                        title: "Payment Failed",
                                        description: message,
                                        variant: "destructive",
                                      });
                                    }}
                                  />
                                </DialogContent>
                              </Dialog>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HotelsPage;