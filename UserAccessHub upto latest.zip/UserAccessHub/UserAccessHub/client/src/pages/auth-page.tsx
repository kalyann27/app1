import { useAuth } from "@/hooks/use-auth";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { insertUserSchema, phoneVerificationSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import {
  Plane,
  Shield,
  Clock,
  Bot,
  Map,
  Brain,
  Sparkles,
  User,
  Phone,
  LockKeyhole
} from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Logo } from "@/components/ui/logo";
import { SiGoogle } from "react-icons/si";

const loginSchema = insertUserSchema.pick({
  username: true,
  password: true,
}).transform((data) => ({
  ...data,
  // Allow either email or phone number in username field
  username: data.username.trim(),
}));

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [showOTPDialog, setShowOTPDialog] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [isPhoneVerified, setIsPhoneVerified] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    if (user) {
      setLocation("/");
    }
  }, [user, setLocation]);

  const form = useForm({
    resolver: zodResolver(insertUserSchema),
    defaultValues: {
      username: "",
      password: "",
      phone_number: "",
    },
  });

  const loginForm = useForm({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const otpForm = useForm({
    resolver: zodResolver(phoneVerificationSchema.pick({ otp: true })),
    defaultValues: {
      otp: "",
    },
  });

  const sendOTPMutation = useMutation({
    mutationFn: async (phone_number: string) => {
      const res = await apiRequest("POST", "/api/send-otp", { phone_number });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message);
      }
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "OTP Sent",
        description: "Please check your phone for the verification code.",
      });
      setShowOTPDialog(true);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send OTP",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const verifyOTPMutation = useMutation({
    mutationFn: async (data: { phone_number: string; otp: string }) => {
      const res = await apiRequest("POST", "/api/verify-otp", data);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message);
      }
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Phone Verified",
        description: "Your phone number has been verified successfully.",
      });
      setIsPhoneVerified(true);
      setShowOTPDialog(false);

      // Proceed with registration after successful verification
      const formData = form.getValues();
      registerMutation.mutate(formData);
    },
    onError: (error: Error) => {
      toast({
        title: "Verification Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handlePhoneVerification = (phone: string) => {
    if (!phone) {
      toast({
        title: "Phone Required",
        description: "Please enter a phone number to proceed.",
        variant: "destructive",
      });
      return;
    }
    setPhoneNumber(phone);
    sendOTPMutation.mutate(phone);
  };

  const handleVerifyOTP = (data: { otp: string }) => {
    console.log("Verifying OTP:", { phoneNumber, otp: data.otp });
    verifyOTPMutation.mutate({
      phone_number: phoneNumber,
      otp: data.otp,
    });
  };

  const handleLogin = async (data: { username: string; password: string }) => {
    try {
      await loginMutation.mutateAsync(data);
    } catch (error) {
      toast({
        title: "Login Failed",
        description: error instanceof Error ? error.message : "An unexpected error occurred",
        variant: "destructive",
      });
    }
  };

  const handleGuestLogin = async () => {
    try {
      const response = await fetch("/api/guest-login", {
        method: "POST",
        credentials: "include",
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Guest login failed");
      }

      const user = await response.json();
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Welcome Guest!",
        description: "You've been logged in as a guest user.",
      });
    } catch (error) {
      toast({
        title: "Login Failed",
        description: error instanceof Error ? error.message : "An unexpected error occurred",
        variant: "destructive",
      });
    }
  };

  const handleGoogleLogin = () => {
    try {
      // Show loading toast
      toast({
        title: "Redirecting to Google",
        description: "Please wait while we connect to Google's authentication service...",
      });
      
      // Get the full origin including protocol
      const currentHost = window.location.origin;
      
      // Log the redirect URL for debugging
      console.log("Redirecting to Google OAuth:", `${currentHost}/auth/google`);
      
      // Redirect to Google OAuth
      window.location.href = `${currentHost}/auth/google`;
    } catch (error) {
      console.error("Google login error:", error);
      toast({
        title: "Google Login Failed",
        description: "Could not connect to Google authentication. Please try again later.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <header className="relative">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&q=80')] bg-cover bg-center">
          <div className="absolute inset-0 bg-[#003580]/90" />
        </div>
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
          <Logo size="lg" className="mb-4 sm:mb-6" />
          <div className="mt-4 sm:mt-6 max-w-xl">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-3 sm:mb-4">
              Your Journey Begins Here
            </h2>
            <p className="text-lg sm:text-xl text-white/90">
              Join millions of travelers who choose AItravelGlobe for the best deals and personalized experiences
            </p>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto py-8 sm:py-12 px-4 sm:px-6">
        <div className="grid lg:grid-cols-2 gap-8 sm:gap-12">
          <div className="w-full">
            <Card className="border-0 shadow-xl">
              <CardHeader className="space-y-1 pb-4">
                <CardTitle className="text-xl sm:text-2xl">Sign in or create an account</CardTitle>
                <CardDescription>
                  Manage your bookings and get personalized recommendations
                  <div className="mt-2 text-sm bg-gray-50 p-2 rounded">
                    <strong>Test Account:</strong> test@example.com / test123
                  </div>
                </CardDescription>
              </CardHeader>

              <CardContent>
                <Tabs defaultValue="login" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 mb-6 sm:mb-8">
                    <TabsTrigger value="login">Sign in</TabsTrigger>
                    <TabsTrigger value="register">Create account</TabsTrigger>
                  </TabsList>

                  <TabsContent value="login">
                    <Form {...loginForm}>
                      <form
                        onSubmit={loginForm.handleSubmit(handleLogin)}
                        className="space-y-4"
                      >
                        <FormField
                          control={loginForm.control}
                          name="username"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-700">Email or Phone number</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                                  <Input
                                    {...field}
                                    className="pl-10 h-12 bg-white border-2"
                                    placeholder="Email or phone (e.g. +1234567890)"
                                  />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={loginForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-700">Password</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <LockKeyhole className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                                  <Input
                                    type="password"
                                    {...field}
                                    className="pl-10 h-12 bg-white border-2"
                                  />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button
                          type="submit"
                          className="w-full h-12 bg-[#006CE4] hover:bg-[#003580] text-white font-semibold"
                          disabled={loginMutation.isPending}
                        >
                          {loginMutation.isPending ? "Signing in..." : "Sign in"}
                        </Button>
                      </form>
                    </Form>

                    <div className="mt-4 space-y-4">
                      <Button
                        onClick={handleGoogleLogin}
                        variant="outline"
                        className="w-full h-12 border-2 flex items-center justify-center gap-2 hover:bg-gray-50 touch-manipulation"
                      >
                        <SiGoogle className="w-5 h-5 text-[#4285F4]" />
                        Continue with Google
                      </Button>

                      <div className="relative">
                        <div className="absolute inset-0 flex items-center">
                          <span className="w-full border-t" />
                        </div>
                        <div className="relative flex justify-center text-xs uppercase">
                          <span className="bg-white px-2 text-gray-500">Or</span>
                        </div>
                      </div>

                      <Button
                        onClick={handleGuestLogin}
                        variant="outline"
                        className="w-full h-12 border-2 border-[#006CE4] text-[#006CE4] hover:bg-[#006CE4] hover:text-white font-semibold touch-manipulation"
                      >
                        Continue as Guest
                      </Button>
                    </div>
                  </TabsContent>

                  <TabsContent value="register">
                    <Form {...form}>
                      <form
                        onSubmit={form.handleSubmit((data) => registerMutation.mutate(data))}
                        className="space-y-4"
                      >
                        <FormField
                          control={form.control}
                          name="username"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-700">Email address</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                                  <Input {...field} className="pl-10 h-12 bg-white border-2" />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="phone_number"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-700">Phone number (E.164 format)</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Phone className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                                  <Input
                                    {...field}
                                    placeholder="+1234567890"
                                    className="pl-10 h-12 bg-white border-2"
                                  />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-gray-700">Password</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <LockKeyhole className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                                  <Input
                                    type="password"
                                    {...field}
                                    className="pl-10 h-12 bg-white border-2"
                                  />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button
                          type="button"
                          onClick={() => handlePhoneVerification(form.getValues("phone_number"))}
                          className="w-full h-12 bg-[#006CE4] hover:bg-[#003580] text-white font-semibold"
                          disabled={registerMutation.isPending || sendOTPMutation.isPending || verifyOTPMutation.isPending}
                        >
                          {sendOTPMutation.isPending
                            ? "Sending OTP..."
                            : verifyOTPMutation.isPending
                            ? "Verifying..."
                            : registerMutation.isPending
                            ? "Creating account..."
                            : "Create account"}
                        </Button>
                      </form>
                    </Form>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6 order-first lg:order-last">
            <h2 className="text-xl sm:text-2xl font-semibold text-[#003580]">
              Benefits of having an account
            </h2>
            <div className="grid gap-4 sm:gap-6">
              {[
                {
                  icon: Brain,
                  title: "AI-Powered Trip Planning",
                  description: "Get personalized itineraries with our advanced AI planner",
                  image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=300",
                },
                {
                  icon: Bot,
                  title: "Smart Travel Assistant",
                  description: "24/7 AI assistance for recommendations and support",
                  image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&q=80&w=300",
                },
                {
                  icon: Map,
                  title: "Intelligent Recommendations",
                  description: "AI learns your preferences for better travel suggestions",
                  image: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&q=80&w=300",
                },
                {
                  icon: Clock,
                  title: "Time-Saving Features",
                  description: "Quick bookings with smart auto-fill and preferences",
                  image: "https://images.unsplash.com/photo-1495616811223-4d98c6e9c869?auto=format&fit=crop&q=80&w=300",
                },
                {
                  icon: Shield,
                  title: "Secure Booking",
                  description: "Your data is protected with bank-level security",
                  image: "https://images.unsplash.com/photo-1517840901100-8179e982acb7?auto=format&fit=crop&q=80&w=300",
                },
                {
                  icon: Sparkles,
                  title: "Premium AI Features",
                  description: "Exclusive access to advanced travel planning tools",
                  image: "https://images.unsplash.com/photo-1579547621113-e4bb2a19bdd6?auto=format&fit=crop&q=80&w=300",
                },
              ].map((benefit, index) => (
                <motion.div
                  key={benefit.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center space-x-4 p-3 sm:p-4 rounded-lg bg-white shadow-lg hover:shadow-xl transition-shadow"
                >
                  <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-lg overflow-hidden flex-shrink-0">
                    <img
                      src={benefit.image}
                      alt={benefit.title}
                      className="object-cover w-full h-full"
                    />
                    <div className="absolute inset-0 bg-[#003580]/10" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 sm:mb-2">
                      <div className="p-1.5 sm:p-2 rounded-full bg-[#003580] text-white">
                        <benefit.icon className="w-4 h-4 sm:w-5 sm:h-5" />
                      </div>
                      <h3 className="font-semibold text-[#003580] truncate">{benefit.title}</h3>
                    </div>
                    <p className="text-sm sm:text-base text-gray-600 line-clamp-2">{benefit.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </main>

      <Dialog open={showOTPDialog} onOpenChange={setShowOTPDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Phone Verification</DialogTitle>
            <DialogDescription>
              Enter the verification code sent to your phone number {phoneNumber}
            </DialogDescription>
          </DialogHeader>
          <Form {...otpForm}>
            <form onSubmit={otpForm.handleSubmit(handleVerifyOTP)} className="space-y-4">
              <FormField
                control={otpForm.control}
                name="otp"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Verification Code</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Enter 6-digit code" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end gap-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => handlePhoneVerification(phoneNumber)}
                  disabled={sendOTPMutation.isPending}
                >
                  Resend Code
                </Button>
                <Button type="submit" disabled={verifyOTPMutation.isPending}>
                  {verifyOTPMutation.isPending ? "Verifying..." : "Verify"}
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}