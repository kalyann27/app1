import { useState } from "react";
import DashboardNav from "@/components/layout/dashboard-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { aiService } from "@/lib/ai-service";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Loader2, Calendar, DollarSign, TrendingUp, AlertCircle } from "lucide-react";

interface BudgetPrediction {
  monthlySpending: Array<{
    month: string;
    predicted: number;
    actual?: number;
  }>;
  recommendations: string[];
  savingsPotential: number;
  riskFactors: string[];
}

export default function BudgetForecastPage() {
  const { toast } = useToast();
  const [destination, setDestination] = useState("");
  const [duration, setDuration] = useState("7");
  const [budget, setBudget] = useState("");
  const [prediction, setPrediction] = useState<BudgetPrediction | null>(null);

  const predictMutation = useMutation({
    mutationFn: async () => {
      return await aiService.predictBudget({
        destination,
        duration: parseInt(duration),
        budget: parseFloat(budget),
      });
    },
    onSuccess: (data) => {
      setPrediction(data);
    },
    onError: (error: Error) => {
      toast({
        title: "Prediction Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <div className="flex min-h-screen bg-gradient-to-b from-background to-secondary/10">
      <aside className="w-64 border-r bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <DashboardNav />
      </aside>
      <main className="flex-1 overflow-hidden">
        <div className="h-full flex flex-col">
          {/* Header Section */}
          <div className="bg-primary/5 border-b px-8 py-6">
            <div className="max-w-7xl mx-auto">
              <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                Travel Budget Forecast
              </h1>
              <p className="text-lg text-muted-foreground mt-2">
                Get AI-powered predictions for your travel expenses
              </p>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 px-8 py-6 overflow-auto">
            <div className="max-w-7xl mx-auto">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Input Section */}
                <Card className="lg:col-span-1">
                  <CardHeader>
                    <CardTitle>Enter Trip Details</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Destination</label>
                      <Input
                        placeholder="e.g., Paris, France"
                        value={destination}
                        onChange={(e) => setDestination(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Duration (days)</label>
                      <Select value={duration} onValueChange={setDuration}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select duration" />
                        </SelectTrigger>
                        <SelectContent>
                          {[3, 5, 7, 10, 14, 21, 30].map((days) => (
                            <SelectItem key={days} value={days.toString()}>
                              {days} days
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Total Budget ($)</label>
                      <Input
                        type="number"
                        placeholder="e.g., 5000"
                        value={budget}
                        onChange={(e) => setBudget(e.target.value)}
                      />
                    </div>

                    <Button 
                      className="w-full" 
                      onClick={() => predictMutation.mutate()}
                      disabled={predictMutation.isPending || !destination || !duration || !budget}
                    >
                      {predictMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Analyzing...
                        </>
                      ) : (
                        "Generate Forecast"
                      )}
                    </Button>
                  </CardContent>
                </Card>

                {/* Results Section */}
                <div className="lg:col-span-2 space-y-6">
                  {prediction && (
                    <>
                      {/* Spending Chart */}
                      <Card>
                        <CardHeader>
                          <CardTitle>Spending Forecast</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="h-[300px]">
                            <ResponsiveContainer width="100%" height="100%">
                              <LineChart data={prediction.monthlySpending}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="month" />
                                <YAxis />
                                <Tooltip />
                                <Line 
                                  type="monotone" 
                                  dataKey="predicted" 
                                  stroke="#006CE4" 
                                  strokeWidth={2}
                                  name="Predicted Spending"
                                />
                                {prediction.monthlySpending.some(m => m.actual) && (
                                  <Line 
                                    type="monotone" 
                                    dataKey="actual" 
                                    stroke="#10B981" 
                                    strokeWidth={2}
                                    name="Actual Spending"
                                  />
                                )}
                              </LineChart>
                            </ResponsiveContainer>
                          </div>
                        </CardContent>
                      </Card>

                      {/* Key Insights */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Recommendations */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                              <TrendingUp className="w-5 h-5" />
                              Recommendations
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <ul className="space-y-2">
                              {prediction.recommendations.map((rec, index) => (
                                <li key={index} className="flex items-start gap-2">
                                  <span className="text-primary">•</span>
                                  <span>{rec}</span>
                                </li>
                              ))}
                            </ul>
                          </CardContent>
                        </Card>

                        {/* Risk Factors */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                              <AlertCircle className="w-5 h-5" />
                              Risk Factors
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <ul className="space-y-2">
                              {prediction.riskFactors.map((risk, index) => (
                                <li key={index} className="flex items-start gap-2 text-destructive">
                                  <span>•</span>
                                  <span>{risk}</span>
                                </li>
                              ))}
                            </ul>
                          </CardContent>
                        </Card>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}