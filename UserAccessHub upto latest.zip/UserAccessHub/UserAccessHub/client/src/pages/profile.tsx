import { useAuth } from "@/hooks/use-auth";
import DashboardNav from "@/components/layout/dashboard-nav";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { useState, useMemo } from "react";
import {
  CreditCard,
  Plane,
  Building2,
  Car,
  UtensilsCrossed,
} from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { BudgetBreakdown } from "@/components/ui/budget-visualization";


export default function ProfilePage() {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<"preferences" | "payments" | "history">("preferences");
  const queryClient = useQueryClient();

  const form = useForm({
    defaultValues: {
      preferredClass: user?.preferences?.preferredClass || "",
      budget: user?.preferences?.budget || "",
      cuisinePreferences: user?.preferences?.cuisinePreferences || [],
      travelStyle: user?.preferences?.travelStyle || [],
      favoriteDestinations: user?.preferences?.favoriteDestinations || [],
      accommodationPreferences: user?.preferences?.accommodationPreferences || [],
      interests: user?.preferences?.interests || [],
      transportPreferences: user?.preferences?.transportPreferences || [],
      climatePreference: user?.preferences?.climatePreference || "",
      tripDurationPreference: user?.preferences?.tripDurationPreference || "",
    },
  });

  const updatePreferencesMutation = useMutation({
    mutationFn: async (preferences: any) => {
      const res = await apiRequest("POST", "/api/preferences", preferences);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      useToast({
        title: "Preferences Updated",
        description: "Your travel preferences have been saved.",
      });
    },
    onError: (error: Error) => {
      useToast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const budgetData = useMemo(() => {
    const monthlyBudget = Number(user?.preferences?.budget) || 5000;
    return {
      total: monthlyBudget,
      data: [
        {
          category: "Flights",
          amount: monthlyBudget * 0.4,
          color: "#FF6B6B",
        },
        {
          category: "Hotels",
          amount: monthlyBudget * 0.3,
          color: "#4ECDC4",
        },
        {
          category: "Dining",
          amount: monthlyBudget * 0.15,
          color: "#45B7D1",
        },
        {
          category: "Transportation",
          amount: monthlyBudget * 0.1,
          color: "#96CEB4",
        },
        {
          category: "Activities",
          amount: monthlyBudget * 0.05,
          color: "#FFEEAD",
        },
      ],
    };
  }, [user?.preferences?.budget]);

  return (
    <div className="flex h-screen">
      <aside className="w-64 border-r">
        <DashboardNav />
      </aside>
      <main className="flex-1 overflow-y-auto p-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold mb-6">Profile Settings</h1>

          <div className="flex space-x-4 mb-6">
            <Button
              variant={activeTab === "preferences" ? "default" : "outline"}
              onClick={() => setActiveTab("preferences")}
            >
              Preferences
            </Button>
            <Button
              variant={activeTab === "payments" ? "default" : "outline"}
              onClick={() => setActiveTab("payments")}
            >
              Payment Methods
            </Button>
            <Button
              variant={activeTab === "history" ? "default" : "outline"}
              onClick={() => setActiveTab("history")}
            >
              Booking History
            </Button>
          </div>

          {activeTab === "preferences" && (
            <>
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Travel Preferences</CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form
                      onSubmit={form.handleSubmit((data) =>
                        updatePreferencesMutation.mutate(data)
                      )}
                      className="space-y-6"
                    >
                      <FormField
                        control={form.control}
                        name="preferredClass"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Preferred Flight Class</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select preferred class" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="economy">Economy</SelectItem>
                                <SelectItem value="premium_economy">Premium Economy</SelectItem>
                                <SelectItem value="business">Business</SelectItem>
                                <SelectItem value="first">First Class</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="budget"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Monthly Travel Budget</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                placeholder="Enter amount"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="travelStyle"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Travel Style</FormLabel>
                            <Select
                              onValueChange={(value) =>
                                field.onChange([...field.value, value])
                              }
                              value={field.value[0]}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select travel styles" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="luxury">Luxury</SelectItem>
                                <SelectItem value="adventure">Adventure</SelectItem>
                                <SelectItem value="cultural">Cultural</SelectItem>
                                <SelectItem value="budget">Budget</SelectItem>
                                <SelectItem value="family">Family</SelectItem>
                              </SelectContent>
                            </Select>
                            <div className="flex flex-wrap gap-2 mt-2">
                              {field.value.map((style) => (
                                <Badge
                                  key={style}
                                  variant="secondary"
                                  className="cursor-pointer"
                                  onClick={() => {
                                    field.onChange(field.value.filter((s) => s !== style));
                                  }}
                                >
                                  {style} ✕
                                </Badge>
                              ))}
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="interests"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Interests</FormLabel>
                            <Select
                              onValueChange={(value) =>
                                field.onChange([...field.value, value])
                              }
                              value={field.value[0]}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select your interests" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="history">History & Culture</SelectItem>
                                <SelectItem value="food">Food & Cuisine</SelectItem>
                                <SelectItem value="nature">Nature & Outdoors</SelectItem>
                                <SelectItem value="shopping">Shopping</SelectItem>
                                <SelectItem value="relaxation">Relaxation</SelectItem>
                              </SelectContent>
                            </Select>
                            <div className="flex flex-wrap gap-2 mt-2">
                              {field.value.map((interest) => (
                                <Badge
                                  key={interest}
                                  variant="secondary"
                                  className="cursor-pointer"
                                  onClick={() => {
                                    field.onChange(field.value.filter((i) => i !== interest));
                                  }}
                                >
                                  {interest} ✕
                                </Badge>
                              ))}
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="climatePreference"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Preferred Climate</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select climate preference" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="warm">Warm</SelectItem>
                                <SelectItem value="cold">Cold</SelectItem>
                                <SelectItem value="moderate">Moderate</SelectItem>
                                <SelectItem value="tropical">Tropical</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="tripDurationPreference"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Preferred Trip Duration</FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select preferred duration" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="weekend">Weekend Getaway</SelectItem>
                                <SelectItem value="week">1 Week</SelectItem>
                                <SelectItem value="twoWeeks">2 Weeks</SelectItem>
                                <SelectItem value="longTerm">Long Term</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button
                        type="submit"
                        disabled={updatePreferencesMutation.isPending}
                      >
                        {updatePreferencesMutation.isPending ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          "Save Preferences"
                        )}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
              <BudgetBreakdown data={budgetData.data} total={budgetData.total} />
            </>
          )}

          {activeTab === "payments" && (
            <Card>
              <CardHeader>
                <CardTitle>Payment Methods</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Card>
                    <CardContent className="p-4 flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <CreditCard className="h-6 w-6" />
                        <div>
                          <div className="font-medium">•••• •••• •••• 4242</div>
                          <div className="text-sm text-muted-foreground">
                            Expires 12/24
                          </div>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        Remove
                      </Button>
                    </CardContent>
                  </Card>
                  <Button className="w-full">Add New Payment Method</Button>
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === "history" && (
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Plane className="w-5 h-5 mr-2" />
                    Flight Bookings
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-sm text-muted-foreground">
                    No flight bookings yet
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Building2 className="w-5 h-5 mr-2" />
                    Hotel Bookings
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-sm text-muted-foreground">
                    No hotel bookings yet
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Car className="w-5 h-5 mr-2" />
                    Ride History
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-sm text-muted-foreground">
                    No ride history yet
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <UtensilsCrossed className="w-5 h-5 mr-2" />
                    Dining Reservations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-sm text-muted-foreground">
                    No dining reservations yet
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}