import { TravelChatbot } from "@/components/ui/travel-chatbot";
import DashboardNav from "@/components/layout/dashboard-nav";
import { MessageSquare } from "lucide-react";

export default function ChatbotPage() {
  return (
    <div className="flex min-h-screen bg-gradient-to-b from-background to-secondary/10">
      <aside className="w-64 border-r bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <DashboardNav />
      </aside>
      <main className="flex-1 overflow-y-auto">
        <div className="bg-primary/10 p-8 relative">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center gap-3 mb-2">
              <MessageSquare className="w-8 h-8 text-primary" />
              <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                Travel Companion
              </h1>
            </div>
            <p className="text-lg text-muted-foreground mb-6">
              Your personal AI travel assistant is here to help plan your perfect trip
            </p>
          </div>
        </div>

        <div className="max-w-6xl mx-auto p-8">
          <div className="bg-card rounded-lg shadow-lg overflow-hidden">
            <TravelChatbot />
          </div>
        </div>
      </main>
    </div>
  );
}