import { useState } from "react";
import DashboardNav from "@/components/layout/dashboard-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/api";
import { Loader2, Globe, Clock, Users, Palette, MapPin, Calendar } from "lucide-react";
import { LocationSearch } from "@/components/ui/location-search";
import { motion } from "framer-motion";
import { TripPlan, TripPreferences } from "@/lib/ai-service";

export default function TripPlannerPage() {
  const { toast } = useToast();
  const [destination, setDestination] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [pace, setPace] = useState<TripPreferences['pace']>("moderate");
  const [tripPlan, setTripPlan] = useState<TripPlan | null>(null);

  const planMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/ai/trip-plan", {
        destination,
        dates: { start: startDate, end: endDate },
        preferences: {
          pace,
          interests: [], // TODO: Add interests selection
          mustSeeAttractions: [],
          avoidTypes: [],
          mealPreferences: [],
          budgetLevel: "moderate",
          transportationPreferences: []
        }
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to generate trip plan');
      }

      return response.json();
    },
    onSuccess: (data) => {
      setTripPlan(data.plan);
      toast({
        title: "Trip Plan Generated",
        description: "Your personalized itinerary is ready!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Generation Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <div className="flex min-h-screen bg-gradient-to-b from-background to-secondary/10">
      <aside className="w-64 border-r bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <DashboardNav />
      </aside>
      <main className="flex-1 overflow-hidden">
        <div className="h-full flex flex-col">
          {/* Header Section */}
          <div className="bg-primary/5 border-b px-8 py-6">
            <div className="max-w-7xl mx-auto">
              <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
                AI Trip Planner
              </h1>
              <p className="text-lg text-muted-foreground mt-2">
                Let AI create your perfect travel itinerary
              </p>
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 px-8 py-6 overflow-auto">
            <div className="max-w-7xl mx-auto">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Input Section */}
                <Card className="lg:col-span-1">
                  <CardHeader>
                    <CardTitle>Plan Your Trip</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Destination</label>
                      <LocationSearch
                        onLocationSelect={(location) => setDestination(location?.city || "")}
                        className="w-full"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Start Date</label>
                      <Input
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                        min={new Date().toISOString().split('T')[0]}
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">End Date</label>
                      <Input
                        type="date"
                        value={endDate}
                        onChange={(e) => setEndDate(e.target.value)}
                        min={startDate || new Date().toISOString().split('T')[0]}
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Trip Pace</label>
                      <Select value={pace} onValueChange={(value: TripPreferences['pace']) => setPace(value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="relaxed">Relaxed</SelectItem>
                          <SelectItem value="moderate">Moderate</SelectItem>
                          <SelectItem value="intensive">Intensive</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Button
                      className="w-full mt-4"
                      onClick={() => planMutation.mutate()}
                      disabled={planMutation.isPending || !destination || !startDate || !endDate}
                    >
                      {planMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Generating Plan...
                        </>
                      ) : (
                        "Generate AI Travel Plan"
                      )}
                    </Button>
                  </CardContent>
                </Card>

                {/* Results Section */}
                <div className="lg:col-span-2">
                  {tripPlan ? (
                    <div className="space-y-6">
                      {/* Trip Overview */}
                      <Card>
                        <CardHeader>
                          <CardTitle>Your Travel Plan</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                              <div className="flex flex-col items-center p-4 bg-primary/5 rounded-lg">
                                <Calendar className="h-6 w-6 text-primary mb-2" />
                                <span className="text-sm font-medium">Duration</span>
                                <span className="text-lg">{tripPlan.duration} Days</span>
                              </div>
                              <div className="flex flex-col items-center p-4 bg-primary/5 rounded-lg">
                                <Globe className="h-6 w-6 text-primary mb-2" />
                                <span className="text-sm font-medium">Destination</span>
                                <span className="text-lg">{tripPlan.destination}</span>
                              </div>
                              <div className="flex flex-col items-center p-4 bg-primary/5 rounded-lg">
                                <Clock className="h-6 w-6 text-primary mb-2" />
                                <span className="text-sm font-medium">Pace</span>
                                <span className="text-lg capitalize">{tripPlan.preferences?.pace}</span>
                              </div>
                              <div className="flex flex-col items-center p-4 bg-primary/5 rounded-lg">
                                <Palette className="h-6 w-6 text-primary mb-2" />
                                <span className="text-sm font-medium">Activities</span>
                                <span className="text-lg">{tripPlan.schedule?.reduce((total: number, day) => total + day.activities.length, 0)}</span>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>

                      {/* Day by Day Schedule */}
                      <Card>
                        <CardHeader>
                          <CardTitle>Daily Schedule</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-6">
                            {tripPlan.schedule?.map((day, index) => (
                              <div key={index} className="border-b last:border-0 pb-6 last:pb-0">
                                <h3 className="text-lg font-semibold mb-4">Day {day.day} - {new Date(day.date).toLocaleDateString()}</h3>
                                <div className="space-y-4">
                                  {day.activities.map((activity, actIndex) => (
                                    <div key={actIndex} className="bg-secondary/5 p-4 rounded-lg">
                                      <div className="flex justify-between items-start mb-2">
                                        <h4 className="font-medium">{activity.title}</h4>
                                        <span className="text-sm text-muted-foreground">
                                          {activity.startTime} - {activity.endTime}
                                        </span>
                                      </div>
                                      <p className="text-sm text-muted-foreground mb-2">{activity.description}</p>
                                      <div className="flex items-center gap-2 text-sm">
                                        <MapPin className="h-4 w-4" />
                                        <span>{activity.location}</span>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>

                      {/* Recommendations */}
                      <Card>
                        <CardHeader>
                          <CardTitle>Travel Tips & Recommendations</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="grid md:grid-cols-2 gap-6">
                            <div>
                              <h4 className="font-medium mb-2">Packing List</h4>
                              <ul className="list-disc list-inside space-y-1 text-sm">
                                {tripPlan.recommendations?.packingList.map((item, index) => (
                                  <li key={index}>{item}</li>
                                ))}
                              </ul>
                            </div>
                            <div>
                              <h4 className="font-medium mb-2">Local Tips</h4>
                              <ul className="list-disc list-inside space-y-1 text-sm">
                                {tripPlan.recommendations?.localTips.map((tip, index) => (
                                  <li key={index}>{tip}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-center">
                        <Globe className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                        <h3 className="text-lg font-medium mb-2">
                          Ready to Plan Your Trip?
                        </h3>
                        <p className="text-muted-foreground">
                          Fill in your trip details and let AI create your perfect itinerary
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}