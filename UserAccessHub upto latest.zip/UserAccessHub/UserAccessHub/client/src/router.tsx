
import { Route, Routes } from "@solidjs/router";
import { lazy } from "solid-js";
import ProtectedRoute from "./components/auth/protected-route";
import { GoogleCallbackHandler } from "./components/auth/google-callback-handler";

// Import your actual page components
const HomePage = lazy(() => import("./pages/home"));
const AuthPage = lazy(() => import("./pages/auth-page"));
const FlightsPage = lazy(() => import("./pages/flights"));
const HotelsPage = lazy(() => import("./pages/hotels"));
const ProfilePage = lazy(() => import("./pages/profile"));

export default function Router() {
  return (
    <Routes>
      <Route path="/" component={HomePage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/auth/google/callback" component={GoogleCallbackHandler} />
      <Route 
        path="/flights" 
        component={() => (
          <ProtectedRoute>
            <FlightsPage />
          </ProtectedRoute>
        )} 
      />
      <Route 
        path="/hotels" 
        component={() => (
          <ProtectedRoute>
            <HotelsPage />
          </ProtectedRoute>
        )} 
      />
      <Route 
        path="/profile" 
        component={() => (
          <ProtectedRoute>
            <ProfilePage />
          </ProtectedRoute>
        )} 
      />
    </Routes>
  );
}
