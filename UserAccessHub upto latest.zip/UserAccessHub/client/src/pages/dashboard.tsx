import { useState } from "react";
import TopNav from "@/components/layout/top-nav";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MapPin, Calendar, Users, Search, Plane, Car, UtensilsCrossed, Bed, ArrowRight, TrendingUp, Heart, Clock, Star, MessageCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link, useLocation } from "wouter";
import { useTravelSearch } from "@/hooks/use-travel-search";
import { format } from "date-fns";
import { FlightBooking, HotelBooking, RideBooking, DiningBooking } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { generateFlights, generateHotels, generateRides, generateDining } from "@shared/mockData";
import { AnimatePresence, motion } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";
import { Skeleton } from "@/components/ui/skeleton";
import { UserPreferences } from "@/components/ui/user-preferences";
import { Chat } from "@/components/ui/chat";
import { TravelSearchProvider } from "@/components/providers/travel-search-provider";

export default function Dashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { searchParams, updateGeneralSearch, updateDestination } = useTravelSearch();
  const [showChat, setShowChat] = useState(false);
  const [localSearchParams, setLocalSearchParams] = useState({
    destination: searchParams.destination || "",
    checkIn: searchParams.checkIn || "",
    guests: searchParams.guests || "2-0-1"
  });

  const handleDestinationChange = (value: string) => {
    console.log('Dashboard: Updating destination to:', value);
    setLocalSearchParams(prev => ({ ...prev, destination: value }));
    updateGeneralSearch({
      location: value,
      checkIn: localSearchParams.checkIn,
      guests: parseInt(localSearchParams.guests.split('-')[0])
    });
    updateDestination(value);
  };

  const handleSearch = () => {
    if (!localSearchParams.destination) {
      toast({
        title: "Destination Required",
        description: "Please enter a destination to search",
        variant: "destructive"
      });
      return;
    }

    console.log('Dashboard: Performing search with:', localSearchParams);
    updateGeneralSearch({
      location: localSearchParams.destination,
      checkIn: localSearchParams.checkIn,
      guests: parseInt(localSearchParams.guests.split('-')[0])
    });

    const params = new URLSearchParams({
      location: localSearchParams.destination,
      checkIn: localSearchParams.checkIn,
      guests: localSearchParams.guests
    });

    setLocation(`/flights?${params.toString()}`);
  };

  const { data: hotels = [], isLoading: hotelsLoading } = useQuery<HotelBooking[]>({
    queryKey: ["/api/hotels"],
    initialData: generateHotels(8),
  });

  const { data: flights = [], isLoading: flightsLoading } = useQuery<FlightBooking[]>({
    queryKey: ["/api/flights"],
    initialData: generateFlights(8),
  });

  const { data: rides = [], isLoading: ridesLoading } = useQuery<RideBooking[]>({
    queryKey: ["/api/rides"],
    initialData: generateRides(8),
  });

  const { data: dining = [], isLoading: diningLoading } = useQuery<DiningBooking[]>({
    queryKey: ["/api/dining"],
    initialData: generateDining(8),
  });

  const calculateStats = () => {
    const now = new Date();
    const totalBookings =
      (hotels?.length || 0) +
      (flights?.length || 0) +
      (rides?.length || 0) +
      (dining?.length || 0);
    const pendingTrips = (
      (hotels?.filter(h => new Date(h.checkIn) > now).length || 0) +
      (flights?.filter(f => new Date(f.departure) > now).length || 0) +
      (rides?.filter(r => new Date(r.pickupTime) > now).length || 0) +
      (dining?.filter(d => new Date(d.reservationTime) > now).length || 0)
    );
    const savedItems =
      (hotels?.filter(h => h.isFavorite)?.length || 0) +
      (flights?.filter(f => f.isFavorite)?.length || 0);
    return {
      totalBookings,
      pendingTrips,
      savedItems
    };
  };

  const userStats = calculateStats();

  return (
    <TravelSearchProvider>
      <div className="min-h-screen bg-[#F5F5F5] relative">
        <TopNav />
        <main className="w-full max-w-[1140px] mx-auto px-4 py-6 space-y-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold">Welcome back, {user?.username}</h1>
              <p className="text-gray-600">Plan your next adventure</p>
            </div>
            <div className="flex gap-4">
              <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4" />
                    <span>{userStats.totalBookings} Bookings</span>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    <span>{userStats.pendingTrips} Pending Trips</span>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2">
                    <Heart className="w-4 h-4" />
                    <span>{userStats.savedItems} Saved Items</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-[#003580] to-[#00224f] rounded-lg" />
            <div className="relative bg-[url('https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?auto=format&fit=crop&q=80')] bg-cover bg-center rounded-lg">
              <div className="bg-black/40 rounded-lg p-8 md:p-12">
                <Card className="bg-white p-4 rounded-lg shadow-lg">
                  <CardContent className="p-0">
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                      <div className="md:col-span-4">
                        <div className="relative">
                          <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                          <Input
                            placeholder="Where are you going?"
                            className="pl-10 h-12 bg-white border-2 border-gray-200 focus:border-[#003580]"
                            value={localSearchParams.destination}
                            onChange={(e) => handleDestinationChange(e.target.value)}
                          />
                        </div>
                      </div>
                      <div className="md:col-span-3">
                        <div className="relative">
                          <Calendar className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                          <Input
                            type="date"
                            className="pl-10 h-12 bg-white border-2 border-gray-200 focus:border-[#003580]"
                            value={localSearchParams.checkIn}
                            onChange={(e) => setLocalSearchParams({ ...localSearchParams, checkIn: e.target.value })}
                            min={format(new Date(), 'yyyy-MM-dd')}
                          />
                        </div>
                      </div>
                      <div className="md:col-span-3">
                        <div className="relative">
                          <Users className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                          <Select
                            value={localSearchParams.guests}
                            onValueChange={(value) => setLocalSearchParams({ ...localSearchParams, guests: value })}
                          >
                            <SelectTrigger className="h-12 pl-10 bg-white border-2 border-gray-200 focus:border-[#003580]">
                              <SelectValue placeholder="2 adults · 0 children · 1 room" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="2-0-1">2 adults · 0 children · 1 room</SelectItem>
                              <SelectItem value="2-1-1">2 adults · 1 child · 1 room</SelectItem>
                              <SelectItem value="2-2-1">2 adults · 2 children · 1 room</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div className="md:col-span-2">
                        <Button
                          className="w-full h-12 bg-[#003580] hover:bg-[#00224f] text-white"
                          size="lg"
                          onClick={handleSearch}
                        >
                          <Search className="w-5 h-5 mr-2" />
                          Search
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <UserPreferences />
            <Card className="bg-white shadow-md">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-4">Quick Links</h3>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { icon: Bed, label: "Stays", path: "/hotels" },
                    { icon: Plane, label: "Flights", path: "/flights" },
                    { icon: Car, label: "Car Rentals", path: "/rides" },
                    { icon: UtensilsCrossed, label: "Dining", path: "/dining" }
                  ].map((item, index) => (
                    <Link key={index} to={item.path}>
                      <Button
                        variant="outline"
                        className="w-full justify-start gap-2"
                      >
                        <item.icon className="h-4 w-4" />
                        {item.label}
                      </Button>
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>


          <div className="dashboard-header rounded-lg shadow-sm p-6">
            <h2 className="text-2xl font-bold mb-6 text-white">Personalized Travel Suggestions</h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: Bed, label: "Stays", color: "bg-blue-100 text-blue-600", path: "/hotels", loading: hotelsLoading, count: hotels?.length },
              { icon: Plane, label: "Flights", color: "bg-purple-100 text-purple-600", path: "/flights", loading: flightsLoading, count: flights?.length },
              { icon: Car, label: "Car Rentals", color: "bg-green-100 text-green-600", path: "/rides", loading: ridesLoading, count: rides?.length },
              { icon: UtensilsCrossed, label: "Restaurants", color: "bg-orange-100 text-orange-600", path: "/dining", loading: diningLoading, count: dining?.length },
            ].map((item, index) => (
              <Link key={index} to={item.path}>
                <motion.div
                  className="cursor-pointer"
                  whileHover={{ scale: 1.02 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                >
                  <Card className={`${item.color} border-0`}>
                    <CardContent className="flex items-center justify-between p-4">
                      <div className="flex items-center gap-3">
                        <item.icon className="h-6 w-6" />
                        <div>
                          <span className="font-medium">{item.label}</span>
                          {item.loading ? (
                            <Skeleton className="h-4 w-8 mt-1" />
                          ) : (
                            <p className="text-sm opacity-75">{item.count || 0} Available</p>
                          )}
                        </div>
                      </div>
                      <ArrowRight className="h-5 w-5" />
                    </CardContent>
                  </Card>
                </motion.div>
              </Link>
            ))}
          </div>

          <div>
            <h2 className="text-2xl font-bold mb-6">Featured Properties</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {hotelsLoading ? (
                Array(4).fill(0).map((_, i) => (
                  <Card key={i}>
                    <CardContent className="p-0">
                      <Skeleton className="h-48" />
                      <div className="p-4">
                        <Skeleton className="h-6 w-3/4 mb-2" />
                        <Skeleton className="h-4 w-1/2" />
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : (
                hotels?.slice(0, 4).map((hotel, index) => (
                  <motion.div
                    key={index}
                    className="cursor-pointer group"
                    whileHover={{ scale: 1.02 }}
                    transition={{ type: "spring", stiffness: 400, damping: 10 }}
                  >
                    <Card className="overflow-hidden border-0 shadow-lg">
                      <div className="relative h-48">
                        <img
                          src={hotel.image}
                          alt={hotel.name}
                          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                        />
                        <button className="absolute top-4 right-4 p-2 rounded-full bg-white/80 hover:bg-white transition-colors">
                          <Heart className={`h-5 w-5 ${hotel.isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-500'}`} />
                        </button>
                      </div>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-semibold text-lg group-hover:text-[#003580] transition-colors">
                              {hotel.name}
                            </h3>
                            <p className="text-sm text-gray-600">{hotel.location}</p>
                          </div>
                          <div className="flex items-center bg-[#003580] text-white px-2 py-1 rounded">
                            <span className="font-bold mr-1">{hotel.rating}</span>
                            <Star className="h-4 w-4" />
                          </div>
                        </div>
                        <div className="flex items-center justify-between mt-4">
                          <div className="text-sm">
                            <span className="text-green-600 font-semibold">Free cancellation</span>
                            <span className="block text-gray-600">Limited time deal</span>
                          </div>
                          <div className="text-right">
                            <span className="block text-2xl font-bold text-[#003580]">
                              ${hotel.price}
                            </span>
                            <span className="text-sm text-gray-600">per night</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))
              )}
            </div>
          </div>
        </main>

        {/* Fixed Chat Button */}
        <div className="fixed bottom-6 left-6 z-40">
          <Button
            variant="default"
            size="lg"
            className="bg-[#003580] hover:bg-[#002255] text-white rounded-full shadow-lg"
            onClick={() => setShowChat(!showChat)}
          >
            <MessageCircle className="h-5 w-5 mr-2" />
            <span>Chat with Travelers</span>
          </Button>
        </div>

        <AnimatePresence>
          {showChat && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="fixed bottom-24 left-6 z-50"
            >
              <Chat onClose={() => setShowChat(false)} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </TravelSearchProvider>
  );
}