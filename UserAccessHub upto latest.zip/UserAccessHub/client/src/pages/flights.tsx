import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { FlightBooking } from "@shared/schema";
import TopNav from "@/components/layout/top-nav";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useTravelSearch } from "@/hooks/use-travel-search";
import { Plane, Search, MapPin } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogTrigger, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { SiAmericanairlines, SiUnitedairlines, SiDelta, SiSouthwestairlines, SiAircanada } from "react-icons/si";
import { Avatar } from "@/components/ui/avatar";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import { useLoading } from "@/hooks/use-loading";
import { PaymentForm } from "@/components/ui/payment-form";
import { aiService } from "@/lib/ai-service";
import { Plane as PlaneIcon, Clock, Calendar, Users,  Briefcase, Filter, Waypoints, Coffee, Wifi, Armchair, ArrowRight, TrendingUp, TrendingDown, AlertCircle, Bot, Brain } from "lucide-react";
import { SeatMap, type Seat } from "@/components/ui/seat-map";
import { Link } from "react-router-dom";


type Airport = {
  code: string;
  name: string;
  city: string;
  country: string;
  detailedName: string;
  terminal?: string;
};

// Mapping of airline names to their respective icons
const airlineIcons: { [key: string]: React.ComponentType<{ className?: string }> } = {
  "American Airlines": SiAmericanairlines,
  "United Airlines": SiUnitedairlines,
  "Delta Air Lines": SiDelta,
  "Southwest Airlines": SiSouthwestairlines,
  "Air Canada": SiAircanada,
};

interface Filter {
  stops?: string;
  airlines?: string[];
  departureTime?: string;
  amenities?: string[];
}

// Airport search UI component
const AirportSearchInput = ({
  value,
  onChange,
  onSelect,
  placeholder,
  label,
  airports,
  isLoading
}: {
  value: string;
  onChange: (value: string) => void;
  onSelect: (airport: Airport) => void;
  placeholder: string;
  label: string;
  airports: Airport[];
  isLoading: boolean;
}) => (
  <div className="relative">
    <label className="block text-sm font-medium text-gray-700 mb-1">
      {label}
    </label>
    <div className="relative">
      <Input
        type="text"
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full pl-10"
      />
      <Plane className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
    </div>
    {value.length >= 2 && (airports.length > 0 || isLoading) && (
      <div className="absolute z-50 w-full mt-1 bg-white rounded-md shadow-lg border">
        {isLoading ? (
          <div className="p-4">
            <Skeleton className="h-4 w-3/4 mb-2" />
            <Skeleton className="h-4 w-1/2" />
          </div>
        ) : (
          airports.map((airport) => (
            <button
              key={airport.code}
              className="w-full text-left px-4 py-3 hover:bg-gray-50 focus:bg-gray-50 focus:outline-none border-b last:border-b-0"
              onClick={() => onSelect(airport)}
            >
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-gray-400 mt-1 shrink-0" />
                <div>
                  <div className="font-medium">
                    {airport.city} ({airport.code})
                  </div>
                  <div className="text-sm text-gray-500">{airport.name}</div>
                  <div className="text-xs text-gray-400">
                    {airport.country}
                    {airport.terminal && ` • Terminal ${airport.terminal}`}
                  </div>
                </div>
              </div>
            </button>
          ))
        )}
      </div>
    )}
  </div>
);

export default function FlightsPage() {
  const { toast } = useToast();
  const { getCurrentDestination, updateDestination } = useTravelSearch();
  const [originSearch, setOriginSearch] = useState("");
  const [destSearch, setDestSearch] = useState(getCurrentDestination() || "");
  const [selectedOrigin, setSelectedOrigin] = useState<Airport | null>(null);
  const [selectedDestination, setSelectedDestination] = useState<Airport | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [selectedClass, setSelectedClass] = useState<string>("");
  const [passengers, setPassengers] = useState("1");
  const [searchTriggered, setSearchTriggered] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [selectedFlight, setSelectedFlight] = useState<FlightBooking | null>(null);
  const [selectedSeat, setSelectedSeat] = useState<Seat | null>(null);
  const [filters, setFilters] = useState<Filter>({});
  const [showAIInsights, setShowAIInsights] = useState(true);


  // Airport search queries
  const { data: originAirports = [], isLoading: isLoadingOrigins } = useQuery<Airport[]>({
    queryKey: ["/api/airports/search", originSearch],
    queryFn: async () => {
      if (!originSearch || originSearch.length < 2) return [];
      const res = await fetch(`/api/airports/search?keyword=${encodeURIComponent(originSearch)}`);
      if (!res.ok) throw new Error("Failed to fetch airports");
      return res.json();
    },
    enabled: originSearch.length >= 2,
  });

  const { data: destinationAirports = [], isLoading: isLoadingDestinations } = useQuery<Airport[]>({
    queryKey: ["/api/airports/search", destSearch],
    queryFn: async () => {
      if (!destSearch || destSearch.length < 2) return [];
      const res = await fetch(`/api/airports/search?keyword=${encodeURIComponent(destSearch)}`);
      if (!res.ok) throw new Error("Failed to fetch airports");
      return res.json();
    },
    enabled: destSearch.length >= 2,
  });

  // Handler for origin input change
  const handleOriginChange = (value: string) => {
    setOriginSearch(value);
    if (!value) setSelectedOrigin(null);
  };

  // Handler for destination input change
  const handleDestinationChange = (value: string) => {
    setDestSearch(value);
    if (!value) {
      setSelectedDestination(null);
      updateDestination('');
    }
  };

  // Handler for selecting an origin airport
  const handleOriginSelect = (airport: Airport) => {
    setSelectedOrigin(airport);
    setOriginSearch(airport.detailedName);
  };

  // Handler for selecting a destination airport
  const handleDestinationSelect = (airport: Airport) => {
    setSelectedDestination(airport);
    setDestSearch(airport.detailedName);
    updateDestination(airport.city);
  };

  const { data: flights = [], isLoading: isLoadingFlights } = useQuery<FlightBooking[]>({
    queryKey: ["/api/flights/search", searchTriggered, selectedOrigin?.code, selectedDestination?.code, selectedDate, selectedClass, filters],
    queryFn: async () => {
      // Only make API call if search is triggered and we have required fields
      if (!searchTriggered || !selectedOrigin?.code || !selectedDestination?.code || !selectedDate) {
        return [];
      }

      try {
        const params = new URLSearchParams({
          from: selectedOrigin.code,
          to: selectedDestination.code,
          date: selectedDate,
          passengers: passengers,
          ...(selectedClass && { class: selectedClass })
        });

        const response = await fetch(`/api/flights/search?${params.toString()}`, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
          },
        });

        if (!response.ok) {
          const error = await response.text();
          throw new Error(error || 'Failed to fetch flights');
        }

        return await response.json();
      } catch (error) {
        console.error('Error fetching flights:', error);
        toast({
          title: "Error",
          description: "Failed to fetch flights. Please try again.",
          variant: "destructive"
        });
        return [];
      }
    },
    enabled: searchTriggered && !!selectedOrigin?.code && !!selectedDestination?.code && !!selectedDate,
  });

  const { data: pricePrediction, isLoading: isPredictionLoading } = useQuery({
    queryKey: ["/api/ai/predict-prices", selectedOrigin?.code, selectedDestination?.code, selectedDate],
    queryFn: async () => {
      if (!selectedOrigin || !selectedDestination || !selectedDate) return null;
      return aiService.predictPrices(
        selectedOrigin.code,
        selectedDestination.code,
        selectedDate
      );
    },
    enabled: !!(selectedOrigin && selectedDestination && selectedDate),
  });

  const { data: travelTips, isLoading: isTipsLoading } = useQuery({
    queryKey: ["/api/ai/travel-tips", selectedDestination?.city],
    queryFn: async () => {
      if (!selectedDestination || !selectedDate) return null;
      return aiService.generateTravelTips(
        selectedDestination.city,
        { start: selectedDate, end: selectedDate },
        {}
      );
    },
    enabled: !!(selectedDestination && selectedDate),
  });

  const { isLoading } = useLoading(
    isLoadingOrigins || isLoadingDestinations || isLoadingFlights || isPredictionLoading || isTipsLoading
  );

  const getAirlineIcon = (airline: string) => {
    const IconComponent = airlineIcons[airline];
    return IconComponent ? <IconComponent className="w-8 h-8" /> : null;
  };

  const calculateDuration = (departure: string, arrival: string) => {
    const start = new Date(departure);
    const end = new Date(arrival);
    const hours = Math.floor((end.getTime() - start.getTime()) / (1000 * 60 * 60));
    const minutes = Math.floor(((end.getTime() - start.getTime()) % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  const generateMockSeats = (): Seat[] => {
    const seats: Seat[] = [];
    const rows = 20;
    const columns = ['A', 'B', 'C', 'D', 'E', 'F'];

    for (let row = 1; row <= rows; row++) {
      for (let col of columns) {
        const isWindow = col === 'A' || col === 'F';
        const isAisle = col === 'C' || col === 'D';
        seats.push({
          id: `${row}${col}`,
          row,
          column: col,
          type: isWindow ? "window" : isAisle ? "aisle" : "middle",
          status: Math.random() > 0.7 ? "occupied" : "available",
          price: isWindow ? 50 : isAisle ? 35 : 25,
        });
      }
    }
    return seats;
  };

  const handlePaymentComplete = () => {
    toast({
      title: "Booking Confirmed",
      description: "Your flight has been successfully booked. Check your email for details.",
    });
    setShowPayment(false);
    setSelectedFlight(null);
    setSelectedSeat(null);
  };

  const handleSearch = () => {
    if (!selectedOrigin || !selectedDestination || !selectedDate) {
      toast({
        title: "Missing Information",
        description: "Please select origin, destination, and date to search flights.",
        variant: "destructive",
      });
      return;
    }

    setSearchTriggered(true);
  };


  return (
    <div className="min-h-screen bg-gray-50">
      <TopNav />
      <div className="container mx-auto px-4 py-8">
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Origin Airport Search */}
              <AirportSearchInput
                value={originSearch}
                onChange={handleOriginChange}
                onSelect={handleOriginSelect}
                placeholder="Search for origin airport"
                label="From"
                airports={originAirports}
                isLoading={isLoadingOrigins}
              />

              {/* Destination Airport Search */}
              <AirportSearchInput
                value={destSearch}
                onChange={handleDestinationChange}
                onSelect={handleDestinationSelect}
                placeholder="Search for destination airport"
                label="To"
                airports={destinationAirports}
                isLoading={isLoadingDestinations}
              />

              {/* Date Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Departure Date
                </label>
                <Input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full"
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>

              {/* Passengers */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Passengers
                </label>
                <Select value={passengers} onValueChange={setPassengers}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {[1, 2, 3, 4, 5, 6].map((num) => (
                      <SelectItem key={num} value={num.toString()}>
                        {num} {num === 1 ? 'Passenger' : 'Passengers'}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Class Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Class
                </label>
                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select class" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ECONOMY">Economy</SelectItem>
                    <SelectItem value="PREMIUM_ECONOMY">Premium Economy</SelectItem>
                    <SelectItem value="BUSINESS">Business</SelectItem>
                    <SelectItem value="FIRST">First</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Search Button */}
            <Button
              className="w-full mt-6"
              onClick={handleSearch}
            >
              Search Flights
            </Button>
          </CardContent>
        </Card>

        {/* AI Insights Section */}
        <AnimatePresence>
          {showAIInsights && (pricePrediction || travelTips) && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="container mx-auto px-4 py-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Price Predictions */}
                {pricePrediction && (
                  <Card className="bg-white/95 backdrop-blur-sm border-primary/10 shadow-card hover:shadow-hover transition-all duration-300">
                    <div className="p-4 border-b border-border/40">
                      <h3 className="text-lg font-semibold gradient-heading">Price Intelligence</h3>
                    </div>
                    <CardContent className="p-5">
                      <div className="space-y-4">
                        <div className="flex items-center gap-2 p-2 rounded-md bg-accent/50">
                          {pricePrediction.trend === "rising" && (
                            <TrendingUp className="w-5 h-5 text-destructive" />
                          )}
                          {pricePrediction.trend === "falling" && (
                            <TrendingDown className="w-5 h-5 text-green-500" />
                          )}
                          <span className="font-medium">
                            Prices are {pricePrediction.trend}
                          </span>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          <AlertCircle className="w-4 h-4 inline mr-2" />
                          Best time to book: {pricePrediction.bestTimeToBook}
                        </div>
                        <div className="bg-primary/5 p-3 rounded-lg">
                          <div className="text-sm mb-1">Expected price range:</div>
                          <div className="text-xl font-bold text-primary">
                            ${pricePrediction.priceRange.min} - ${pricePrediction.priceRange.max}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Travel Tips */}
                {travelTips && travelTips.length > 0 && (
                  <Card className="bg-white/95 backdrop-blur-sm border-primary/10">
                    <div>
                      <h3 className="text-lg font-semibold">Smart Travel Tips</h3>
                    </div>
                    <CardContent>
                      <ul className="space-y-3">
                        {travelTips.map((tip, index) => (
                          <motion.li
                            key={index}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="flex items-start gap-3"
                          >
                            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                              <span className="text-xs text-primary font-medium">{index + 1}</span>
                            </div>
                            <p className="text-sm text-muted-foreground">{tip}</p>
                          </motion.li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Results Section */}
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
            {/* Filters Sidebar */}
            <div className="md:col-span-3">
              <Card className="bg-white sticky top-4">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-4 pb-4 border-b">
                    <Filter className="w-4 h-4 text-[#003580]" />
                    <h3 className="font-semibold text-[#003580]">Filter Flights</h3>
                  </div>

                  <div className="space-y-6">
                    <div>
                      <h4 className="text-sm font-medium mb-3">Stops</h4>
                      <div className="space-y-2">
                        {['nonstop', 'oneStop', 'multiStop'].map((stop) => (
                          <label key={stop} className="flex items-center cursor-pointer">
                            <input
                              type="radio"
                              checked={filters.stops === stop}
                              onChange={() => setFilters({ ...filters, stops: stop })}
                              className="w-4 h-4 border-2 border-gray-300 rounded-full text-[#003580]"
                            />
                            <span className="ml-2 text-sm">
                              {stop === 'nonstop' ? 'Non-stop' :
                                stop === 'oneStop' ? '1 Stop' :
                                  'Multiple Stops'}
                            </span>
                          </label>
                        ))}
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <h4 className="text-sm font-medium mb-3">Times</h4>
                      <div className="space-y-2">
                        {[
                          { label: 'Early Morning (12am - 6am)', value: 'early' },
                          { label: 'Morning (6am - 12pm)', value: 'morning' },
                          { label: 'Afternoon (12pm - 6pm)', value: 'afternoon' },
                          { label: 'Evening (6pm - 12am)', value: 'evening' }
                        ].map(({ label, value }) => (
                          <label key={value} className="flex items-center cursor-pointer">
                            <input
                              type="radio"
                              checked={filters.departureTime === value}
                              onChange={() => setFilters({ ...filters, departureTime: value })}
                              className="w-4 h-4 border-2 border-gray-300 rounded-full text-[#003580]"
                            />
                            <span className="ml-2 text-sm">{label}</span>
                          </label>
                        ))}
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <h4 className="text-sm font-medium mb-3">Amenities</h4>
                      <div className="space-y-2">
                        {[
                          { icon: Wifi, label: 'WiFi', value: 'wifi' },
                          { icon: Coffee, label: 'Meals', value: 'meals' },
                          { icon: Armchair, label: 'Extra Legroom', value: 'legroom' }
                        ].map(({ icon: Icon, label, value }) => (
                          <label key={value} className="flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              checked={filters.amenities?.includes(value)}
                              onChange={(e) => {
                                const newAmenities = e.target.checked
                                  ? [...(filters.amenities || []), value]
                                  : (filters.amenities || []).filter(a => a !== value);
                                setFilters({ ...filters, amenities: newAmenities });
                              }}
                              className="w-4 h-4 border-2 border-gray-300 rounded text-[#003580]"
                            />
                            <Icon className="w-4 h-4 mx-2 text-gray-500" />
                            <span className="text-sm">{label}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Flight Listings */}
            <div className="md:col-span-9 space-y-4">
              {isLoading ? (
                Array(3).fill(0).map((_, i) => (
                  <Card key={i} className="bg-white p-6">
                    <div className="flex items-center space-x-4">
                      <Skeleton className="h-16 w-16 rounded-full" />
                      <div className="flex-1">
                        <Skeleton className="h-6 w-32 mb-2" />
                        <Skeleton className="h-4 w-48" />
                      </div>
                      <div className="text-right">
                        <Skeleton className="h-8 w-24 mb-2" />
                        <Skeleton className="h-4 w-16" />
                      </div>
                    </div>
                  </Card>
                ))
              ) : (
                flights?.map((flight) => (
                  <motion.div
                    key={flight.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                  >
                    <Card className="bg-white hover:shadow-lg transition-all duration-300">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between flex-wrap gap-4">
                          <div className="flex items-center space-x-6">
                            <Avatar className="h-16 w-16 bg-gray-50">
                              {getAirlineIcon(flight.airline)}
                            </Avatar>
                            <div>
                              <div className="flex items-center gap-2 mb-2">
                                <h3 className="text-xl font-semibold text-[#003580]">{flight.airline}</h3>
                                {flight.amenities?.map((amenity) => (
                                  <Badge key={amenity} variant="outline" className="bg-gray-50">
                                    {amenity === 'wifi' && <Wifi className="w-3 h-3 mr-1" />}
                                    {amenity === 'meals' && <Coffee className="w-3 h-3 mr-1" />}
                                    {amenity === 'legroom' && <Armchair className="w-3 h-3 mr-1" />}
                                    {amenity.charAt(0).toUpperCase() + amenity.slice(1)}
                                  </Badge>
                                ))}
                              </div>

                              <div className="flex items-center text-sm space-x-4">
                                <div className="flex items-center">
                                  <span className="font-medium">{flight.from}</span>
                                  <div className="mx-2 flex items-center">
                                    <div className="w-2 h-2 rounded-full bg-[#003580]" />
                                    <div className="w-16 h-0.5 bg-[#003580]" />
                                    <ArrowRight className="w-4 h-4 text-[#003580]" />
                                    <div className="w-16 h-0.5 bg-[#003580]" />
                                    <div className="w-2 h-2 rounded-full bg-[#003580]" />
                                  </div>
                                  <span className="font-medium">{flight.to}</span>
                                </div>
                              </div>

                              <div className="flex items-center mt-2 text-sm text-gray-500 space-x-4">
                                <div className="flex items-center">
                                  <Calendar className="h-4 w-4 mr-1" />
                                  {format(new Date(flight.departure), "MMM d, yyyy")}
                                </div>
                                <div className="flex items-center">
                                  <Clock className="h-4 w-4 mr-1" />
                                  {calculateDuration(flight.departure, flight.arrival)}
                                </div>
                                <div className="flex items-center">
                                  <Users className="h-4 w-4 mr-1" />
                                  {passengers} {Number(passengers) === 1 ? 'passenger' : 'passengers'}
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="text-right">
                            <div className="text-3xl font-bold text-[#003580] mb-2">
                              ${flight.price}
                            </div>
                            <div className="inline-block px-3 py-1 rounded-full bg-blue-50 text-[#003580] text-sm font-medium mb-3">
                              {flight.class}
                            </div>
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button
                                  className="w-full md:w-auto bg-[#003580] hover:bg-[#00224f]"
                                  size="lg"
                                  onClick={() => setSelectedFlight(flight)}
                                >
                                  Select Seats
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-[90vw] w-full max-h-[90vh] h-full overflow-y-auto">
                                <DialogHeader>
                                  <DialogTitle>Select Your Seat</DialogTitle>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <p className="text-sm text-gray-500">
                                    Choose your preferred seat for the flight from {selectedFlight?.from} to {selectedFlight?.to}
                                  </p>
                                  <div className="flex justify-center items-center py-4">
                                    <SeatMap
                                      seats={generateMockSeats()}
                                      selectedSeat={selectedSeat}
                                      onSeatSelect={(seat) => {
                                        setSelectedSeat(seat);
                                        setShowPayment(true);
                                      }}
                                      className="w-full max-w-4xl"
                                    />
                                  </div>
                                  <div className="flex items-center gap-4">
                                    <div className="flex items-center gap-2">
                                      <div className="w-4 h-4 bg-green-500/20 border border-green-500 rounded" />
                                      <span className="text-sm">Available</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <div className="w-4 h-4 bg-red-500/20 border border-red-500 rounded" />
                                      <span className="text-sm">Occupied</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <div className="w-4 h-4 bg-blue-500/20 border border-blue-500 rounded" />
                                      <span className="text-sm">Selected</span>
                                    </div>
                                  </div>
                                  <div className="flex justify-end mt-4">
                                    <Button
                                      variant="outline"
                                      onClick={() => {
                                        setSelectedFlight(null);
                                        setSelectedSeat(null);
                                      }}
                                    >
                                      Cancel
                                    </Button>
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))
              )}
            </div>
          </div>
        </div>
        <Dialog open={showPayment} onOpenChange={setShowPayment}>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Complete Your Booking</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {selectedFlight && selectedSeat && (
                <>
                  <div className="bg-muted/50 p-4 rounded-lg space-y-2">
                    <h3 className="font-medium">Booking Summary</h3>
                    <div className="text-sm space-y-1">
                      <p>Flight: {selectedFlight.airline}</p>
                      <p>From: {selectedFlight.from} To: {selectedFlight.to}</p>
                      <p>Seat: {selectedSeat.row}{selectedSeat.column}</p>
                      <p>Class: {selectedFlight.class}</p>
                      <div className="flex justify-between items-center pt-2 border-t">
                        <span>Total Amount:</span>
                        <span className="font-bold">${selectedFlight.price + (selectedSeat.price || 0)}</span>
                      </div>
                    </div>
                  </div>
                  <PaymentForm
                    amount={selectedFlight.price + (selectedSeat.price || 0)}
                    onSuccess={handlePaymentComplete}
                    metadata={{
                      flightId: selectedFlight.id,
                      seatNumber: `${selectedSeat.row}${selectedSeat.column}`,
                      class: selectedFlight.class
                    }}
                  />
                </>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}