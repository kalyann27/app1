import { useEffect } from "react";
import { Redirect } from "wouter";
import { Loader2 } from "lucide-react";

export default function GoogleCallback() {
  useEffect(() => {
    // The Google OAuth flow will automatically handle the callback
    // We just need to show a loading state while the server processes it
    console.log("Google auth callback page mounted");
  }, []);

  // Get error from URL if present
  const params = new URLSearchParams(window.location.search);
  const error = params.get("error");

  if (error) {
    return <Redirect to={`/auth?error=${error}`} />;
  }

  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="text-center">
        <Loader2 className="mx-auto h-8 w-8 animate-spin text-primary" />
        <p className="mt-4 text-lg">Completing sign in...</p>
      </div>
    </div>
  );
}
