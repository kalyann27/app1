import { useContext } from 'react';
import { TravelSearchContext } from '@/lib/TravelSearchContext';

export function useTravelSearch() {
  const context = useContext(TravelSearchContext);
  if (context === undefined) {
    throw new Error('useTravelSearch must be used within a TravelSearchProvider');
  }

  // Helper function to check if we have active search parameters
  const hasActiveSearch = () => {
    const { destination, location } = context.searchParams;
    return !!(destination || location);
  };

  // Helper to get the current destination/location
  const getCurrentDestination = () => {
    const { destination, location } = context.searchParams;
    return destination || location || '';
  };

  // Helper to update both flight and general search at once
  const updateDestination = (value: string) => {
    console.log('Updating destination to:', value);
    context.updateGeneralSearch({ location: value });
    context.updateFlightSearch({ destination: value });
  };

  return {
    ...context,
    hasActiveSearch,
    getCurrentDestination,
    updateDestination,
  };
}