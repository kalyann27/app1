import { ReactNode } from "react";

export interface ThemeProviderProps {
  children: ReactNode;
  defaultTheme?: "dark" | "light" | "system";
  storageKey?: string;
}
