import { createContext, useContext, useState, ReactNode } from "react";

export interface TravelSearchParams {
  origin?: string;
  destination?: string;
  departureDate?: string;
  returnDate?: string;
  passengers?: number;
  travelClass?: string;
  location?: string;
  checkIn?: string;
  checkOut?: string;
  guests?: number;
}

interface TravelSearchContextType {
  searchParams: TravelSearchParams;
  setSearchParams: (params: Partial<TravelSearchParams>) => void;
  clearSearchParams: () => void;
  getFlightSearchParams: () => Partial<TravelSearchParams>;
  getHotelSearchParams: () => Partial<TravelSearchParams>;
  updateFlightSearch: (flightParams: Partial<TravelSearchParams>) => void;
  updateGeneralSearch: (generalParams: Partial<TravelSearchParams>) => void;
}

export const TravelSearchContext = createContext<TravelSearchContextType | undefined>(undefined);

export function TravelSearchProvider({ children }: { children: ReactNode }) {
  const [searchParams, setSearchParams] = useState<TravelSearchParams>({});

  const clearSearchParams = () => {
    setSearchParams({});
  };

  const getFlightSearchParams = () => {
    const { origin, destination, departureDate, returnDate, passengers, travelClass } = searchParams;
    return { origin, destination, departureDate, returnDate, passengers, travelClass };
  };

  const getHotelSearchParams = () => {
    const { location, checkIn, checkOut, guests } = searchParams;
    return { location, checkIn, checkOut, guests };
  };

  // Update flight-specific parameters and sync with general search
  const updateFlightSearch = (flightParams: Partial<TravelSearchParams>) => {
    console.log('Updating flight search with:', flightParams);
    setSearchParams(prev => {
      const updated = {
        ...prev,
        ...flightParams,
        // Sync destination with location for hotel search
        location: flightParams.destination || prev.location
      };
      console.log('Updated search params:', updated);
      return updated;
    });
  };

  // Update general search parameters and sync with flight search
  const updateGeneralSearch = (generalParams: Partial<TravelSearchParams>) => {
    console.log('Updating general search with:', generalParams);
    setSearchParams(prev => {
      const updated = {
        ...prev,
        ...generalParams,
        // Sync location with destination for flight search
        destination: generalParams.location || prev.destination
      };
      console.log('Updated search params:', updated);
      return updated;
    });
  };

  return (
    <TravelSearchContext.Provider 
      value={{ 
        searchParams, 
        setSearchParams,
        clearSearchParams,
        getFlightSearchParams,
        getHotelSearchParams,
        updateFlightSearch,
        updateGeneralSearch
      }}
    >
      {children}
    </TravelSearchContext.Provider>
  );
}

export function useTravelSearch() {
  const context = useContext(TravelSearchContext);
  if (context === undefined) {
    throw new Error('useTravelSearch must be used within a TravelSearchProvider');
  }
  return context;
}