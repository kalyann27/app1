import { createContext, useContext, useState, ReactNode } from 'react';

interface TravelSearchContextType {
  generalSearch: {
    location: string;
    checkIn: string;
    guests: number;
  };
  destination: string;
  updateGeneralSearch: (search: { location: string; checkIn: string; guests: number }) => void;
  updateDestination: (destination: string) => void;
  getCurrentDestination: () => string;
}

const TravelSearchContext = createContext<TravelSearchContextType | undefined>(undefined);

interface TravelSearchProviderProps {
  children: ReactNode;
}

export function TravelSearchProvider({ children }: TravelSearchProviderProps) {
  const [generalSearch, setGeneralSearch] = useState({
    location: '',
    checkIn: '',
    guests: 2
  });
  const [destination, setDestination] = useState('');

  const updateGeneralSearch = (search: { location: string; checkIn: string; guests: number }) => {
    console.log('TravelSearchProvider: Updating general search:', search);
    setGeneralSearch(search);
  };

  const updateDestination = (newDestination: string) => {
    console.log('TravelSearchProvider: Updating destination:', newDestination);
    setDestination(newDestination);
  };

  const getCurrentDestination = () => {
    return destination;
  };

  return (
    <TravelSearchContext.Provider
      value={{
        generalSearch,
        destination,
        updateGeneralSearch,
        updateDestination,
        getCurrentDestination
      }}
    >
      {children}
    </TravelSearchContext.Provider>
  );
}

export function useTravelSearch() {
  const context = useContext(TravelSearchContext);
  if (context === undefined) {
    throw new Error('useTravelSearch must be used within a TravelSearchProvider');
  }
  return context;
}
