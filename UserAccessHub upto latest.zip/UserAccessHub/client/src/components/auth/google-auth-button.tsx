import { useState } from "react";
import { SiGoogle } from "react-icons/si";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function GoogleAuthButton() {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleGoogleLogin = async () => {
    try {
      setIsLoading(true);

      // Ensure we're using the correct URL with the current origin
      const baseUrl = window.location.origin;
      const authUrl = `${baseUrl}/api/auth/google`;

      console.log('Initiating Google auth redirect to:', authUrl);
      window.location.href = authUrl;
    } catch (error) {
      console.error('Google auth error:', error);
      toast({
        title: "Authentication Error",
        description: "Failed to initiate Google login. Please try again.",
        variant: "destructive"
      });
      setIsLoading(false);
    }
  };

  return (
    <Button
      variant="outline"
      className="w-full flex items-center justify-center gap-2 bg-white hover:bg-gray-50"
      onClick={handleGoogleLogin}
      disabled={isLoading}
    >
      {isLoading ? (
        <Loader2 className="h-4 w-4 animate-spin" />
      ) : (
        <SiGoogle className="h-4 w-4 text-blue-500" />
      )}
      {isLoading ? "Connecting..." : "Sign in with Google"}
    </Button>
  );
}
