import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, MapPin, Calendar, Landmark } from 'lucide-react';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from './card';
import { Button } from './button';
import { ScrollArea } from './scroll-area';
import { 
  travelDestinations, 
  type Country, 
  type City, 
  type Attraction 
} from '@shared/data/travelDestinations';

export function DestinationsShowcase() {
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
  const [selectedCity, setSelectedCity] = useState<string | null>(null);

  const handleCountryClick = (countryName: string) => {
    setSelectedCountry(selectedCountry === countryName ? null : countryName);
    setSelectedCity(null);
  };

  const handleCityClick = (cityName: string) => {
    setSelectedCity(selectedCity === cityName ? null : cityName);
  };

  return (
    <div className="p-4 space-y-4">
      <h2 className="text-3xl font-bold text-center mb-8">Popular Destinations</h2>
      
      {travelDestinations.map((country) => (
        <Card key={country.name} className="overflow-hidden">
          <Button
            variant="ghost"
            className="w-full flex items-center justify-between p-4 hover:bg-accent"
            onClick={() => handleCountryClick(country.name)}
          >
            <div className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              <span className="font-semibold">{country.name}</span>
            </div>
            <ChevronDown
              className={`h-5 w-5 transition-transform ${
                selectedCountry === country.name ? 'transform rotate-180' : ''
              }`}
            />
          </Button>

          <AnimatePresence>
            {selectedCountry === country.name && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
              >
                <CardContent className="pt-0">
                  {/* Events Section */}
                  {country.events && country.events.length > 0 && (
                    <div className="mb-4">
                      <h4 className="font-semibold flex items-center gap-2 mb-2">
                        <Calendar className="h-4 w-4" />
                        Notable Events
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {country.events.map((event) => (
                          <div
                            key={event.name}
                            className="p-2 bg-muted rounded-lg text-sm"
                          >
                            <span className="font-medium">{event.name}</span>
                            {event.month && (
                              <span className="text-muted-foreground"> - {event.month}</span>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Cities Section */}
                  <div className="space-y-2">
                    {country.cities.map((city) => (
                      <Card key={city.name} className="overflow-hidden">
                        <Button
                          variant="ghost"
                          className="w-full flex items-center justify-between p-2"
                          onClick={() => handleCityClick(city.name)}
                        >
                          <span className="font-medium">{city.name}</span>
                          <ChevronDown
                            className={`h-4 w-4 transition-transform ${
                              selectedCity === city.name ? 'transform rotate-180' : ''
                            }`}
                          />
                        </Button>

                        <AnimatePresence>
                          {selectedCity === city.name && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.2 }}
                            >
                              <CardContent className="pt-0">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                  {city.attractions.map((attraction) => (
                                    <div
                                      key={attraction.name}
                                      className="flex items-center gap-2 p-2 bg-muted rounded-lg"
                                    >
                                      <Landmark className="h-4 w-4 text-primary" />
                                      <div>
                                        <div className="font-medium text-sm">
                                          {attraction.name}
                                        </div>
                                        {attraction.type && (
                                          <div className="text-xs text-muted-foreground">
                                            {attraction.type}
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </CardContent>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </motion.div>
            )}
          </AnimatePresence>
        </Card>
      ))}
    </div>
  );
}
