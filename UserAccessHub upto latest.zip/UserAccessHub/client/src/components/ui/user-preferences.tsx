import { useState } from "react";
import { Card, CardContent } from "./card";
import { Button } from "./button";
import { motion, AnimatePresence } from "framer-motion";
import { Check, ChevronDown, Calendar, Trophy } from "lucide-react";

interface Preference {
  category: string;
  selected: boolean;
}

interface Event {
  name: string;
  date: string;
  location: string;
  type: 'sport' | 'cultural' | 'festival';
}

const localEvents: Event[] = [
  {
    name: "Super Bowl",
    date: "February",
    location: "United States",
    type: "sport"
  },
  {
    name: "Coachella Music Festival",
    date: "April",
    location: "United States",
    type: "festival"
  },
  {
    name: "Thanksgiving Day Parade",
    date: "November",
    location: "United States",
    type: "cultural"
  },
  {
    name: "Montreal International Jazz Festival",
    date: "July",
    location: "Canada",
    type: "festival"
  }
];

const preferenceVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 }
  },
  exit: {
    opacity: 0,
    y: -20,
    transition: { duration: 0.3 }
  }
};

export function UserPreferences() {
  const [preferences, setPreferences] = useState<Preference[]>([
    { category: "Sports Events", selected: false },
    { category: "Cultural Festivals", selected: false },
    { category: "Music Festivals", selected: false },
    { category: "Local Celebrations", selected: false }
  ]);

  const [showEvents, setShowEvents] = useState(false);

  const togglePreference = (index: number) => {
    const newPreferences = [...preferences];
    newPreferences[index].selected = !newPreferences[index].selected;
    setPreferences(newPreferences);
  };

  return (
    <Card className="bg-white shadow-md">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold">Your Event Preferences</h3>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowEvents(!showEvents)}
            className="text-gray-500 hover:text-gray-700"
          >
            <ChevronDown className={`h-5 w-5 transition-transform ${showEvents ? 'rotate-180' : ''}`} />
          </Button>
        </div>

        <AnimatePresence>
          {showEvents && (
            <motion.div
              initial="hidden"
              animate="visible"
              exit="exit"
              variants={preferenceVariants}
              className="space-y-4"
            >
              <div className="grid grid-cols-2 gap-3">
                {preferences.map((pref, index) => (
                  <motion.button
                    key={pref.category}
                    onClick={() => togglePreference(index)}
                    className={`p-3 rounded-lg border-2 transition-colors ${
                      pref.selected
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{pref.category}</span>
                      {pref.selected && <Check className="h-4 w-4" />}
                    </div>
                  </motion.button>
                ))}
              </div>

              <div className="mt-6">
                <h4 className="text-lg font-medium mb-3">Upcoming Events</h4>
                <div className="space-y-3">
                  {localEvents.map((event, index) => (
                    <motion.div
                      key={event.name}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-center gap-3 p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors"
                    >
                      {event.type === 'sport' ? (
                        <Trophy className="h-5 w-5 text-green-500" />
                      ) : (
                        <Calendar className="h-5 w-5 text-blue-500" />
                      )}
                      <div>
                        <p className="font-medium">{event.name}</p>
                        <p className="text-sm text-gray-500">
                          {event.date} • {event.location}
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </CardContent>
    </Card>
  );
}
