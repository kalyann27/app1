import { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { Send, X, Check } from 'lucide-react';
import { Button } from './button';
import { Card, CardContent, CardHeader, CardTitle } from './card';
import { Input } from './input';
import { ScrollArea } from './scroll-area';
import { useToast } from "@/hooks/use-toast";
import { ErrorBoundary } from "./error-boundary";

interface Message {
  id: string;
  type: 'message' | 'status';
  sender?: string;
  content: string;
  timestamp: number;
  status?: 'sent' | 'delivered' | 'seen';
}

interface ChatProps {
  onClose?: () => void;
}

export function Chat({ onClose }: ChatProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!user?.id || !user?.username) {
      toast({
        title: "Authentication Required",
        description: "Please log in to use the chat feature",
        variant: "destructive"
      });
      return;
    }

    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws/chat`;
      console.log('Connecting to WebSocket:', wsUrl);

      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log('WebSocket connected');
        setIsConnected(true);

        // Send authentication message
        ws.send(JSON.stringify({
          type: 'auth',
          userId: user.id,
          username: user.username
        }));
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          console.log('Received message:', data);

          // Send delivery receipt for received messages
          if (data.type === 'message' && data.sender !== user.username) {
            ws.send(JSON.stringify({
              type: 'receipt',
              messageId: data.id,
              status: 'delivered',
              recipient: user.username
            }));
          }

          // Handle delivery receipts
          if (data.type === 'receipt') {
            setMessages(prev => prev.map(msg => 
              msg.id === data.messageId 
                ? { ...msg, status: data.status }
                : msg
            ));
            return;
          }

          // Add new message with unique ID if it doesn't exist
          setMessages(prev => {
            const exists = prev.some(msg => 
              msg.id === data.id || 
              (msg.timestamp === data.timestamp && msg.content === data.content)
            );
            if (!exists) {
              return [...prev, {
                ...data,
                id: data.id || `${Date.now()}-${Math.random()}`,
                status: data.sender === user.username ? 'sent' : 'delivered'
              }];
            }
            return prev;
          });

          // Auto-scroll to bottom
          if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
          }
        } catch (error) {
          console.error('Error processing message:', error);
        }
      };

      ws.onclose = () => {
        console.log('WebSocket disconnected');
        setIsConnected(false);
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        setIsConnected(false);
      };

      return () => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.close();
        }
      };
    } catch (error) {
      console.error('Error setting up WebSocket:', error);
    }
  }, [user, toast]);

  const sendMessage = () => {
    if (!input.trim() || !wsRef.current || !isConnected) return;

    try {
      const messageId = `${Date.now()}-${Math.random()}`;
      const messageToSend = {
        id: messageId,
        type: 'message',
        sender: user?.username,
        content: input.trim(),
        timestamp: Date.now(),
        status: 'sent'
      };

      wsRef.current.send(JSON.stringify(messageToSend));
      setInput('');
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive"
      });
    }
  };

  // Handle message seen status
  useEffect(() => {
    const markMessagesAsSeen = () => {
      if (!wsRef.current || !isConnected) return;

      const unseenMessages = messages.filter(msg => 
        msg.sender !== user?.username && 
        msg.status !== 'seen'
      );

      unseenMessages.forEach(msg => {
        wsRef.current?.send(JSON.stringify({
          type: 'receipt',
          messageId: msg.id,
          status: 'seen',
          recipient: user?.username
        }));
      });
    };

    // Mark messages as seen when chat is focused
    window.addEventListener('focus', markMessagesAsSeen);

    return () => {
      window.removeEventListener('focus', markMessagesAsSeen);
    };
  }, [messages, isConnected, user?.username]);

  const MessageStatus = ({ status }: { status?: string }) => {
    if (!status || status === 'sent') {
      return <Check className="h-3 w-3 text-gray-400" />;
    }
    if (status === 'delivered') {
      return (
        <div className="flex">
          <Check className="h-3 w-3 text-gray-400" />
          <Check className="h-3 w-3 text-gray-400 -ml-1" />
        </div>
      );
    }
    if (status === 'seen') {
      return (
        <div className="flex">
          <Check className="h-3 w-3 text-blue-500" />
          <Check className="h-3 w-3 text-blue-500 -ml-1" />
        </div>
      );
    }
    return null;
  };

  return (
    <ErrorBoundary>
      <Card className="w-[400px] shadow-xl">
        <CardHeader className="p-4 flex flex-row items-center justify-between space-y-0 border-b bg-[#003580] text-white">
          <CardTitle className="text-lg font-semibold">Travel Chat</CardTitle>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-white hover:text-white/80"
            onClick={onClose}
          >
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>

        <CardContent className="p-0">
          <ScrollArea className="h-[400px] p-4" ref={scrollRef}>
            {messages.map((message, index) => (
              <div
                key={message.id}
                className={`mb-4 ${message.type === 'status' ? 'text-center' : ''}`}
              >
                {message.type === 'status' ? (
                  <p className="text-sm text-gray-500">{message.content}</p>
                ) : (
                  <div className={`flex flex-col ${message.sender === user?.username ? 'items-end' : 'items-start'}`}>
                    <div className={`max-w-[80%] rounded-lg p-3 ${
                      message.sender === user?.username
                        ? 'bg-[#003580] text-white'
                        : 'bg-gray-100'
                    }`}>
                      <p className="text-xs font-medium mb-1">{message.sender}</p>
                      <p className="text-sm break-words">{message.content}</p>
                    </div>
                    <div className="flex items-center gap-1 mt-1">
                      <span className="text-xs text-gray-500">
                        {new Date(message.timestamp).toLocaleTimeString()}
                      </span>
                      {message.sender === user?.username && (
                        <MessageStatus status={message.status} />
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </ScrollArea>

          <div className="p-4 border-t">
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                placeholder="Type a message..."
                className="flex-1"
                disabled={!isConnected}
              />
              <Button
                onClick={sendMessage}
                disabled={!isConnected || !input.trim()}
                size="icon"
                className="bg-[#003580] hover:bg-[#002255]"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
            {!isConnected && (
              <p className="text-xs text-red-500 mt-2">
                Disconnected from chat
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </ErrorBoundary>
  );
}