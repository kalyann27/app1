import { useState, useEffect } from "react";
import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "./hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";
import { Footer } from "@/components/layout/footer";
import { SplashScreen } from "@/components/ui/splash-screen";
import { TravelSearchProvider } from "./lib/TravelSearchContext";
import { ThemeProvider } from "./components/theme/theme-provider";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import Dashboard from "@/pages/dashboard";
import FlightsPage from "@/pages/flights";
import HotelsPage from "@/pages/hotels";
import RidesPage from "@/pages/rides";
import DiningPage from "@/pages/dining";
import ProfilePage from "@/pages/profile";
import MemoriesPage from "@/pages/memories";
import ChatbotPage from "@/pages/chatbot";
import BudgetForecastPage from "@/pages/budget-forecast";
import TripPlannerPage from "@/pages/trip-planner";
import { FloatingChat } from "@/components/ui/floating-chat";
import { TranslationBubble } from "@/components/ui/translation-bubble";
import errorLogger from './lib/errorLogger';

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/flights" component={FlightsPage} />
      <ProtectedRoute path="/hotels" component={HotelsPage} />
      <ProtectedRoute path="/rides" component={RidesPage} />
      <ProtectedRoute path="/dining" component={DiningPage} />
      <ProtectedRoute path="/profile" component={ProfilePage} />
      <ProtectedRoute path="/memories" component={MemoriesPage} />
      <ProtectedRoute path="/chatbot" component={ChatbotPage} />
      <ProtectedRoute path="/budget-forecast" component={BudgetForecastPage} />
      <ProtectedRoute path="/trip-planner" component={TripPlannerPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [showSplash, setShowSplash] = useState(() => {
    const hasSeenSplash = sessionStorage.getItem('hasSeenSplash');
    return !hasSeenSplash;
  });
  const [, setLocation] = useLocation();

  useEffect(() => {
    errorLogger.init();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="system" storageKey="ui-theme">
        <AuthProvider>
          <TravelSearchProvider>
            <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-secondary/10 flex flex-col">
              <div className="flex-1">
                <Router />
                <FloatingChat />
                <TranslationBubble />
                <Toaster />
              </div>
              <Footer />
              {showSplash && (
                <SplashScreen 
                  onDismiss={() => {
                    setShowSplash(false);
                    sessionStorage.setItem('hasSeenSplash', 'true');
                    setLocation("/auth");
                  }}
                />
              )}
            </div>
          </TravelSearchProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;